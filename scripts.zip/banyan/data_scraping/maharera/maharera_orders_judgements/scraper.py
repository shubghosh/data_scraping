from requests_toolbelt import MultipartEncoder
from bs4 import BeautifulSoup
import http.client
from datetime import datetime
import requests
import json
import os
import base64


http.client.MAXHEADERS = 100000
TIMEOUT = 120

HOME_PAGE_URL = "https://maharerait.mahaonline.gov.in/Login/Login"
ORDER_PAGE_URL = "https://maharerait.mahaonline.gov.in"
RECORD_URL = "https://maharerait.mahaonline.gov.in/SearchList/SearchJudgements"
PDF_URL = "https://maharerait.mahaonline.gov.in/SearchList/ShowComplaintView"
NON_REGITERED_RULINGS = (
    "https://maharerait.mahaonline.gov.in/SearchList/ShowSourceInfoFileOrder"
)

session = requests.Session()
base_url = "http://localhost:1567"


def create_get_url(base_url, data=dict()):
    if len(data) == 0:
        return base_url
    url = base_url + "?"
    for key, val in data.items():
        url += key + "=" + val + "&"
    return url[:-1]


def soup_creator(url):
    return BeautifulSoup(url.text, "html.parser")


def set_payload(meta_data):
    payload = {
        "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3",
        "Accept-Encoding": "gzip, deflate, br",
        "Accept-Language": "en-GB,en-US;q=0.9,en;q=0.8",
        "Connection": "keep-alive",
        "Cookie": meta_data["cookies"],
        "Host": "maharerait.mahaonline.gov.in",
        "Referer": "https://maharerait.mahaonline.gov.in/Login/Login/",
        "Upgrade-Insecure-Requests": "1",
        "User-Agent": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_5) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/75.0.3770.100 Safari/537.36",
    }
    return payload


def set_formdata_1(token, type):
    form_data = {
        "__RequestVerificationToken": token,
        "IsSourceComplaint": "",
        "Type": str(type),
        "ID": "0",
        "pageTraverse": "1",
        "ComplaintNo": "",
        "hdnComplaintNoNo": "",
        "CertiNo": "",
        "hdnCertiNo": "",
        "SourceComplaintNo": "",
        "hdnAgent": "",
        "SourceComplaintName": "",
        "hdnAgent": "",
        "CompletionDate_From": "",
        "hdnfromdate": "",
        "CompletionDate_To": "",
        "hdntodate": "",
        "ComplainantName": "",
        "hdnComplainantName": "",
        "RespondentName": "",
        "hdnRespondentName": "",
        "btnSearch": "Search",
        "IsSourceComplaint": "",
    }
    return form_data


def set_formdata_2(i, meta_data):
    form_data = {
        "__RequestVerificationToken": meta_data["token"],
        "IsSourceComplaint": "",
        "Type": str(meta_data["type"]),
        "ID": "0",
        "pageTraverse": "1",
        "ComplaintNo": "",
        "hdnComplaintNoNo": "",
        "CertiNo": "",
        "hdnCertiNo": "",
        "SourceComplaintNo": "",
        "hdnAgent": "",
        "SourceComplaintName": "",
        "hdnAgent": "",
        "CompletionDate_From": "",
        "hdnfromdate": "",
        "CompletionDate_To": "",
        "hdntodate": "",
        "ComplainantName": "",
        "hdnComplainantName": "",
        "RespondentName": "",
        "hdnRespondentName": "",
        "btnSearch": "Search",
        "IsSourceComplaint": "",
        "TotalRecords": str(meta_data["records"]),
        "CurrentPage": str(i),
        "TotalPages": "77",
        "Command": "Next",
    }

    return form_data


def set_formdata_3(token):

    form_data = {"ID": token, "Type": "4"}
    return form_data


def set_formdata_4(token):

    form_data = {"ID": token}
    return form_data


def get_pdf_judgement(token, payload):
    form_data = set_formdata_3(token)
    response = session.post(PDF_URL, headers=payload, data=form_data)
    return response


def get_pdf_internim_judgement(token, payload):
    form_data = set_formdata_3(token)
    response = session.post(PDF_URL, headers=payload, data=form_data)
    return response


def get_pdf_judgement_non_rgtn_rulings(token, payload):
    form_data = set_formdata_4(token)
    response = session.post(
        NON_REGITERED_RULINGS, headers=payload, data=form_data
    )
    return response


def get_col_data(rows, payload, doc_response):
    for row in rows:
        data_dict = {}
        cols = row.find_all("td")
        data_dict["s_no"] = cols[0].text.strip()
        data_dict["complainant_no"] = cols[1].text.strip()
        data_dict["complainant_name"] = cols[2].text.strip()
        data_dict["respondent_name"] = cols[3].text.strip()
        data_dict["maharera_regn_no"] = cols[4].text.strip()
        data_dict["heard_by"] = cols[5].text.strip()

        if cols[6].find("a"):
            data_dict["view_judgement"] = (
                cols[6].find("a")["data-qstr"].strip()
            )
            response = get_pdf_judgement(data_dict["view_judgement"], payload)
            content = base64.decodestring(response.content)
            doc_data = {
                "pdf_link": dict(
                    content=content,
                    content_type=response.headers["Content-Type"],
                )
            }
        if cols[7].find("a"):
            data_dict["view_internim_judgement"] = (
                cols[7].find("a")["data-qstr"].strip()
            )
            response = get_pdf_internim_judgement(
                data_dict["view_internim_judgement"], payload
            )
            content = base64.decodestring(response.content)
            doc_data = {
                "pdf_link_internim": dict(
                    content=content,
                    content_type=response.headers["Content-Type"],
                )
            }
        doc_data = {
            "link": dict(
                content=doc_response,
                content_type=doc_response.headers["Content-Type"],
            )
        }
        data = dict(
            export_type="DATA", record_params=data_dict, doc_params=doc_data
        )
        api_data = prepare_export_data(data)
        url = base_url + "/export/data"
        api_call(url, api_data, api_data.content_type)


def get_col_data_1(rows, payload, doc_response):
    for row in rows:
        data_dict = {}
        cols = row.find_all("td")
        data_dict["s_no"] = cols[0].text.strip()
        data_dict["complainant_no"] = cols[1].text.strip()
        data_dict["complainant_name"] = cols[2].text.strip()
        data_dict["respondent_name"] = cols[3].text.strip()
        if cols[4].find("a"):
            data_dict["view_judgement"] = (
                cols[4].find("a")["data-qstr"].strip()
            )
            response = get_pdf_judgement_non_rgtn_rulings(
                data_dict["view_judgement"], payload
            )
            content = base64.decodestring(response.content)
            doc_data = {
                "pdf_link_non_rgtn_rulings": dict(
                    content=content,
                    content_type=response.headers["Content-Type"],
                )
            }
    doc_data = {
        "link": dict(
            content=doc_response,
            content_type=doc_response.headers["Content-Type"],
        )
    }
    data = dict(
        export_type="DATA", record_params=data_dict, doc_params=doc_data
    )
    api_data = prepare_export_data(data)
    url = base_url + "/export/data"
    api_call(url, api_data, api_data.content_type)


def get_pages(soup):
    total_pages = soup.find("input", {"id": "TotalPages"})["value"]
    return total_pages


def get_total_records(soup):
    total_records = soup.find("input", {"id": "TotalRecords"})["value"]
    return total_records


def get_details(meta_data):
    for i in range(0, int(meta_data["pages"])):
        payload = set_payload(meta_data)
        response = session.get(
            meta_data["url"], headers=payload, timeout=TIMEOUT
        )
        if response.status_code != 200:
            return dict(
                status="ERROR",
                error_type="PRE_LOAD_FAIL",
                message="Failed to load home page!!",
            )
        soup = soup_creator(response)
        meta_data["token"] = soup.find(
            "input", {"name": "__RequestVerificationToken"}
        )["value"]
        form_data = set_formdata_2(i, meta_data)
        resp = session.post(RECORD_URL, data=form_data, headers=payload)
        soup = soup_creator(resp)
        table_body = soup.find("tbody")
        rows = table_body.find_all("tr")

        if meta_data["type"] == 3:
            get_col_data_1(rows, payload, resp)
        elif meta_data["type"] == 1 or meta_data["type"] == 2:
            get_col_data(rows, payload, resp)


def get_records(meta_data):
    payload = set_payload(meta_data)
    response = session.get(meta_data["url"], headers=payload, timeout=TIMEOUT)
    if response.status_code != 200:
        return dict(
            status="ERROR",
            error_type="PRE_LOAD_FAIL",
            message="Failed to load home page!!",
        )
    soup = soup_creator(response)
    req_token = soup.find("input", {"name": "__RequestVerificationToken"})[
        "value"
    ]
    for i in range(1, 4):
        form_data = set_formdata_1(req_token, i)
        resp = session.post(RECORD_URL, data=form_data, headers=payload)
        soup = soup_creator(resp)
        meta_data["pages"] = get_pages(soup)
        meta_data["records"] = get_total_records(soup)
        meta_data["type"] = i
        get_details(meta_data)


def get_orders_url(home_url):
    meta_data = {}

    response = session.get(home_url, timeout=TIMEOUT)
    if response.status_code != 200:
        return dict(
            status="ERROR",
            error_type="PRE_LOAD_FAIL",
            message="Failed to load home page!!",
        )
    cookies = response.headers["Set-Cookie"].split(";")
    session_id = cookies[0]
    request_verification = cookies[-3].split(",")[1]
    meta_data["cookies"] = session_id + ";" + request_verification
    soup = soup_creator(response)
    divs = soup.find_all("div", {"class": "search-pro-details"})
    causelist_url = divs[-3].find("a")["href"]
    meta_data["url"] = ORDER_PAGE_URL + causelist_url
    return meta_data


def prepare_export_data(data):
    params = dict(
        export_type=data["export_type"],
        record_params=data["record_params"],
        doc_params=dict(),
    )
    fields = {}
    if "doc_params" in data:
        for k, v in data["doc_params"].items():
            file_name = k
            params["doc_params"][k] = dict(
                content_type=v["content_type"], file_name=file_name
            )
            file_path = "./" + file_name
            with open(file_path, "wb") as f:
                f.write(v["content"])
            fields[file_name] = (
                file_name,
                open(file_path, "rb"),
                v["content_type"],
            )
            os.system("rm " + file_path)
    fields["params"] = json.dumps(params)
    return MultipartEncoder(fields=fields)


def api_call(url, data, content_type="text/plain"):
    try:
        response = requests.post(
            url=url, data=data, headers={"Content-Type": content_type}
        )
        print(response)
        resp = response.json()
        print(resp)
    except Exception as e:
        print("Exception while parsing response")
        print(e)


def start_parsing():
    try:
        # connecting to website
        url = create_get_url(HOME_PAGE_URL)
        meta_data = get_orders_url(url)
        get_records(meta_data)

    except Exception as e:
        print("Exception while parsing page")
        print(e)

    return dict(
        status="ERROR", message="Exception Occured!!", error_type="EXCEPTION"
    )


def create_combinations():
    try:
        print("creating combination")
        start_parsing()
    except Exception as e:
        print("Exception while creating_combination")
        print(e)


def log_script_stats(st, et):
    dt_format = "%Y-%m-%d %H:%M:%S"
    start_time = st.strftime(dt_format)
    end_time = et.strftime(dt_format)
    print(
        "Combinations Created: started at %s and completed at %s"
        % (start_time, end_time)
    )


if __name__ == "__main__":
    start_time = datetime.now()
    create_combinations()
    end_time = datetime.now()
    log_script_stats(start_time, end_time)
    url = base_url + "/notify"
    api_call(url, json.dumps(dict(finished=True)))
