from requests_toolbelt import MultipartEncoder
from bs4 import BeautifulSoup
import http.client
from datetime import datetime
import requests
import json
import os


http.client.MAXHEADERS = 100000
TIMEOUT = 120

HOME_PAGE_URL = "https://maharerait.mahaonline.gov.in/Login/Login"
CAUSELIST_PAGE_URL = "https://maharerait.mahaonline.gov.in"

session = requests.Session()
base_url = "http://localhost:1567"


def create_get_url(base_url, data=dict()):
    if len(data) == 0:
        return base_url
    url = base_url + "?"
    for key, val in data.items():
        url += key + "=" + val + "&"
    return url[:-1]


def soup_creator(url):
    return BeautifulSoup(url.text, "html.parser")


def set_payload(meta_data):
    payload = {
        "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3",
        "Accept-Encoding": "gzip, deflate, br",
        "Accept-Language": "en-GB,en-US;q=0.9,en;q=0.8",
        "Connection": "keep-alive",
        "Cookie": meta_data["cookies"],
        "Host": "maharerait.mahaonline.gov.in",
        "Referer": "https://maharerait.mahaonline.gov.in/Login/Login/",
        "Upgrade-Insecure-Requests": "1",
        "User-Agent": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_5) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/75.0.3770.100 Safari/537.36",
    }
    return payload


def is_int(token):
    try:
        if type(token) == type(int()):
            return False
        return True
    except Exception as e:
        return False


def get_next_page(meta_data):
    print(meta_data)
    payload = set_payload(meta_data)
    response = session.get(meta_data["url"], headers=payload, timeout=TIMEOUT)
    if response.status_code != 200:
        return dict(
            status="ERROR",
            error_type="PRE_LOAD_FAIL",
            message="Failed to load home page!!",
        )
    soup = soup_creator(response)

    print(soup.find("div", {"class": "pagination"}))
    pagination_ul = soup.find("ul", {"class": "pagination"})
    if pagination_ul:
        li = pagination_ul.find_all("li")
        token = li[-1].text
        if is_int(token):
            url = li[-1].find("a")["href"]
            url = meta_data["url"] + url
            return url
        else:
            return None
    else:
        return None


def get_col_data(rows, doc_response):
    data_list = []
    for row in rows:
        data_dict = {}
        cols = row.find_all("td")
        data_dict["s_no"] = cols[0].text.strip()
        data_dict["cmplnt_no"] = cols[1].text.strip()
        data_dict["project_regd_no"] = cols[2].text.strip()
        data_dict["complainant_name"] = cols[3].text.strip()
        data_dict["respondent_name"] = cols[4].text.strip()
        data_dict["next_hearing_date"] = cols[5].text.strip()
        data_dict["stage"] = cols[6].text.strip()
        doc_data = {
            "link": dict(
                content=doc_response.content,
                content_type=doc_response.headers["Content-Type"],
            )
        }
        data = dict(
            export_type="DATA", record_params=data_dict, doc_params=doc_data
        )
        api_data = prepare_export_data(data)
        url = base_url + "/export/data"
        api_call(url, api_data, api_data.content_type)


def get_records(meta_data):

    page_data = {}
    next_page = get_next_page(meta_data)
    page_data["next_page"] = next_page

    payload = set_payload(meta_data)
    response = session.get(meta_data["url"], headers=payload, timeout=TIMEOUT)
    if response.status_code != 200:
        return dict(
            status="ERROR",
            error_type="PRE_LOAD_FAIL",
            message="Failed to load home page!!",
        )
    soup = soup_creator(response)

    table_body = soup.find_all("tbody")
    for tb in table_body:
        rows_1 = tb.find_all("tr")
        get_col_data(rows_1, response)
    return page_data


def prepare_export_data(data):
    params = dict(
        export_type=data["export_type"],
        record_params=data["record_params"],
        doc_params=dict(),
    )
    fields = {}
    if "doc_params" in data:
        for k, v in data["doc_params"].items():
            file_name = k
            params["doc_params"][k] = dict(
                content_type=v["content_type"], file_name=file_name
            )
            file_path = "./" + file_name
            with open(file_path, "wb") as f:
                f.write(v["content"])
            fields[file_name] = (
                file_name,
                open(file_path, "rb"),
                v["content_type"],
            )
            os.system("rm " + file_path)
    fields["params"] = json.dumps(params)
    return MultipartEncoder(fields=fields)


def api_call(url, data, content_type="text/plain"):
    try:
        response = requests.post(
            url=url, data=data, headers={"Content-Type": content_type}
        )
        print(response)
        resp = response.json()
        print(resp)
    except Exception as e:
        print("Exception while parsing response")
        print(e)


def get_causelists(home_url):
    meta_data = {}

    response = session.get(home_url, timeout=TIMEOUT)
    if response.status_code != 200:
        return dict(
            status="ERROR",
            error_type="PRE_LOAD_FAIL",
            message="Failed to load home page!!",
        )
    cookies = response.headers["Set-Cookie"].split(";")
    session_id = cookies[0]
    request_verification = cookies[-3].split(",")[1]
    meta_data["cookies"] = session_id + ";" + request_verification
    soup = soup_creator(response)
    divs = soup.find_all("div", {"class": "search-pro-details"})
    causelist_url = divs[-2].find("a")["href"]
    meta_data["url"] = CAUSELIST_PAGE_URL + causelist_url
    return meta_data


def start_parsing():
    try:
        # connecting to website
        url = create_get_url(HOME_PAGE_URL)
        meta_data = get_causelists(url)
        page_data = get_records(meta_data)
        meta_data["url"] = page_data["next_page"]
        while page_data["next_page"]:
            page_data = get_records(meta_data)

    except Exception as e:
        print("Exception while parsing page")
        print(e)

    return dict(
        status="ERROR", message="Exception Occured!!", error_type="EXCEPTION"
    )


def create_combinations():
    try:
        print("creating combination")
        start_parsing()
    except Exception as e:
        print("Exception while creating_combination")
        print(e)


def log_script_stats(st, et):
    dt_format = "%Y-%m-%d %H:%M:%S"
    start_time = st.strftime(dt_format)
    end_time = et.strftime(dt_format)
    print(
        "Combinations Created: started at %s and completed at %s"
        % (start_time, end_time)
    )


if __name__ == "__main__":
    start_time = datetime.now()
    create_combinations()
    end_time = datetime.now()
    log_script_stats(start_time, end_time)
    url = base_url + "/notify"
    api_call(url, json.dumps(dict(finished=True)))
