from bs4 import BeautifulSoup
from datetime import datetime, timedelta
from threading import Thread
import requests
import boto3
import http.client
import json

AVG_THRESHOLD = 60
PARSED_TILL = "31-12-1989"

http.client._MAXHEADERS = 100000
TIMEOUT = 120

HOME_PAGE_URL = "http://delhihighcourt.nic.in/dhc_case_status_list_new.asp"
JUDGE_URL = "http://lobis.nic.in/judname.php?scode=31"
RECORD_URL = "http://lobis.nic.in/judname1.php?scode=31&fflag=1"
PAGE_URL = "http://lobis.nic.in"
PDF_URL = "http://lobis.nic.in"


ACCESS_KEY = "AKIAJQMKT7WP26VWAKOA"
SECRET_KEY = "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"
QUEUE_URL = "https://sqs.ap-south-1.amazonaws.com/449052551048/delhi_high_court_2"

sqs = boto3.resource(
    "sqs",
    region_name="ap-south-1",
    aws_access_key_id=ACCESS_KEY,
    aws_secret_access_key=SECRET_KEY,
)

session = requests.Session()


def soup_creator(url):
    return BeautifulSoup(url.text, "html.parser")


def feed_sqs(combs):
    # feed sqs here
    print("feeding sqs:")
    print(json.dumps(combs))
    messages = []
    for msg in combs:
        messages.append(msg)
        if len(messages) >= 10:
            Thread(target=send_messages, args=[messages]).start()
            messages = []
    if len(messages) > 0:
        Thread(target=send_messages, args=[messages]).start()


def send_messages(messages):
    entries = []
    i = 1
    for msg in messages:
        entries.append({"Id": str(i), "MessageBody": json.dumps(msg)})
        i += 1
    queue = sqs.Queue(QUEUE_URL)
    queue.send_messages(Entries=entries)


def get_count(url):
    response = session.get(url)
    if response.status_code != 200:
        print("Failed to load page")
        return
    # token_dict["cookie"] = response.headers["Set-Cookie"].split(";")[0]
    soup = soup_creator(response)
    count = soup.find("span", {"class": "search-count"}).text.split(":")[1].strip()
    return int(count)


def create_sqs_comb(count):
    combs = []
    for idx in range(0, count, 8):
        comb_dict = {"records": idx}
        combs.append(comb_dict)
    return combs


def start_parsing(start_date, end_date):
    try:
        count = get_count(HOME_PAGE_URL)
        combs = create_sqs_comb(count)
        print("Combinations Create:", len(combs))
        feed_sqs(combs)
    except Exception as e:
        print("Exception while creating combination")
        print(e)
        pass


def create_combinations(start_date, end_date):
    try:
        print("creating combination")
        start_parsing(start_date, end_date)
    except Exception as e:
        print("Exception while creating_combination")
        print(e)


if __name__ == "__main__":
    # fetch high court mapping from the database, create date-range combinations for the same.
    # after create combination insert them to sqs queue.
    start_date = "01/01/1950"
    end_date = "18/10/2019"
    create_combinations(start_date, end_date)
