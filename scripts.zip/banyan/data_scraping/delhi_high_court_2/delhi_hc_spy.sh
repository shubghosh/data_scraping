#!/bin/bash
  
if [[ $(ps -ef | grep "python3 scraper_2.py"| grep -v grep) ]]
then
        echo ""
else
        echo "starting  high court scraper_2.py"
        python3 scraper_2.py
fi