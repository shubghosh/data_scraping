from bs4 import BeautifulSoup
import http.client
from datetime import datetime
import requests
import boto3
import json
import hashlib
from pymongo import MongoClient

http.client.MAXHEADERS = 100000
TIMEOUT = 120

# HOME_PAGE_URL = "http://delhihighcourt.nic.in/case.asp"

HOME_PAGE_URL = "http://delhihighcourt.nic.in/dhc_case_status_list_new.asp"
PAGE_URL = "http://delhihighcourt.nic.in/"
PDF_URL = "http://lobis.nic.in"

session = requests.Session()

ACCESS_KEY = "AKIAJQMKT7WP26VWAKOA"
SECRET_KEY = "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"
QUEUE_URL = "https://sqs.ap-south-1.amazonaws.com/449052551048/delhi_high_court_2"

sqs = boto3.resource(
    "sqs",
    region_name="ap-south-1",
    aws_access_key_id=ACCESS_KEY,
    aws_secret_access_key=SECRET_KEY,
)

SISYPHUS_AWS_ACCESS_KEY = "AKIAJQMKT7WP26VWAKOA"
SISYPHUS_AWS_SECRET_KEY = "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"
SISYPHUS_AWS_REGION = "ap-south-1"
SISYPHUS_AWS_S3_BUCKET_URL = "https://sisypheans.s3-ap-south-1.amazonaws.com/"
SISYPHUS_AWS_S3_BUCKET = "sisypheans"

s3 = boto3.client(
    "s3",
    aws_access_key_id=SISYPHUS_AWS_ACCESS_KEY,
    aws_secret_access_key=SISYPHUS_AWS_SECRET_KEY,
    region_name=SISYPHUS_AWS_REGION,
)

MONGO_URL = "3.80.136.128:30006"
MONGO_USERNAME = "kagzat"
MONGO_PASSWORD = "q0xoFtVOc2FzefbcZx9m5yzWNp49tsOH0GNAnQHD1Be1C2h/6eVE/XkW1eqqGnB8"
MONGO_AUTH_SOURCE = "admin"
DB_NAME = "sisyphus_prod_scraping"
COL_NAME = "delhi_high_court_2"


def get_collection(db_name, col_name):
    client = MongoClient(
        MONGO_URL,
        username=MONGO_USERNAME,
        password=MONGO_PASSWORD,
        authSource=MONGO_AUTH_SOURCE,
    )
    db = client[db_name]
    return db[col_name]


def create_get_url(base_url, data=dict()):
    if len(data) == 0:
        return base_url
    url = base_url + "?"
    for key, val in data.items():
        url += key + "=" + val + "&"
    return url[:-1]


def soup_creator(url):
    return BeautifulSoup(url.text, "lxml")


def set_payload(cookie):
    payload = {"Cookie": cookie}
    return payload


def set_form_data(comb_dict):
    form_data = {
        "ctype": comb_dict["judge_id"],
        "frdate": comb_dict["start_date"],
        "todate": comb_dict["end_date"],
        "Submit": "Submit",
    }
    return form_data


def set_query_params(rec):
    params = {
        "ayear": "",
        "pyear": "",
        "SNo": "",
        "SRecNo": str(rec),
        "dno": "",
        "dyear": "",
        "ctype_29": "",
        "cno": "",
        "cyear": "",
        "party": "",
        "adv": "",
    }
    return params


def get_span_data(spans, doc_response):
    data_dict = {}
    try:
        data_dict["s_no"] = spans[0].text.strip()
        data_dict["case_no"] = (
            spans[1].text.strip().split("\n")[0].replace("\r", "").replace("\xa0", "")
        )
        data_dict["petitioner"] = (
            spans[2].text.strip().split("Vs.")[0].split("\n")[0].strip()
        )
        data_dict["respondent"] = (
            spans[2]
            .text.strip()
            .split("Vs.")[1]
            .replace("\xa0", "")
            .split("Advocate :")[0]
            .strip()
        )
        data_dict["advocate_name"] = (
            spans[2]
            .text.strip()
            .split("Vs.")[1]
            .replace("\xa0", "")
            .split("Advocate :")[1]
            .strip()
        )
        data_dict["court_no"] = (
            spans[3].text.strip().replace("\r", "").replace("\t", "").replace("\n", "")
        )
        data_dict["elastic"] = 0
        data_dict["status"] = 0
        data_dict["backup"] = 0
        data_dict["sisyphean_id"] = ""
        data_dict["event_id"] = ""
        data_dict["status"] = ""
        data_dict["pdf_url"] = ""
        data_dict["court_name"] = "Delhi High Court"
        if spans[1].find("button"):
            data_dict["pdf_url"] = (
                PAGE_URL + spans[1].find("button")["onclick"].split("'")[1]
            )
        if spans[1].find("font"):
            data_dict["status"] = (
                spans[1].find("font").text.strip().split("]")[0].split("[")[1]
            )
        result = hashlib.md5(
            str(data_dict["s_no"]).encode()
            + str(data_dict["case_no"]).encode()
            + str(data_dict["petitioner"]).encode()
            + str(data_dict["respondent"]).encode()
            + str(data_dict["status"]).encode()
            + str(data_dict["pdf_url"]).encode()
            + str(data_dict["court_no"]).encode()
            + str(data_dict["advocate_name"]).encode()
        )

        data_dict["md5"] = result.hexdigest()

        s3.put_object(
            Bucket=SISYPHUS_AWS_S3_BUCKET,
            Key=data_dict["md5"],
            Body=doc_response.content,
            ACL="public-read",
            ContentType="text/html",
            ContentDisposition="inline",
        )
        data_dict["link"] = SISYPHUS_AWS_S3_BUCKET_URL + data_dict["md5"]
        return data_dict
    except Exception as e:
        print("Exception occured at")
        print(e)


def store_data(items):
    try:
        col = get_collection(DB_NAME, COL_NAME)
        max_allowed = 8
        done = 0
        # print(len(items))
        if len(items) > 1:
            while done < len(items):
                try:
                    r = col.insert_many(items[done : done + max_allowed], ordered=False)
                    print(r)
                except Exception as e:
                    # print(items[done:done + max_allowed])
                    print("error while inserting many")
                    print(e)
                    pass
                done += max_allowed
        if len(items) == 1:
            col.insert_one(items[0])
    except Exception as e:
        print("Exception while storing data to db")
        print(e)


def get_records(token_dict, comb_dict):
    if comb_dict:
        data_list = []
        params = set_query_params(comb_dict["records"])
        payload = set_payload(token_dict["cookie"])
        response = session.get(HOME_PAGE_URL, params=params, headers=payload)
        if response.status_code != 200:
            print("Failed to load page", params)
            return
        soup = soup_creator(response)
        li_tags = soup.find("ul", {"class": "clearfix grid"}).find_all("li")
        for li in li_tags:
            spans = li.find_all("span")
            data_dict = get_span_data(spans, response)
            data_list.append(data_dict)
        # print(data_list)
        store_data(data_list)
        print(len(data_list), "records inserted for", comb_dict["records"])


def get_cookie(url):
    token_dict = {}
    response = session.get(url)
    if response.status_code != 200:
        print("Failed to load page")
        return
    token_dict["cookie"] = response.headers["Set-Cookie"].split(";")[0]
    return token_dict


def read_queue_and_start():
    token_dict = get_cookie(HOME_PAGE_URL)
    # comb_data = {}
    # get_records(token_dict, comb_data)
    queue = sqs.Queue(QUEUE_URL)
    messages = queue.receive_messages()
    while len(messages) > 0:
        for message in messages:
            comb_data = json.loads(message.body)
            # for logging purpose
            print(comb_data)
            get_records(token_dict, comb_data)
            message.delete()
        messages = queue.receive_messages()


def start_parsing():
    try:
        # read_queue_and_start()
        col = get_collection(DB_NAME, COL_NAME)
        col.remove({})
    except Exception as e:
        print("Exception while parsing page")
        print(e)
    return dict(status="ERROR", message="Exception Occured!!", error_type="EXCEPTION")


def create_combinations():
    try:
        print("creating combination")
        start_parsing()
    except Exception as e:
        print("Exception while creating_combination")
        print(e)


def log_script_stats(st, et):
    dt_format = "%Y-%m-%d %H:%M:%S"
    start_time = st.strftime(dt_format)
    end_time = et.strftime(dt_format)
    print(
        "Combinations Created: started at %s and completed at %s"
        % (start_time, end_time)
    )


if __name__ == "__main__":
    start_time = datetime.now()
    create_combinations()
    end_time = datetime.now()
    log_script_stats(start_time, end_time)
