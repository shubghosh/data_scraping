#!/bin/bash
  
if [[ $(ps -ef | grep "python3 scraper_db.py"| grep -v grep) ]]
then
        echo ""
else
        echo "starting  high court scraper_db.py"
        python3 scraper.py
fi