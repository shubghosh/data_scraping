from bs4 import BeautifulSoup
import http.client
from datetime import datetime
import requests
import boto3
import json
import hashlib
from pymongo import MongoClient

http.client.MAXHEADERS = 100000
TIMEOUT = 120

# HOME_PAGE_URL = "http://delhihighcourt.nic.in/case.asp"

HOME_PAGE_URL = "https://bombayhighcourt.nic.in/case_query.php"
JUDGE_URL = "http://lobis.nic.in/judname.php?scode=31"
RECORD_URL = "https://bombayhighcourt.nic.in/casequery_action.php"
PAGE_URL = "http://lobis.nic.in"
PDF_URL = "https://bombayhighcourt.nic.in/"

session = requests.Session()

ACCESS_KEY = "AKIAJQMKT7WP26VWAKOA"
SECRET_KEY = "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"
QUEUE_URL = "https://sqs.ap-south-1.amazonaws.com/449052551048/bombay_high_court"

sqs = boto3.resource(
    "sqs",
    region_name="ap-south-1",
    aws_access_key_id=ACCESS_KEY,
    aws_secret_access_key=SECRET_KEY,
)

SISYPHUS_AWS_ACCESS_KEY = "AKIAJQMKT7WP26VWAKOA"
SISYPHUS_AWS_SECRET_KEY = "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"
SISYPHUS_AWS_REGION = "ap-south-1"
SISYPHUS_AWS_S3_BUCKET_URL = "https://sisypheans.s3-ap-south-1.amazonaws.com/"
SISYPHUS_AWS_S3_BUCKET = "sisypheans"

s3 = boto3.client(
    "s3",
    aws_access_key_id=SISYPHUS_AWS_ACCESS_KEY,
    aws_secret_access_key=SISYPHUS_AWS_SECRET_KEY,
    region_name=SISYPHUS_AWS_REGION,
)

MONGO_URL = "3.80.136.128:30006"
MONGO_USERNAME = "kagzat"
MONGO_PASSWORD = "q0xoFtVOc2FzefbcZx9m5yzWNp49tsOH0GNAnQHD1Be1C2h/6eVE/XkW1eqqGnB8"
MONGO_AUTH_SOURCE = "admin"
DB_NAME = "sisyphus_prod_scraping"
COL_NAME = "bombay_high_court"


def get_collection(db_name, col_name):
    client = MongoClient(
        MONGO_URL,
        username=MONGO_USERNAME,
        password=MONGO_PASSWORD,
        authSource=MONGO_AUTH_SOURCE,
    )
    db = client[db_name]
    return db[col_name]


def create_get_url(base_url, data=dict()):
    if len(data) == 0:
        return base_url
    url = base_url + "?"
    for key, val in data.items():
        url += key + "=" + val + "&"
    return url[:-1]


def soup_creator(url):
    return BeautifulSoup(url.text, "lxml")


def set_dict():
    data_dict = {
        "case_no": "",
        "pdf_url": "",
        "petitioner": "",
        "respondent": "",
        "elastic": "",
        "status": "",
        "backup": "",
        "sisyphean_id": "",
        "event_id": "",
        "presentation_date": "",
        "stamp_no": "",
        "filing_date": "",
        "reg_no": "",
        "reg_date": "",
        "petitioners": [],
        "respondents": [],
        "petitioners_advs": [],
        "dist_name": "",
        "bench": "",
        "status": "",
        "next_date": "",
        "stage": "",
        "act": "",
    }

    return data_dict


def set_payload(cookie):
    payload = {"Cookie": cookie}
    return payload


def set_form_data(comb_dict):
    form_data = {
        "m_hc": "01",
        "m_sideflg": "C",
        "m_sr": "R",
        "m_skey": "AO",
        "m_no": "",
        "m_yr": "",
        "frmdate": comb_dict["start_date"],
        "todate": comb_dict["end_date"],
        "submit11": "List By Case Type",
    }
    return form_data


def get_table_data_1(table, data_dict):
    try:
        data_dict["presentation_date"] = table.find_all("tr")[0].text.split(":-")[1]
        data_dict["stamp_no"] = table.find_all("tr")[2].find_all("td")[2].text.strip()
        data_dict["filing_date"] = (
            table.find_all("tr")[2].find_all("td")[4].text.strip()
        )
        data_dict["reg_no"] = table.find_all("tr")[2].find_all("td")[6].text.strip()
        data_dict["reg_date"] = table.find_all("tr")[2].find_all("td")[8].text.strip()
    except Exception as e:
        print("In table 1")
        print(e)
    return data_dict


def get_table_data_3(table, data_dict):
    try:
        pets = table.find("select", {"name": "m_petno"}).find_all("option")
        for pet in pets:
            data_dict["petitioners"].append(pet.text.strip())
        resps = table.find("select", {"name": "m_resno"}).find_all("option")
        for resp in resps:
            data_dict["respondents"].append(resp.text.strip())
    except Exception as e:
        print("In table 3")
        print(e)
    return data_dict


def get_table_data_4(table, data_dict):
    try:
        pets_adv = table.find("select", {"name": "m_padv"}).find_all("option")
        for pet in pets_adv:
            data_dict["petitioners_advs"].append(pet.text.strip().replace("\xa0", ""))
    except Exception as e:
        print("In table 4")
        print(e)
    return data_dict


def get_table_data_5(table, data_dict):
    try:
        data_dict["dist_name"] = table.find_all("tr")[0].find_all("td")[2].text.strip()
    except Exception as e:
        print("In table 5")
        print(e)
    return data_dict


def get_table_data_7(table, data_dict):
    try:
        data_dict["bench"] = table.find_all("tr")[0].find_all("td")[2].text.strip()
        data_dict["status"] = table.find_all("tr")[1].find_all("td")[2].text.strip()
    except Exception as e:
        print("In table 7")
        print(e)
    return data_dict


def get_table_data_8(table, data_dict):
    try:
        data_dict["next_date"] = table.find_all("tr")[0].find_all("td")[2].text.strip()
        data_dict["stage"] = table.find_all("tr")[0].find_all("td")[4].text.strip()
    except Exception as e:
        print("In table 8")
        print(e)
    return data_dict


def get_table_data_13(table, data_dict):
    try:
        data_dict["act"] = table.find_all("tr")[0].find_all("td")[2].text.strip()
    except Exception as e:
        print("In table 13")
        print(e)
    return data_dict


def get_table_data_14(table, data_dict):
    try:
        data_dict["act"] = (
            data_dict["act"]
            + " "
            + table.find_all("tr")[1].find_all("td")[1].text.strip()
        )
    except Exception as e:
        print("In table 14")
        print(e)
    return data_dict


def get_table_data_15(table, data_dict):
    try:
        data_dict["act"] = (
            data_dict["act"]
            + " "
            + table.find_all("tr")[1].find_all("td")[1].text.strip()
        )
    except Exception as e:
        print("In table 15")
        print(e)
    return data_dict


def get_case_data(data_dict, cookie):
    token_dict = get_cookie(HOME_PAGE_URL)
    payload = set_payload(token_dict["cookie"])
    response = session.get(data_dict["pdf_url"], headers=payload)
    if response.status_code != 200:
        print("Failed to load page")
        return
    soup = soup_creator(response)
    try:
        tables = soup.find("form").find_all("table")[2:]
        
        data_dict = get_table_data_1(tables[0], data_dict)
        data_dict = get_table_data_3(tables[2], data_dict)
        data_dict = get_table_data_4(tables[3], data_dict)
        data_dict = get_table_data_5(tables[4], data_dict)
        data_dict = get_table_data_7(tables[6], data_dict)
        data_dict = get_table_data_8(tables[7], data_dict)
        data_dict = get_table_data_13(tables[12], data_dict)
        data_dict = get_table_data_14(tables[13], data_dict)
        data_dict = get_table_data_15(tables[14], data_dict)
    except Exception as e:
        print("Exception occured in Case data", e)
    return data_dict, response


def get_col_data(cols, cookie):
    data_dict = set_dict()
    try:
        if cols:
            data_dict["case_no"] = cols[0].text.strip()
            data_dict["pdf_url"] = PDF_URL + cols[0].find("a")["href"]
            data_dict["petitioner"] = cols[1].text.strip().split("Vs.")[0]
            data_dict["respondent"] = cols[1].text.strip().split("Vs.")[1]
            data_dict["elastic"] = 0
            data_dict["status"] = 0
            data_dict["backup"] = 0
            data_dict["sisyphean_id"] = ""
            data_dict["event_id"] = ""
            data_dict, response = get_case_data(data_dict, cookie)
            result = hashlib.md5(
                str(data_dict["case_no"]).encode()
                + str(data_dict["pdf_url"]).encode()
                + str(data_dict["petitioner"]).encode()
                + str(data_dict["respondent"]).encode()
            )

            data_dict["md5"] = result.hexdigest()

            s3.put_object(
                Bucket=SISYPHUS_AWS_S3_BUCKET,
                Key=data_dict["md5"],
                Body=response.content,
                ACL="public-read",
                ContentType="text/html",
                ContentDisposition="inline",
            )
            data_dict["link"] = SISYPHUS_AWS_S3_BUCKET_URL + data_dict["md5"]
            return data_dict
        else:
            return {}
    except Exception as e:
        print("Exception occured at", e)
    return {}


def store_data(items):
    try:
        col = get_collection(DB_NAME, COL_NAME)
        max_allowed = 200
        done = 0
        # print(len(items))
        if len(items) > 1:
            while done < len(items):
                try:
                    r = col.insert_many(items[done : done + max_allowed], ordered=False)
                    print(r)
                except Exception as e:
                    # print(items[done:done + max_allowed])
                    print("error while inserting many")
                    print(e)
                    pass
                done += max_allowed
        if len(items) == 1:
            col.insert_one(items[0])
    except Exception as e:
        print("Exception while storing data to db")
        print(e)


def check_data_length(data):
    if len(data) >= 200:
        return True
    return False


def get_records(token_dict, comb_dict):
    print("In get records")
    payload = set_payload(token_dict["cookie"])
    if comb_dict:
        data = []
        data_list = []
        form_data = set_form_data(comb_dict)
        response = session.post(RECORD_URL, data=form_data, headers=payload)
        if response.status_code != 200:
            print("Failed to load page for judge with code")
            return
        soup = soup_creator(response)
        if soup.find("font", {"color": "red"}):
            if "No Record Found" in soup.find("font", {"color": "red"}).text.strip():
                print("No Records")
                return
        rows = soup.find_all("table")[-1].find_all("tr")[4:]
        for row in rows:
            cols = row.find_all("td")
            data_dict = get_col_data(cols, token_dict["cookie"])
            if data_dict:
                print(data_dict)
                data_list.append(data_dict)
        print("Length of data list", len(data_list))
        data.extend(data_list)
        if check_data_length(data):
            print(data)
            store_data(data)
            print(len(data), "records inserted")
            data = []
    if data:
        store_data(data)
        print(len(data), "records inserted")
        data = []
        data_list = []


def get_cookie(url):
    token_dict = {}
    response = session.get(url)
    if response.status_code != 200:
        print("Failed to load page")
        return
    cookies = response.headers["Set-Cookie"].split(",")[:-1]
    c = ""
    for cookie in cookies:
        c = c + cookie.split(";")[0] + "; "
    token_dict["cookie"] = c.strip()[:-1]
    # soup = soup_creator(response)
    # token_dict["input_digit"] = soup.find("input", {"id": "hiddeninputdigit"})["value"]
    return token_dict


def read_queue_and_start():

    token_dict = get_cookie(HOME_PAGE_URL)
    # comb_data = {'start_date': '18-08-2019', 'end_date': '16-11-2019'}
    # get_records(token_dict, comb_data)
    queue = sqs.Queue(QUEUE_URL)
    messages = queue.receive_messages()
    while len(messages) > 0:
        for message in messages:
            comb_data = json.loads(message.body)
            # for logging purpose
            print(comb_data)
            get_records(token_dict, comb_data)
            message.delete()
        messages = queue.receive_messages()


def start_parsing():
    try:
        read_queue_and_start()
        # col = get_collection(DB_NAME, COL_NAME)
        # col.remove({})
    except Exception as e:
        print("Exception while parsing page")
        print(e)
    return dict(status="ERROR", message="Exception Occured!!", error_type="EXCEPTION")


def create_combinations():
    try:
        print("creating combination")
        start_parsing()
    except Exception as e:
        print("Exception while creating_combination")
        print(e)


def log_script_stats(st, et):
    dt_format = "%Y-%m-%d %H:%M:%S"
    start_time = st.strftime(dt_format)
    end_time = et.strftime(dt_format)
    print(
        "Combinations Created: started at %s and completed at %s"
        % (start_time, end_time)
    )


if __name__ == "__main__":
    start_time = datetime.now()
    create_combinations()
    end_time = datetime.now()
    log_script_stats(start_time, end_time)
