from requests_toolbelt import MultipartEncoder
from pymongo import MongoClient
from bs4 import BeautifulSoup
import http.client
from datetime import datetime
import requests
import os
import json
import hashlib

http.client.MAXHEADERS = 100000
TIMEOUT = 120

HOME_PAGE_URL = "https://njdg.ecourts.gov.in/njdgnew/?p=main"
YEAR_URL = "https://njdg.ecourts.gov.in/njdgnew/?p=report/fetchYearData"
STATE_URL = "https://njdg.ecourts.gov.in/njdgnew/?p=report/fetchData"
DISTRICT_URL = "https://njdg.ecourts.gov.in/njdgnew/?p=report/fetchDist"
EST_URL = "https://njdg.ecourts.gov.in/njdgnew/?p=report/fetchEst"
CASE_URL = "https://njdg.ecourts.gov.in/njdgnew/?p=report/fetchCases"
DATA_URL = "https://njdg.ecourts.gov.in/njdgv1/civil/o_civil_case_history_es.php"

session = requests.Session()
base_url = "http://localhost:1567"

MONGO_URL = "3.80.136.128:30006"
MONGO_USERNAME = "kagzat"
MONGO_PASSWORD = "q0xoFtVOc2FzefbcZx9m5yzWNp49tsOH0GNAnQHD1Be1C2h/6eVE/XkW1eqqGnB8"
MONGO_AUTH_SOURCE = "admin"
DB_NAME = "sisyphus_prod_scraping"
# COL_NAME = "combinations_4bcf7df92e8a7f26ce842805be0e2cb7"
COL_NAME = "ecourt_combinations"


def get_collection(db_name, col_name):
    client = MongoClient(
        MONGO_URL,
        username=MONGO_USERNAME,
        password=MONGO_PASSWORD,
        authSource=MONGO_AUTH_SOURCE,
    )
    db = client[db_name]
    return db[col_name]


def soup_creator(url):
    return BeautifulSoup(url, "lxml")


def set_year_form():
    return {"tot": "tot", "val": "1", "ajax_req": "true"}


def parse_response(response):
    params_list = []
    try:
        d = json.loads(response.text)
        soup = soup_creator(d["reportrow"])
        rows = soup.find("tbody").find_all("tr")
        for row in rows:
            cols = row.find_all("td")
            params = cols[-1].find("a")["href"].split("(")[1].split(")")[0]
            params = params.split(",")
            params_list.append(params)
    except Exception as e:
        print(e)
    return params_list


def get_year_data():
    response = session.post(YEAR_URL, data=set_year_form())
    if response.status_code != 200:
        print("Failed to load Year page")
        return
    params_list = parse_response(response)
    data_list = []
    for params in params_list:
        data_dict = {}
        data_dict["total"] = params[1].replace("'", "")
        data_dict["val"] = params[2].replace("'", "")
        data_dict["year"] = params[3].replace("'", "")
        data_dict["ajax_req"] = True
        data_list.append(data_dict)
    return data_list


def store_data(items):
    try:
        col = get_collection(DB_NAME, COL_NAME)
        max_allowed = 8
        done = 0
        # print(len(items))
        if len(items) > 1:
            while done < len(items):
                try:
                    r = col.insert_many(items[done : done + max_allowed], ordered=False)
                    print(r)
                except Exception as e:
                    # print(items[done:done + max_allowed])
                    print("error while inserting many")
                    print(e)
                    pass
                done += max_allowed
        if len(items) == 1:
            col.insert_one(items[0])
    except Exception as e:
        print("Exception while storing data to db")
        print(e)


def get_state_data(data_list):
    state_list = []
    # for dl in data_list:
    year = datetime.now().year
    response = session.post(
        STATE_URL, data={
            "total": "tot",
            "val": "1",
            "year": str(year),
            "ajax_req": True
        }
    )
    if response.status_code != 200:
        print("Failed To Load State Page")
        # continue
    params_list = parse_response(response)
    for params in params_list:
        data_dict = {}
        data_dict["state_name"] = params[2].replace("'", "")
        data_dict["ci_cri"] = "1"
        data_dict["col_name"] = "tot"
        data_dict["year"] = (
                params[0].replace("'", "").replace("/", "").replace(" ", "")
            )
        data_dict["label"] = params[0].replace("'", "")
        data_dict["ajax_req"] = True
        state_list.append(data_dict)
    return state_list


def get_dist_data(state_list):
    dist_list = []
    for state in state_list:
        response = session.post(DISTRICT_URL, data=state)
        if response.status_code != 200:
            print("Failed To Load State Page", state)
            continue
        params_list = parse_response(response)
        for params in params_list:
            data_dict = {}
            data_dict["dist_name"] = params[2].replace("'", "")
            data_dict["get_state_name"] = params[0].replace("'", "").split("/")[2][1:]
            data_dict["ci_cri"] = "1"
            data_dict["col_name"] = "tot"
            data_dict["year"] = params[0].replace("'", "").split("/")[1][1:-1]
            data_dict["label"] = params[0].replace("'", "")
            data_dict["ajax_req"] = True
            dist_list.append(data_dict)
    return dist_list


def get_est_data(dist_list):
    est_list = []
    for dist in dist_list:
        response = session.post(EST_URL, data=dist)
        if response.status_code != 200:
            print("Failed To Load State Page", dist)
            continue
        try:
            params_list = parse_response(response)
            for params in params_list:
                data_dict = {}
                data_dict["year"] = params[0].replace("'", "").split("/")[1][1:-1]
                data_dict["est_code"] = params[1].replace("'", "")
                data_dict["get_dist_name"] = params[0].replace("'", "").split("/")[3][1:]
                data_dict["get_state_name"] = params[0].replace("'", "").split("/")[2][1:-1]
                data_dict["ci_cri"] = "1"
                data_dict["col_name"] = "tot"
                data_dict["label"] = params[0].replace("'", "")
                data_dict["ajax_req"] = True
                data_dict["sisyphean_id"] = "4bcf7df92e8a7f26ce842805be0e2cb7"
                data_dict["event_id"] = "50fafa8f9861d641ad08bc20bb06bbe7"
                data_dict["data_inserted_on"] = datetime.utcnow()
                data_dict["elastic"] = 0
                data_dict["status"] = 0
                data_dict["backup"] = 0
                # print(data_dict)
                
                result = hashlib.md5(
                    str(data_dict["year"]).encode()
                    + str(data_dict["est_code"]).encode()
                    + str(data_dict["get_dist_name"]).encode()
                    + str(data_dict["get_state_name"]).encode()
                    + str(data_dict["ci_cri"]).encode()
                    + str(data_dict["col_name"]).encode()
                    + str(data_dict["label"]).encode()
                    + str(data_dict["ajax_req"]).encode()
                )

                data_dict["md5"] = result.hexdigest()
                est_list.append(data_dict)
                # data = dict(export_type="DATA", record_params=data_dict, doc_params={})
                # api_data = prepare_export_data(data)
                # url = base_url + "/export/data"
                # api_call(url, api_data, api_data.content_type)
        except Exception as e:
            print(params_list)
            print(e)
        # print(dist)
        # print(len(est_list))
    return est_list


def get_combs_data(est_list):
    for est in est_list:
        print(est)
        response = session.post(CASE_URL, data=est)
        if response.status_code != 200:
            print("Failed To Load State Page", est)
            continue
        params_list = parse_response(response)
        # print(params_list)
        for params in params_list:
            try:
                data_dict = {}
                data_dict["es_flag"] = "Y"
                data_dict["state_code"] = params[7].replace("'", "")
                data_dict["dist_code"] = params[8].replace("'", "")
                data_dict["court_code"] = params[9].replace("'", "")
                data_dict["case_number"] = params[3].replace("'", "")
                data_dict["type"] = "both"
                data_dict["objection1"] = "totalpending_cases"
                data_dict["matchtotal"] = "13145"
                data_dict["jocode"] = params[6].replace("'", "")
                data_dict["court_no"] = params[5].replace("'", "")
                data_dict["cino"] = params[4].replace("'", "")
                data_dict["disposed_case"] = "N"
                print(data_dict)
                # data = dict(export_type="DATA", record_params=data_dict, doc_params={})
                # api_data = prepare_export_data(data)
                # url = base_url + "/export/data"
                # api_call(url, api_data, api_data.content_type)
            except Exception as e:
                print(e)


def prepare_export_data(data):
    params = dict(
        export_type=data["export_type"],
        record_params=data["record_params"],
        doc_params=dict(),
    )
    fields = {}
    if "doc_params" in data:
        for k, v in data["doc_params"].items():
            file_name = k
            params["doc_params"][k] = dict(
                content_type=v["content_type"], file_name=file_name
            )
            file_path = "./" + file_name
            with open(file_path, "wb") as f:
                f.write(v["content"])
            fields[file_name] = (file_name, open(file_path, "rb"), v["content_type"])
            os.system("rm " + file_path)
    fields["params"] = json.dumps(params)
    return MultipartEncoder(fields=fields)


def api_call(url, data, content_type="text/plain"):
    try:
        response = requests.post(
            url=url, data=data, headers={"Content-Type": content_type}
        )
        print(response)
        resp = response.json()
        print(resp)
    except Exception as e:
        print("Exception while parsing response")
        print(e)


def start_parsing():
    try:
        # connecting to website
        # year_list = get_year_data()
        # print(len(year_list), "Records in year_list")
        state_list = get_state_data([])
        print(len(state_list), "Records in state_list")
        dist_list = get_dist_data(state_list)
        print(len(dist_list), "Records in dist_list")
        est_list = get_est_data(dist_list)
        print(len(est_list), "Records in est_list")
        store_data(est_list)
        # get_combs_data(est_list)
    except Exception as e:
        print("Exception while parsing page")
        print(e)

    return dict(status="ERROR", message="Exception Occured!!", error_type="EXCEPTION")


def create_combinations():
    try:
        print("creating combination")
        col = get_collection(DB_NAME, COL_NAME)
        col.remove()
        # start_parsing()
    except Exception as e:
        print("Exception while creating_combination")
        print(e)


def log_script_stats(st, et):
    dt_format = "%Y-%m-%d %H:%M:%S"
    start_time = st.strftime(dt_format)
    end_time = et.strftime(dt_format)
    print(
        "Combinations Created: started at %s and completed at %s"
        % (start_time, end_time)
    )


if __name__ == "__main__":
    start_time = datetime.now()
    create_combinations()
    end_time = datetime.now()
    log_script_stats(start_time, end_time)
    # url = base_url + "/notify"
    # api_call(url, json.dumps(dict(finished=True)))
