from bs4 import BeautifulSoup
import http.client
import re 
from datetime import datetime
import hashlib
import requests
import json
import subprocess
import os
import itertools
import boto3


http.client.MAXHEADERS = 100000
TIMEOUT = 120

HOME_PAGE_URL = 'https://indiankanoon.org/search/?formInput=blacklisting%20contractors'
# JUDGEMENT_PAGE_URL = 'http://moneylaundering.legal/'
PAGE_URL = 'https://indiankanoon.org'

session = requests.Session()

def create_get_url(base_url, data=dict()):
    if len(data) == 0:
        return base_url
    url = base_url + '?'
    for key, val in data.items():
        url += key + '=' + val + '&'
    return url[:-1]

def soup_creator(url):
    return BeautifulSoup(url.text, 'html.parser')


def get_next_page(url):
    next_page = ''
    response = session.get(url, timeout=TIMEOUT)
    if response.status_code != 200:
        print('Failed to load home page!!')
    soup = soup_creator(response)
    next_page = soup.find('div',{'class':'bottom'}).find_all('a')
    text = next_page[-1].text.strip()
    if text == 'Next':
        next_page = PAGE_URL + str(next_page[-1]['href'])
        return next_page
    else:
        return None


def get_judgements(url):
    data = {}
    desc_link = []
    next_page = get_next_page(url)
    data['next_page'] = next_page

    response = session.get(url, timeout=TIMEOUT)
    if response.status_code != 200:
        print('Failed to load home page!!')
    soup = soup_creator(response)
    divs = soup.find_all('div',{'class':'result_title'})
    for div in divs:
        a = div.find('a')
        desc_link.append(PAGE_URL + a['href'])
    data['judgement_links'] = desc_link
    return data


def get_judgement_data(urls):
    data_list = []
    for url in urls:
        response = session.get(url)
        if response.status_code != 200:
            print('Failed to load home page!!')
            # return dict(status='ERROR', error_type='PRE_LOAD_FAIL', message='Failed to load home page!!')
        soup = soup_creator(response)
        doc_url = soup.find('div',{'class':'doc_title'}).find('a')
        doc_url = PAGE_URL + doc_url['href']
        data_dict = get_judgement_details(doc_url)
        data_list.append(data_dict)
        break
    return data_list


def get_judgement_details(url):
    data_dict = {}
    response = session.get(url, timeout=TIMEOUT)
    if response.status_code != 200:
        print('Failed to load home page!!')
        # return dict(status='ERROR', error_type='PRE_LOAD_FAIL', message='Failed to load home page!!')
    soup = soup_creator(response)
    div_main = soup.find('div',{'class':'judgments'})
    if div_main == None:
        return data_dict
    data_dict['court'] = div_main.find('div',{'class' : 'docsource_main'}).text
    data_dict['title'] = div_main.find('div',{'class' : 'doc_title'}).text
    data_dict['bench'] = div_main.find('div',{'class' : 'doc_bench'}).text
    data_dict['content'] = div_main.text.strip()
    data_dict['content_type'] = 'text'
    print(data_dict)

    return data_dict


def start_parsing():
    try:
        # connecting to website
        url = create_get_url(HOME_PAGE_URL)
        data = get_judgements(url)
        # print(data) 
        data_list = get_judgement_data(data['judgement_links'])
        print(len(data_list))
        i=1
        # while data['next_page']:
        #     i=i+1
        #     print("--------------------------------------------------------------------------------------------------------------")
        #     data = get_judgements(data['next_page'])
        #     data_list = get_judgement_data(data['judgement_links'])
        #     print(len(data_list))
        # print(i)
    except Exception as e:
        print('Exception while parsing page')
        print(e)
    
    return dict(status='ERROR', message='Exception Occured!!', error_type='EXCEPTION')


def create_combinations():
    try:
        print('creating combination')
        start_parsing()
    except Exception as e:
        print('Exception while creating_combination')
        print(e)


def log_script_stats(st, et):
    dt_format = '%Y-%m-%d %H:%M:%S'
    start_time = st.strftime(dt_format)
    end_time = et.strftime(dt_format)
    print('Combinations Created: started at %s and completed at %s' % (start_time, end_time))


def create_text_file(data_dict):
    s = ''
    with open('input.txt','w') as f:
        t = open('desc.txt','r',encoding="utf-8")
        content = t.readlines()
        for line in content:
            line = line.replace('\n','')
            line = line.replace('\t','')    
            if not line.strip():
                continue
            f.write(line)
            s = s + line
    data_dict['content'] = s
    data_dict['content_type'] = 'text'
    result = hashlib.md5(data_dict['title'].encode() + data_dict['Court'].encode() + data_dict['Citation'].encode()
            + data_dict['content'])
    md5 = result.hexdigest()
    data_dict['md5'] = md5
    
    return data_dict


if __name__ == '__main__':
    start_time = datetime.now()
    create_combinations()
    end_time = datetime.now()
    log_script_stats(start_time, end_time)

