apt-get update

apt-get install gcc -y

# apt-get install python3-pip -y

# apt-get install python-dev python-pip libxml2-dev libxslt1-dev zlib1g-dev libffi-dev libssl-dev -y

pip3 install -r requirements.txt
