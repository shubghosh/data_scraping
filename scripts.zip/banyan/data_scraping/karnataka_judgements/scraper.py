from requests_toolbelt import MultipartEncoder
from bs4 import BeautifulSoup
import http.client
from datetime import datetime
import requests
import json
import os


http.client.MAXHEADERS = 100000
TIMEOUT = 120

HOME_PAGE_URL = "https://kat.karnataka.gov.in/judgements?p_p_id=kiosk_WAR_kaptportlet&p_p_lifecycle=0&p_p_state=normal&p_p_mode=view&p_p_col_id=column-1&p_p_col_count=1&_kiosk_WAR_kaptportlet_action=input&_kiosk_WAR_kaptportlet_tab=Judgement"

session = requests.Session()
base_url = "http://localhost:1567"


def create_get_url(base_url, data=dict()):
    if len(data) == 0:
        return base_url
    url = base_url + "?"
    for key, val in data.items():
        url += key + "=" + val + "&"
    return url[:-1]


def soup_creator(url):
    return BeautifulSoup(url.text, "html.parser")


def set_form_data(section):
    form_data = {
        "searchTypeList": "list",
        "section": "Cooperation",
        "lcoNo": "",
        "lcoAuthority": "",
        "courtHall": "",
        "memberName": "",
        "district": "",
        "appelantName": "",
        "respondentName": "",
        "advocateName": "",
        "fromDate": "01/01/2010",
        "toDate": "",
        "issueId": "",
    }
    return form_data


def set_headers(token):
    data = "; COOKIE_SUPPORT=true; GUEST_LANGUAGE_ID=en_US; ROUTEID=.node1; LFR_SESSION_STATE_20158=1563514943984"
    headers = {"Cookie": token + data}
    return headers


def get_pdf(url, name):
    name = name.replace("/", "_")
    response = session.get(url)
    file_name = "./PDF_Downloads/" + name + ".pdf"
    with open(file_name, "wb") as f:
        f.write(response.content)


def get_data(rows):
    data_dict = {}

    data_dict["case_number"] = rows[0].find("td").text.strip()
    data_dict["judgement_date"] = rows[1].find("td").text.strip()
    data_dict["judgement_by"] = rows[2].find("td").text.strip()
    data_dict["court_hall"] = rows[3].find("td").text.strip()
    data_dict["appellant_name"] = rows[4].find("td").text.strip()
    data_dict["respondent_name"] = rows[5].find("td").text.strip()
    return data_dict


def get_judgement_details(urls):
    data_list = []
    for url in urls:
        response = session.get(url)
        soup = soup_creator(response)
        table = soup.find("table", {"id": "resultTableId"})
        rows = table.find_all("tr")
        data_dict = get_data(rows)
        data_dict["pdf_url"] = soup.find("object", {"class": "pdf-frame"})[
            "data"
        ]
        # get_pdf(data_dict["pdf_url"], data_dict["case_number"])
        # data_list.append(data_dict)
        response_pdf = session.get(data_dict["pdf_url"])
        doc_data = {
            "pdf_link": dict(
                content=response_pdf.content,
                content_type=response_pdf.headers["Content-Type"],
            )
        }
        data = dict(
            export_type="DATA", record_params=data_dict, doc_params=doc_data
        )
        api_data = prepare_export_data(data)
        url = base_url + "/export/data"
        api_call(url, api_data, api_data.content_type)
    return data_list


def prepare_export_data(data):
    params = dict(
        export_type=data["export_type"],
        record_params=data["record_params"],
        doc_params=dict(),
    )
    fields = {}
    if "doc_params" in data:
        for k, v in data["doc_params"].items():
            file_name = k
            params["doc_params"][k] = dict(
                content_type=v["content_type"], file_name=file_name
            )
            file_path = "./" + file_name
            with open(file_path, "wb") as f:
                f.write(v["content"])
            fields[file_name] = (
                file_name,
                open(file_path, "rb"),
                v["content_type"],
            )
            os.system("rm " + file_path)
    fields["params"] = json.dumps(params)
    return MultipartEncoder(fields=fields)


def api_call(url, data, content_type="text/plain"):
    try:
        response = requests.post(
            url=url, data=data, headers={"Content-Type": content_type}
        )
        print(response)
        resp = response.json()
        print(resp)
    except Exception as e:
        print("Exception while parsing response")
        print(e)


def get_judgements(data, section):

    form_data = set_form_data(section)
    headers = set_headers(data["token"])

    response = session.post(data["url"], data=form_data, headers=headers)
    soup = soup_creator(response)
    table = soup.find("table", {"id": "resultTableId"}).find("tbody")
    urls = []
    rows = table.find_all("tr")
    for row in rows:
        url = row.find("a")["href"]
        urls.append(url)
    return urls


def get_tokens(url):
    data = {}
    response = session.get(url, timeout=TIMEOUT, verify=False)
    data["token"] = response.headers["Set-Cookie"].split(";")[0]
    if response.status_code != 200:
        print("Failed to load home page!!")
        return
    soup = soup_creator(response)
    data["url"] = soup.find("div", {"class": "kiosk-search-form"}).find(
        "form"
    )["action"]
    return data


def start_parsing():
    try:
        # connecting to website
        url = create_get_url(HOME_PAGE_URL)
        data = get_tokens(url)
        section_list = ["Cooperation", "Revenue", "Sales Tax"]
        data_dict = {}
        for s in section_list:
            urls = get_judgements(data, s)
            data_dict[s] = get_judgement_details(urls)
        print(data_dict)
        # print(len(data_list))
    except Exception as e:
        print("Exception while parsing page")
        print(e)

    return dict(
        status="ERROR", message="Exception Occured!!", error_type="EXCEPTION"
    )


def create_combinations():
    try:
        print("creating combination")
        start_parsing()
    except Exception as e:
        print("Exception while creating_combination")
        print(e)


def log_script_stats(st, et):
    dt_format = "%Y-%m-%d %H:%M:%S"
    start_time = st.strftime(dt_format)
    end_time = et.strftime(dt_format)
    print(
        "Combinations Created: started at %s and completed at %s"
        % (start_time, end_time)
    )


if __name__ == "__main__":
    start_time = datetime.now()
    create_combinations()
    end_time = datetime.now()
    log_script_stats(start_time, end_time)
    url = base_url + "/notify"
    api_call(url, json.dumps(dict(finished=True)))
