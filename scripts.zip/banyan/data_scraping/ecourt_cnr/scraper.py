from requests_toolbelt import MultipartEncoder
from pymongo import MongoClient
from bs4 import BeautifulSoup
import http.client
from datetime import datetime
import requests
import os
import json

http.client.MAXHEADERS = 100000
TIMEOUT = 120

HOME_PAGE_URL = "https://njdg.ecourts.gov.in/njdgnew/?p=main"
YEAR_URL = "https://njdg.ecourts.gov.in/njdgnew/?p=report/fetchYearData"
STATE_URL = "https://njdg.ecourts.gov.in/njdgnew/?p=report/fetchData"
DISTRICT_URL = "https://njdg.ecourts.gov.in/njdgnew/?p=report/fetchDist"
EST_URL = "https://njdg.ecourts.gov.in/njdgnew/?p=report/fetchEst"
CASE_URL = "https://njdg.ecourts.gov.in/njdgnew/?p=report/fetchCases"
DATA_URL = "https://njdg.ecourts.gov.in/njdgv1/civil/o_civil_case_history_es.php"

MONGO_URL = "3.80.136.128:30006"
MONGO_USERNAME = "kagzat"
MONGO_PASSWORD = "q0xoFtVOc2FzefbcZx9m5yzWNp49tsOH0GNAnQHD1Be1C2h/6eVE/XkW1eqqGnB8"
MONGO_AUTH_SOURCE = "admin"
DB_NAME = "sisyphus_prod_scraping"
COL_NAME = "combinations_4bcf7df92e8a7f26ce842805be0e2cb7"

session = requests.Session()
base_url = "http://localhost:1567"


def soup_creator(url):
    return BeautifulSoup(url, "lxml")


def get_collection(db_name, col_name):
    client = MongoClient(
        MONGO_URL,
        username=MONGO_USERNAME,
        password=MONGO_PASSWORD,
        authSource=MONGO_AUTH_SOURCE,
    )
    return client[db_name][col_name]


def parse_response(response):
    params_list = []
    try:
        d = json.loads(response.text)
        soup = soup_creator(d["reportrow"])
        rows = soup.find("tbody").find_all("tr")
        for row in rows:
            cols = row.find_all("td")
            params = cols[-1].find("a")["href"].split("(")[1].split(")")[0]
            params = params.split(",")
            params_list.append(params)
    except Exception as e:
        print("in parse_response")
        print(e)
        print(response.text)
    return params_list


def fetch_combs():
    col = get_collection(DB_NAME, COL_NAME)
    recs = col.find(
        {},
        {
            "_id": 0,
            "md5": 0,
            "sisyphean_id": 0,
            "event_id": 0,
            "data_inserted_on": 0,
            "elastic": 0,
            "status": 0,
            "backup": 0,
        },
    )
    est_list = []
    for rec in recs:
        est_list.append(rec)
        # store_data(record, cnr_recs)
    return est_list


def get_combs_data(est_list):
    combs_list = []
    for est in est_list:
        response = session.post(CASE_URL, data=est)
        if response.status_code != 200:
            print("Failed To Load State Page", est)
            continue
        params_list = parse_response(response)
        for params in params_list:
            if len(params) > 4:
                try:
                    data_dict = {}
                    data_dict["es_flag"] = "Y"
                    data_dict["state_code"] = params[7].replace("'", "")
                    data_dict["dist_code"] = params[8].replace("'", "")
                    data_dict["court_code"] = params[9].replace("'", "")
                    data_dict["case_number"] = params[3].replace("'", "")
                    data_dict["type"] = "both"
                    data_dict["objection1"] = "totalpending_cases"
                    data_dict["matchtotal"] = "13145"
                    data_dict["jocode"] = params[6].replace("'", "")
                    data_dict["court_no"] = params[5].replace("'", "")
                    data_dict["ci_no"] = params[4].replace("'", "")
                    data_dict["disposed_case"] = "N"
                    combs_list.append(data_dict)
                    data = dict(export_type="DATA", record_params=data_dict, doc_params={})
                    api_data = prepare_export_data(data)
                    url = base_url + "/export/data"
                    api_call(url, api_data, api_data.content_type)
                except Exception as e:
                    print(e)
                    print("in comb data")
                    print(est)
                    print(params)
        print(len(combs_list), "Records Appended")
    return combs_list


def prepare_export_data(data):
    params = dict(
        export_type=data["export_type"],
        record_params=data["record_params"],
        doc_params=dict(),
    )
    fields = {}
    if "doc_params" in data:
        for k, v in data["doc_params"].items():
            file_name = k
            params["doc_params"][k] = dict(
                content_type=v["content_type"], file_name=file_name
            )
            file_path = "./" + file_name
            with open(file_path, "wb") as f:
                f.write(v["content"])
            fields[file_name] = (file_name, open(file_path, "rb"), v["content_type"])
            os.system("rm " + file_path)
    fields["params"] = json.dumps(params)
    return MultipartEncoder(fields=fields)


def api_call(url, data, content_type="text/plain"):
    try:
        response = requests.post(
            url=url, data=data, headers={"Content-Type": content_type}
        )
        print(response)
        resp = response.json()
        print(resp)
    except Exception as e:
        print("Exception while parsing response")
        print(e)


def start_parsing():
    try:
        # connecting to website
        est_list = fetch_combs()
        print(len(est_list), "records Fetched as establisment")
        combs_list = get_combs_data(est_list)
        print(combs_list)
        print(len(combs_list), "records Fetched as combinations")
    except Exception as e:
        print("Exception while parsing page")
        print(e)

    return dict(status="ERROR", message="Exception Occured!!", error_type="EXCEPTION")


def create_combinations():
    try:
        print("creating combination")
        start_parsing()
    except Exception as e:
        print("Exception while creating_combination")
        print(e)


def log_script_stats(st, et):
    dt_format = "%Y-%m-%d %H:%M:%S"
    start_time = st.strftime(dt_format)
    end_time = et.strftime(dt_format)
    print(
        "Combinations Created: started at %s and completed at %s"
        % (start_time, end_time)
    )


if __name__ == "__main__":
    start_time = datetime.now()
    create_combinations()
    end_time = datetime.now()
    log_script_stats(start_time, end_time)
    url = base_url + "/notify"
    api_call(url, json.dumps(dict(finished=True)))
