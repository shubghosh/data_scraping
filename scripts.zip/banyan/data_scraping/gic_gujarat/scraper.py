from requests_toolbelt import MultipartEncoder
from bs4 import BeautifulSoup
import http.client
from datetime import datetime
import requests
import json
import os


http.client.MAXHEADERS = 100000
TIMEOUT = 120

HOME_PAGE_URL = "http://gic.gujarat.gov.in/Default.aspx"
CAUSELIST_URL = "http://gic.gujarat.gov.in/front-page/CauseList.aspx"
DETAILS_URL = "http://gic.gujarat.gov.in/front-page/getPIODetails.aspx"

session = requests.Session()
base_url = "http://localhost:1567"


def create_get_url(base_url, data=dict()):
    if len(data) == 0:
        return base_url
    url = base_url + "?"
    for key, val in data.items():
        url += key + "=" + val + "&"
    return url[:-1]


def soup_creator(url):
    return BeautifulSoup(url.text, "lxml")


def set_form_data(token_data):
    form_data = {
        "ctl00$ScriptManager1": "ctl00$ScriptManager1",
        "ctl00_ScriptManager1_HiddenField": "",
        "__EVENTTARGET": "",
        "__EVENTARGUMENT": "",
        "__VIEWSTATE": token_data["vs"],
        "__VIEWSTATEGENERATOR": "61FF86D9",
        "__EVENTVALIDATION": token_data["ev"],
        "ctl00$Serach": "",
        "ctl00$ContentPlaceHolder1$txtsearch": "19/Aug/2019",
        "ctl00$ContentPlaceHolder1$ddlcourt": "0",
        "ctl00$hid1": "",
        "__ASYNCPOST": "true",
    }
    return form_data


def set_form_data_1(token_data, court, date):
    form_data = {
        "ctl00_ScriptManager1_HiddenField": "",
        "ctl00$Serach": "",
        "ctl00$ContentPlaceHolder1$txtsearch": date,
        "ctl00$ContentPlaceHolder1$ddlcourt": court,
        "ctl00$ContentPlaceHolder1$btnsend": "Search",
        "ctl00$hid1": "",
        "__EVENTTARGET": "",
        "__EVENTARGUMENT": "",
        "__VIEWSTATE": token_data["vs"],
        "__VIEWSTATEGENERATOR": "61FF86D9",
        "__EVENTVALIDATION": token_data["ev"],
    }
    return form_data


def set_form_data_2(token_data, court, date, page):
    form_data = {
        "ctl00$ScriptManager1": "ctl00$ContentPlaceHolder1$upSetSession|ctl00$ContentPlaceHolder1$gvDetails",
        "ctl00_ScriptManager1_HiddenField": "",
        "ctl00$Serach": "",
        "ctl00$ContentPlaceHolder1$txtsearch": date,
        "ctl00$ContentPlaceHolder1$ddlcourt": court,
        "ctl00$hid1": "",
        "__EVENTTARGET": "ctl00$ContentPlaceHolder1$gvDetails",
        "__EVENTARGUMENT": "Page$" + str(page),
        "__VIEWSTATE": token_data["vs"],
        "__VIEWSTATEGENERATOR": "61FF86D9",
        "__EVENTVALIDATION": token_data["ev"],
        "__ASYNCPOST": "true",
    }
    return form_data


def set_payload_causelist_1():
    payload = {
        "Cache-Control": "no-cache",
        "Content-Type": "application/x-www-form-urlencoded; charset=UTF-8",
        "Referer": "http://gic.gujarat.gov.in/front-page/CauseList.aspx",
        "User-Agent": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_5) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/76.0.3809.100 Safari/537.36",
        "X-MicrosoftAjax": "Delta=true",
        "X-Requested-With": "XMLHttpRequest",
    }

    return payload


def set_payload(token_data):
    payload = {"Cookie": token_data["cookie"]}
    return payload


def set_payload_causelist_2(token_data):
    payload = {
        "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3",
        "Accept-Encoding": "gzip, deflate",
        "Accept-Language": "en-GB,en-US;q=0.9,en;q=0.8",
        "Cache-Control": "max-age= 0",
        "Connection": "keep-alive",
        "Content-Length": "10619",
        "Content-Type": "application/x-www-form-urlencoded",
        "Cookie": token_data["cookie"],
        "Host": "gic.gujarat.gov.in",
        "Origin": "http://gic.gujarat.gov.in",
        "Referer": "http://gic.gujarat.gov.in/front-page/CauseList.aspx",
        "Upgrade-Insecure-Requests": "1",
        "User-Agent": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_5) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/76.0.3809.100 Safari/537.36",
    }
    return payload


def set_payload_causelist_3():
    payload = {
        "Cache-Control": "no-cache",
        "Content-Type": "application/x-www-form-urlencoded; charset=UTF-8",
        "Referer": "http://gic.gujarat.gov.in/front-page/CauseList.aspx",
        "User-Agent": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_5) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/76.0.3809.100 Safari/537.36",
        "X-MicrosoftAjax": "Delta=true",
        "X-Requested-With": "XMLHttpRequest",
    }
    return payload


def get_col_data(cols, doc_response):
    try:
        data_dict = {}
        data_dict["s_no"] = cols[0].text.strip()
        data_dict["app_com_no"] = cols[1].text.strip()
        data_dict["applicant"] = cols[2].text.strip()
        pio = cols[3]
        td_num = len(pio.find_all("td"))
        data_dict["pio"] = get_pio_details(pio)
        appellate = cols[3 + (td_num + 1)]
        data_dict["appellate"] = get_appellate_details(appellate)
        data_dict["hearing_time"] = cols[-3].text.strip()
        data_dict["court_no"] = cols[-2].text.strip()
        data_dict["info_commissioner_name"] = cols[-1].text.strip()
        doc_data = {
            "link": dict(
                content=doc_response.content,
                content_type=doc_response.headers["Content-Type"],
            )
        }
        data = dict(
            export_type="DATA", record_params=data_dict, doc_params=doc_data
        )
        api_data = prepare_export_data(data)
        url = base_url + "/export/data"
        api_call(url, api_data, api_data.content_type)
    except Exception as e:
        print("Exception occured at", cols)
        print("continuing")

    return data_dict


def get_pio_details(pio):
    pio_list = []
    a_tags = pio.find_all("a")
    for a in a_tags:
        pio_data = {}
        params = (
            a["onclick"]
            .split("(")[1]
            .split(")")[0]
            .replace("'", "")
            .split(",")
        )
        response = session.get(
            DETAILS_URL,
            params={
                "Id": "'" + params[0],
                "PIOId": params[0],
                "For": params[1],
            },
        )
        data = response.text.split("|")
        pio_data["name"] = data[0]
        pio_data["designation"] = data[1]
        pio_data["organization"] = data[2]
        pio_data["address"] = data[3]
        pio_data["district"] = data[4]
        pio_data["taluka"] = data[5]
        pio_data["pincode"] = data[6]
        pio_data["mobile_no"] = data[7]
        pio_data["email"] = data[8]
        pio_list.append(pio_data)
    return pio_list


def get_appellate_details(appellate):
    appellate_list = []
    a_tags = appellate.find_all("a")
    for a in a_tags:
        appellate_data = {}
        params = (
            a["onclick"]
            .split("(")[1]
            .split(")")[0]
            .replace("'", "")
            .split(",")
        )
        response = session.get(
            DETAILS_URL,
            params={
                "Id": "'" + params[0],
                "PIOId": params[0],
                "For": params[1],
            },
        )
        data = response.text.split("|")
        appellate_data["name"] = data[0]
        appellate_data["designation"] = data[1]
        appellate_data["organization"] = data[2]
        appellate_data["address"] = data[3]
        appellate_data["district"] = data[4]
        appellate_data["taluka"] = data[5]
        appellate_data["pincode"] = data[6]
        appellate_data["mobile_no"] = data[7]
        appellate_data["email"] = data[8]
        appellate_list.append(appellate_data)
    return appellate_list


def get_courts(token_data):
    courts = []
    payload = set_payload(token_data)
    response = session.get(CAUSELIST_URL, headers=payload)
    soup = soup_creator(response)
    select = soup.find("select", {"id": "ctl00_ContentPlaceHolder1_ddlcourt"})
    options = select.find_all("option")[1:]
    token_data["ev"] = soup.find("input", {"id": "__EVENTVALIDATION"})["value"]
    token_data["vs"] = soup.find("input", {"id": "__VIEWSTATE"})["value"]
    for optn in options:
        courts.append(optn["value"])
    token_data["courts"] = courts
    return token_data


def get_records(date, token_data):
    payload = set_payload_causelist_1()
    form_data = set_form_data(token_data)
    response = session.post(CAUSELIST_URL, data=form_data, headers=payload)
    with open("resp.txt", "wb") as f:
        f.write(response.content)

    t = open("resp.txt")
    lines = t.readlines()
    token_data["vs"] = lines[0][89:9493]
    token_data["ev"] = lines[0][9572:9844]
    for court in token_data["courts"]:
        form_data_1 = set_form_data_1(token_data, court, date)
        payload_2 = set_payload_causelist_2(token_data)
        response = session.post(
            CAUSELIST_URL, data=form_data_1, headers=payload_2
        )
        soup = soup_creator(response)
        token_data["ev"] = soup.find("input", {"id": "__EVENTVALIDATION"})[
            "value"
        ]
        token_data["vs"] = soup.find("input", {"id": "__VIEWSTATE"})["value"]
        rows = soup.find(
            "table", {"id": "ctl00_ContentPlaceHolder1_gvDetails"}
        ).find_all("tr")[1:-2]
        for row in rows:
            if len(row) > 2:
                cols = row.find_all("td")
                data_dict = get_col_data(cols, response)
        pages = soup.find(
            "table", {"id": "ctl00_ContentPlaceHolder1_gvDetails"}
        ).find_all("tr", {"class": "headerTitle"})
        if len(pages) > 2:
            pages = (
                pages.find_all("td")[-1]
                .find("a")["href"]
                .split("(")[1]
                .split(")")[0]
                .replace("'", "")
                .split(",")
            )
            pages = int(pages[1].split("$")[1])
            for page in range(2, pages + 1):
                payload_3 = set_payload_causelist_3()
                form_data_2 = set_form_data_2(token_data, court, date, page)
                response = session.post(
                    CAUSELIST_URL, data=form_data_2, headers=payload_3
                )
                soup = soup_creator(response)
                with open("response.txt", "wb") as f:
                    f.write(response.content)
                t_1 = open("resp.txt")
                text = t_1.readlines()
                token_data["vs"] = text[0][89:9493]
                token_data["ev"] = text[0][9572:9844]
                rows = soup.find(
                    "table", {"id": "ctl00_ContentPlaceHolder1_gvDetails"}
                ).find_all("tr")[1:-2]
                for row in rows:
                    if len(row) > 2:
                        cols = row.find_all("td")
                        get_col_data(cols, response)


def get_tokens(url):
    token_data = {}
    response = session.get(url, timeout=TIMEOUT)
    if response.status_code != 200:
        print("Failed to load home page!!")
        return
    token_data["cookie"] = (
        response.headers["Set-Cookie"].split(",")[0].split(";")[0]
        + ";"
        + response.headers["Set-Cookie"].split(",")[1].split(";")[0]
        + "; Font="
    )
    return token_data

def prepare_export_data(data):
    params = dict(
        export_type=data["export_type"],
        record_params=data["record_params"],
        doc_params=dict(),
    )
    fields = {}
    if "doc_params" in data:
        for k, v in data["doc_params"].items():
            file_name = k
            params["doc_params"][k] = dict(
                content_type=v["content_type"], file_name=file_name
            )
            file_path = "./" + file_name
            with open(file_path, "wb") as f:
                f.write(v["content"])
            fields[file_name] = (
                file_name,
                open(file_path, "rb"),
                v["content_type"],
            )
            os.system("rm " + file_path)
    fields["params"] = json.dumps(params)
    return MultipartEncoder(fields=fields)


def api_call(url, data, content_type="text/plain"):
    try:
        response = requests.post(
            url=url, data=data, headers={"Content-Type": content_type}
        )
        print(response)
        resp = response.json()
        print(resp)
    except Exception as e:
        print("Exception while parsing response")
        print(e)

def start_parsing():
    try:
        # connecting to website
        url = create_get_url(HOME_PAGE_URL)
        token_data = get_tokens(url)
        # print(token_data)
        token_data = get_courts(token_data)
        start_date = "14/Aug/2019"
        # start_date = '01/Jan/2019'
        end_date = str(datetime.date.today().strftime("%d/%b/%Y"))
        start = datetime.datetime.strptime(start_date, "%d/%b/%Y")
        end = datetime.datetime.strptime(end_date, "%d/%b/%Y")
        step = datetime.timedelta(days=1)
        while start <= end:
            date = start.date().strftime("%d/%b/%Y")
            data = get_records(str(date), token_data)
            break
            # data_dict[url] = data
            start += step
            # print(data)
            # break
        # print(len(court_list),'DONE')
    except Exception as e:
        print("Exception while parsing page")
        print(e)

    return dict(
        status="ERROR", message="Exception Occured!!", error_type="EXCEPTION"
    )


def create_combinations():
    try:
        print("creating combination")
        start_parsing()
    except Exception as e:
        print("Exception while creating_combination")
        print(e)


def log_script_stats(st, et):
    dt_format = "%Y-%m-%d %H:%M:%S"
    start_time = st.strftime(dt_format)
    end_time = et.strftime(dt_format)
    print(
        "Combinations Created: started at %s and completed at %s"
        % (start_time, end_time)
    )


if __name__ == "__main__":
    start_time = datetime.datetime.now()
    create_combinations()
    end_time = datetime.datetime.now()
    log_script_stats(start_time, end_time)
    url = base_url + "/notify"
    api_call(url, json.dumps(dict(finished=True)))