from requests_toolbelt import MultipartEncoder
from bs4 import BeautifulSoup
import http.client
from datetime import datetime
import requests
import json
import os
import base64


http.client.MAXHEADERS = 100000
TIMEOUT = 120

HOME_PAGE_URL = "http://www.infocommpunjab.com/SelectYear.aspx"
ORDER_PAGE_URL = "http://www.infocommpunjab.com/"
RECORD_URL = ""
PDF_URL = "http://www.infocommpunjab.com"
NON_REGITERED_RULINGS = ""
SESSION_ID = ""

session = requests.Session()
base_url = "http://localhost:1567"


def create_get_url(base_url, data=dict()):
    if len(data) == 0:
        return base_url
    url = base_url + "?"
    for key, val in data.items():
        url += key + "=" + val + "&"
    return url[:-1]


def soup_creator(url):
    return BeautifulSoup(url.text, "html.parser")


def set_formdata(meta_data):
    form_data = {
        "__EVENTTARGET": "ctl00$ContentPlaceHolder1$gvOrders",
        "__EVENTARGUMENT": meta_data["page"],
        "__LASTFOCUS": "",
        "__VIEWSTATE": meta_data["view_state"],
        "__VIEWSTATEGENERATOR": meta_data["state_generator"],
        "__EVENTVALIDATION": meta_data["event_validation"],
        "ctl00$ContentPlaceHolder1$cboCommissioner": "All",
    }
    return form_data


def set_payload(cookie):
    payload = {"Cookie": cookie}
    return payload


def get_pdf(url, name):
    name = name.replace("/", "_")
    name = name.replace(" ", "_")
    name = name.replace(".", "_")
    response = session.get(url)
    file_name = "./PDF_Downloads/" + name + ".pdf"
    with open(file_name, "wb") as f:
        f.write(response.content)


def get_col_data(rows, doc_response):
    for row in rows:
        data_dict = {}
        cols = row.find_all("td")
        data_dict["dated"] = cols[0].text.strip()
        data_dict["court_no"] = cols[1].text.strip()
        data_dict["commissioner"] = cols[2].text.strip()
        data_dict["time"] = cols[3].text.strip()
        url = cols[4].find("a")["href"]
        name = url.split("/")[-1]
        url = PDF_URL + url
        get_pdf(url, name)
        data_dict["pdf_url"] = url
        response = session.get(data_dict["pdf_url"])
        doc_data = {
            "pdf_link": dict(
                content=response.content,
                content_type=response.headers["Content-Type"],
            ),
            "link": dict(
                content=doc_response.content,
                content_type=doc_response.headers["Content-Type"],
            ),
        }
    data = dict(
        export_type="DATA", record_params=data_dict, doc_params=doc_data
    )
    api_data = prepare_export_data(data)
    url = base_url + "/export/data"
    api_call(url, api_data, api_data.content_type)
    return data_list


def get_tokens(url, cookie):

    payload = set_payload(cookie)
    response = session.get(url, headers=payload)
    print(response)
    if response.status_code != 200:
        return dict(
            status="ERROR",
            error_type="PRE_LOAD_FAIL",
            message="Failed to load home page!!",
        )
    soup = soup_creator(response)
    meta_data = {}

    meta_data["event_validation"] = soup.find(
        "input", {"id": "__EVENTVALIDATION"}
    )["value"]
    meta_data["view_state"] = soup.find("input", {"id": "__VIEWSTATE"})[
        "value"
    ]
    meta_data["state_generator"] = soup.find(
        "input", {"id": "__VIEWSTATEGENERATOR"}
    )["value"]

    return meta_data


def get_page_tokens(soup):

    meta_data = {}

    meta_data["event_validation"] = soup.find(
        "input", {"id": "__EVENTVALIDATION"}
    )["value"]
    meta_data["view_state"] = soup.find("input", {"id": "__VIEWSTATE"})[
        "value"
    ]
    meta_data["state_generator"] = soup.find(
        "input", {"id": "__VIEWSTATEGENERATOR"}
    )["value"]

    return meta_data


def get_records(url, cookie, tokens):
    payload = set_payload(cookie)
    response = session.get(url, headers=payload)
    if response.status_code != 200:
        return dict(
            status="ERROR",
            error_type="PRE_LOAD_FAIL",
            message="Failed to load home page!!",
        )
    soup = soup_creator(response)
    table = soup.find("table", {"id": "ctl00_ContentPlaceHolder1_gvOrders"})
    rows = table.find_all("tr")[3:-2]
    get_col_data(rows, response)

    for i in range(2, 21):
        tokens["page"] = "Page$" + str(i)
        form_data = set_formdata(tokens)

        print(url)
        print(tokens["page"])
        response = session.post(url, data=form_data, headers=payload)
        print(response)
        if response.status_code != 200:
            return dict(
                status="ERROR",
                error_type="PRE_LOAD_FAIL",
                message="Failed to load home page!!",
            )
        soup = soup_creator(response)
        table = soup.find(
            "table", {"id": "ctl00_ContentPlaceHolder1_gvOrders"}
        )
        rows = table.find_all("tr")[3:-2]
        get_col_data(rows, response)
        tokens = get_page_tokens(soup)


def get_years_url(home_url):
    meta_data = {}
    urls = []
    response = session.get(home_url, timeout=TIMEOUT)
    if response.status_code != 200:
        return dict(
            status="ERROR",
            error_type="PRE_LOAD_FAIL",
            message="Failed to load home page!!",
        )
    cookies = response.headers["Set-Cookie"].split(";")
    meta_data["cookies"] = cookies[0]
    soup = soup_creator(response)
    table = soup.find(
        "table", {"style": "text-align:center; width: 800px; height: 130px;"}
    )
    a_tags = table.find_all("a")
    for a in a_tags:
        url = a["href"]
        urls.append(url)

    meta_data["urls"] = urls
    return meta_data


def prepare_export_data(data):
    params = dict(
        export_type=data["export_type"],
        record_params=data["record_params"],
        doc_params=dict(),
    )
    fields = {}
    if "doc_params" in data:
        for k, v in data["doc_params"].items():
            file_name = k
            params["doc_params"][k] = dict(
                content_type=v["content_type"], file_name=file_name
            )
            file_path = "./" + file_name
            with open(file_path, "wb") as f:
                f.write(v["content"])
            fields[file_name] = (
                file_name,
                open(file_path, "rb"),
                v["content_type"],
            )
            os.system("rm " + file_path)
    fields["params"] = json.dumps(params)
    return MultipartEncoder(fields=fields)


def api_call(url, data, content_type="text/plain"):
    try:
        response = requests.post(
            url=url, data=data, headers={"Content-Type": content_type}
        )
        print(response)
        resp = response.json()
        print(resp)
    except Exception as e:
        print("Exception while parsing response")
        print(e)


def start_parsing():
    try:
        # connecting to website
        url = create_get_url(HOME_PAGE_URL)
        meta_data = get_years_url(url)
        cookie = meta_data["cookies"]
        urls = meta_data["urls"]
        data_dict = {}
        for url in urls:
            url = ORDER_PAGE_URL + url
            tokens = get_tokens(url, cookie)
            get_records(url, cookie, tokens)

    except Exception as e:
        print("Exception while parsing page")
        print(e)

    return dict(
        status="ERROR", message="Exception Occured!!", error_type="EXCEPTION"
    )


def create_combinations():
    try:
        print("creating combination")
        start_parsing()
    except Exception as e:
        print("Exception while creating_combination")
        print(e)


def log_script_stats(st, et):
    dt_format = "%Y-%m-%d %H:%M:%S"
    start_time = st.strftime(dt_format)
    end_time = et.strftime(dt_format)
    print(
        "Combinations Created: started at %s and completed at %s"
        % (start_time, end_time)
    )


if __name__ == "__main__":
    start_time = datetime.now()
    create_combinations()
    end_time = datetime.now()
    log_script_stats(start_time, end_time)
    url = base_url + "/notify"
    api_call(url, json.dumps(dict(finished=True)))
