from bs4 import BeautifulSoup
import http.client
from datetime import datetime
import requests
import json
import os
import datetime
import hashlib
from pymongo import MongoClient
import boto3

http.client.MAXHEADERS = 100000
TIMEOUT = 120

client = MongoClient(
    "13.233.89.112:30006",
    username="kagzat",
    password="q0xoFtVOc2FzefbcZx9m5yzWNp49tsOH0GNAnQHD1Be1C2h/6eVE/XkW1eqqGnB8",
    authSource="admin",
)
db = client["scraping"]
col = db["consumer_court_orders"]

s3 = boto3.client(
    "s3",
    aws_access_key_id="AKIAJMYWB2AK7EMYBDHA",
    aws_secret_access_key="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",
)

HOME_PAGE_URL = (
    "http://cms.nic.in/ncdrcusersWeb/search.do?method=loadSearchPub"
)
DISTRICT_URL = "http://cms.nic.in/ncdrcusersWeb/servlet/search.GetDistricts"
RECORD_URL = "http://cms.nic.in/ncdrcusersWeb/servlet/search.GetHtml"
DOC_URL = "http://cms.nic.in/ncdrcusersWeb/"
PAGE_URL = "http://cms.nic.in/ncdrcusersWeb/servlet/search.GetHtml?"

session = requests.Session()


def create_get_url(base_url, data=dict()):
    if len(data) == 0:
        return base_url
    url = base_url + "?"
    for key, val in data.items():
        url += key + "=" + val + "&"
    return url[:-1]


def soup_creator(url):
    return BeautifulSoup(url.text, "html.parser")


def set_params(district, state, start_date, end_date):
    params = {
        "method": "GetHtml",
        "method": "GetHtml",
        "stid": str(state),
        "did": str(district),
        "stdate": start_date,
        "enddate": end_date,
        "par1": "NotApp",
        "fmt": "T",
        "searchOpt": "jud",
        "filterBy": "on",
        "dateByPar": "dtod",
        "start": "1",
        "jsrc": "FULL",
        "searchBy": "6",
    }
    return params


def get_pdf(url):
    response = session.get(url)
    with open("name.pdf", "wb") as f:
        f.write(response.content)


def set_form_data_districts(state):
    form_data = {"scode": state, "type": "report", "method": "GetDistricts"}
    return form_data


def get_col_data(cols, data_dict):
    data_dict["case_code"] = cols[0].text.strip()
    data_dict["pet_name"] = cols[1].text.strip()
    data_dict["res_name"] = cols[2].text.strip()
    data_dict["pet_advocate"] = cols[3].text.strip()
    data_dict["res_advocate"] = cols[4].text.strip()
    data_dict["filling_date"] = cols[5].text.strip()
    data_dict["order_date"] = cols[6].text.strip()
    data_dict["upload_date"] = cols[7].text.strip()
    data_dict["pdf_url"] = DOC_URL + cols[8].find("a")["href"]
    data_dict["doc_link"] = DOC_URL + cols[0].find("a")["href"]
    result = hashlib.md5(
        data_dict["case_code"].encode()
        + data_dict["pet_name"].encode()
        + data_dict["res_name"].encode()
        + data_dict["pet_advocate"].encode()
        + data_dict["res_advocate"].encode()
        + data_dict["filling_date"].encode()
        + data_dict["order_date"].encode()
        + data_dict["upload_date"].encode()
        + data_dict["state_code"].encode()
        + data_dict["dist_code"].encode()
    )

    response = session.get(data_dict["doc_link"])
    md5 = result.hexdigest()
    data_dict["md5"] = md5
    s3.put_object(
        Bucket="firhtml",
        Key=md5,
        Body=response.content,
        ACL="public-read",
        ContentType=response.headers["Content-Type"],
    )
    data_dict["order_link"] = (
        "https://firhtml.s3-us-west-2.amazonaws.com/" + md5
    )
    print(data_dict)
    try:
        col.insert_one(data_dict)
    except Exception as e:
        print("Exception Occured")
        print(e)


def get_next_page(soup):
    cols = soup.find_all("td", {"class": "rhead"})
    next_page = None
    for col in cols:
        if col.text == "Next":
            next_page = PAGE_URL + col.find("a")["href"].split("'")[-2]
            return next_page
        else:
            next_page = None
    return next_page


def get_data(soup, data_dict):
    table = soup.find_all("table")[0]
    if table:
        rows = table.find_all("tr")[1:]
        for row in rows:
            cols = row.find_all("td")
            get_col_data(cols, data_dict)


def get_records(districts, state, data_dict, start_date, end_date):
    for district in districts:
        next_page = RECORD_URL
        data_dict["dist_code"] = list(district.values())[0]
        data_dict["dist_name"] = list(district.keys())[0]
        response = session.get(
            RECORD_URL,
            params=set_params(
                data_dict["dist_code"],
                data_dict["state_code"],
                start_date,
                end_date,
            ),
        )
        if response.status_code != 200:
            print("Failed to load page")
            return
        print(
            "Running script from",
            start_date,
            "to",
            end_date,
            "for district",
            data_dict["dist_name"],
            "and state",
            data_dict["state_name"],
        )
        soup = soup_creator(response)
        get_data(soup, data_dict)
        next_page = get_next_page(soup)
        while next_page:
            response = session.get(next_page)
            if response.status_code != 200:
                print("Failed to load page")
                return
            soup = soup_creator(response)
            get_data(soup, data_dict)
            next_page = get_next_page(soup)
            break
        break


def get_districts(states):
    start_date = "28/08/2019"
    end_date = "01/01/1970"
    start = datetime.datetime.strptime(start_date, "%d/%m/%Y")
    end = datetime.datetime.strptime(end_date, "%d/%m/%Y")
    step = datetime.timedelta(days=365)
    while start > end:
        en_date = str(start.strftime("%d/%m/%Y"))
        strt_date = str((start - step).strftime("%d/%m/%Y"))
        start -= step
        for state in states:
            data_dict = {}
            data_dict["state_code"] = list(state.values())[0]
            data_dict["state_name"] = list(state.keys())[0]
            districts = [{"StateCommission": "0"}]
            response = session.post(
                DISTRICT_URL,
                data=set_form_data_districts(data_dict["state_code"]),
            )
            if response.status_code != 200:
                print("Failed to load page")
            soup = soup_creator(response)
            # dists = soup.find_all("distid")
            dists = soup.find_all("detail")
            for dist in dists:
                districts.append(
                    {dist.find("distname").text: dist.find("distid").text}
                )
            get_records(
                districts,
                data_dict["state_code"],
                data_dict,
                strt_date,
                en_date,
            )
            print(
                "--------------------------------------------------------------"
            )
            break


def get_states():
    states = []
    data = {}
    response = session.get(HOME_PAGE_URL)
    if response.status_code != 200:
        print("Failed to load Page")
        return
    # data["cookie"] = response.headers["Set-Cookie"].split(";")[0]
    soup = soup_creator(response)
    options = soup.find("select", {"id": "stateId"}).find_all("option")
    for optn in options:
        states.append({optn.text: optn["value"]})
    data["states"] = states
    return data


def start_parsing():
    data = get_states()
    get_districts(data["states"])


def create_combinations():
    try:
        print("creating combination")
        start_parsing()
    except Exception as e:
        print("Exception while creating_combination")
        print(e)


if __name__ == "__main__":
    create_combinations()
