from requests_toolbelt import MultipartEncoder
from bs4 import BeautifulSoup
import http.client
import datetime
import requests
import json
import os

http.client.MAXHEADERS = 100000
TIMEOUT = 120


HOME_PAGE_URL = (
    "http://cms.nic.in/ncdrcusersWeb/search.do?method=loadSearchPub"
)
DISTRICT_URL = "http://cms.nic.in/ncdrcusersWeb/servlet/search.GetDistricts"
RECORD_URL = "http://cms.nic.in/ncdrcusersWeb/servlet/search.GetHtml"
DOC_URL = "http://cms.nic.in/ncdrcusersWeb/"
PAGE_URL = "http://cms.nic.in/ncdrcusersWeb/servlet/search.GetHtml?"

session = requests.Session()
base_url = "http://localhost:1567"


def create_get_url(base_url, data=dict()):
    if len(data) == 0:
        return base_url
    url = base_url + "?"
    for key, val in data.items():
        url += key + "=" + val + "&"
    return url[:-1]


def soup_creator(url):
    return BeautifulSoup(url.text, "html.parser")


def set_params(district, state, start_date, end_date):
    params = {
        "method": "GetHtml",
        "stid": str(state),
        "did": str(district),
        "stdate": start_date,
        "enddate": end_date,
        "par1": "NotApp",
        "fmt": "T",
        "searchOpt": "jud",
        "filterBy": "on",
        "dateByPar": "dtod",
        "start": "1",
        "jsrc": "FULL",
        "searchBy": "6",
    }
    return params


def get_pdf(url):
    response = session.get(url)
    with open("name.pdf", "wb") as f:
        f.write(response.content)


def set_form_data_districts(state):
    form_data = {"scode": state, "type": "report", "method": "GetDistricts"}
    return form_data


def get_col_data(cols, data_dict):
    data_dict["case_code"] = cols[0].text.strip()
    data_dict["pet_name"] = cols[1].text.strip()
    data_dict["res_name"] = cols[2].text.strip()
    data_dict["pet_advocate"] = cols[3].text.strip()
    data_dict["res_advocate"] = cols[4].text.strip()
    data_dict["filling_date"] = cols[5].text.strip()
    data_dict["order_date"] = cols[6].text.strip()
    data_dict["upload_date"] = cols[7].text.strip()
    data_dict["pdf_url"] = DOC_URL + cols[8].find("a")["href"]
    data_dict["doc_url"] = DOC_URL + cols[0].find("a")["href"]

    # response = session.get(data_dict["doc_url"])
    print(data_dict)
    # doc_data = {
    #     "order_link": dict(
    #         content=response.content,
    #         content_type=response.headers["Content-Type"],
    #     )
    # }
    # data = dict(
    #     export_type="DATA", record_params=data_dict, doc_params=doc_data
    # )
    # api_data = prepare_export_data(data)
    # url = base_url + "/export/data"
    # api_call(url, api_data, api_data.content_type)


def get_next_page(soup):
    cols = soup.find_all("td", {"class": "rhead"})
    next_page = None
    for col in cols:
        if col.text == "Next":
            next_page = PAGE_URL + col.find("a")["href"].split("'")[-2]
            return next_page
        else:
            next_page = None
    return next_page


def get_data(soup, data_dict):
    table = soup.find_all("table")[0]
    if table:
        rows = table.find_all("tr")[1:]
        for row in rows:
            cols = row.find_all("td")
            get_col_data(cols, data_dict)


def get_records(districts, state, data_dict, start_date, end_date):
    for district in districts:
        next_page = RECORD_URL
        data_dict["dist_code"] = list(district.values())[0]
        data_dict["dist_name"] = list(district.keys())[0]
        response = session.get(
            RECORD_URL,
            params=set_params(
                data_dict["dist_code"],
                data_dict["state_code"],
                start_date,
                end_date,
            ),
        )
        if response.status_code != 200:
            print("Failed to load page")
            return
        print(
            "Running script from",
            start_date,
            "to",
            end_date,
            "for district",
            data_dict["dist_name"],
            "and state",
            data_dict["state_name"],
        )
        soup = soup_creator(response)
        get_data(soup, data_dict)
        next_page = get_next_page(soup)
        while next_page:
            response = session.get(next_page)
            if response.status_code != 200:
                print("Failed to load page")
                return
            soup = soup_creator(response)
            get_data(soup, data_dict)
            next_page = get_next_page(soup)
            break
        break


def get_districts(states):
    # print("inside get_districts")
    # # print(states)
    # url = base_url + "/import/data"
    # params = dict(import_type="DATE_RANGE")
    # import_date = api_call(url, json.dumps(params))["resp"]
    # print("import_Date")
    # print(import_date)
    start_date = "28/08/2019"
    end_date = "01/01/1970"
    start = datetime.datetime.strptime(start_date, "%d/%m/%Y")
    end = datetime.datetime.strptime(end_date, "%d/%m/%Y")
    step = datetime.timedelta(days=365)
    while start > end:
        data_dict = {}
        en_date = str(start.strftime("%d/%m/%Y"))
        strt_date = str((start - step).strftime("%d/%m/%Y"))
        data_dict["start_date"] = strt_date
        data_dict["end_date"] = en_date
        start -= step
        for state in states:
            try:
                if state and len(state) > 0:
                    data_dict["state_code"] = list(state.values())[0]
                    data_dict["state_name"] = list(state.keys())[0]
                    districts = [{"StateCommission": "0"}]
                    response = session.post(
                        DISTRICT_URL,
                        data=set_form_data_districts(data_dict["state_code"]),
                    )
                    if response.status_code != 200:
                        print("Failed to load page")
                    soup = soup_creator(response)
                    dists = soup.find_all("detail")
                    for dist in dists:
                        districts.append(
                            {
                                dist.find("distname")
                                .text: dist.find("distid")
                                .text
                            }
                        )
                    # print(districts)
                    for district in districts:
                        data_dict["dist_code"] = list(district.values())[0]
                        data_dict["dist_name"] = list(district.keys())[0]
                        print(data_dict)
                    # break
                    # get_records(
                    #     districts,
                    #     data_dict["state_code"],
                    #     data_dict,
                    #     strt_date,
                    #     en_date,
                    # )
            except Exception as e:
                print("Exception while get districts")
                # print("strt_date")
                # print(strt_date)
                # print("en_date")
                # print(en_date)
                # print("error")
                print(e)


def get_states():
    states = []
    data = {}
    response = session.get(HOME_PAGE_URL)
    if response.status_code != 200:
        print("Failed to load Page")
        return
    # data["cookie"] = response.headers["Set-Cookie"].split(";")[0]
    soup = soup_creator(response)
    options = soup.find("select", {"id": "stateId"}).find_all("option")
    for optn in options:
        states.append({optn.text: optn["value"]})
    data["states"] = states
    return data


def prepare_export_data(data):
    params = dict(
        export_type=data["export_type"],
        record_params=data["record_params"],
        doc_params=dict(),
    )
    fields = {}
    if "doc_params" in data:
        for k, v in data["doc_params"].items():
            file_name = k
            params["doc_params"][k] = dict(
                content_type=v["content_type"], file_name=file_name
            )
            file_path = "./" + file_name
            with open(file_path, "wb") as f:
                f.write(v["content"])
            fields[file_name] = (
                file_name,
                open(file_path, "rb"),
                v["content_type"],
            )
            os.system("rm " + file_path)
    fields["params"] = json.dumps(params)
    return MultipartEncoder(fields=fields)


def api_call(url, data, content_type="text/plain"):
    try:
        response = requests.post(
            url=url, data=data, headers={"Content-Type": content_type}
        )
        print(response)
        resp = response.json()
        print(resp)
        return resp
    except Exception as e:
        print("Exception while parsing response")
        print(e)


def start_parsing():
    data = get_states()
    # print(data)
    get_districts(data["states"])


def create_combinations():
    try:
        print("creating combination")
        start_parsing()
    except Exception as e:
        print("Exception while creating_combination")
        print(e)


if __name__ == "__main__":
    create_combinations()
    # url = base_url + "/notify"
    # api_call(url, json.dumps(dict(finished=True)))
