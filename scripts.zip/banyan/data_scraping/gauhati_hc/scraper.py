from bs4 import BeautifulSoup
import http.client
import re 
from datetime import datetime,date
import hashlib
import requests
import json
import subprocess
import os
import itertools
import boto3


http.client.MAXHEADERS = 100000
TIMEOUT = 120

HOME_PAGE_URL = 'http://kohimahighcourt.gov.in/judgement.aspx'
PDF_URL = 'https://aftjabalpur.in/uploads/'

session = requests.Session()

def create_get_url(base_url, data=dict()):
    if len(data) == 0:
        return base_url
    url = base_url + '?'
    for key, val in data.items():
        url += key + '=' + val + '&'
    return url[:-1]

def soup_creator(url):
    return BeautifulSoup(url.text, 'html.parser')

def set_form_data(token_dict):
    form_data = {
        'ctl00$CPHBody$SM1': 'ctl00$CPHBody$SM1|ctl00$CPHBody$DropDownListMonth',
        'ctl00$CPHBody$DropDownListYear': token_dict['year'],
        'ctl00$CPHBody$DropDownListMonth': token_dict['month'],
        'ctl00$CPHBody$TextBox1': '',
        '__EVENTTARGET': 'ctl00$CPHBody$DropDownListMonth',
        '__EVENTARGUMENT': '', 
        '__LASTFOCUS': '',
        '__VIEWSTATE': token_dict['view_state'],
        '__VIEWSTATEGENERATOR': 'E683B3E1',
        '__EVENTVALIDATION': token_dict['event_validation'],
        '__ASYNCPOST': 'true'
    }
    return form_data


def set_form_data_year(token_dict):
    form_data = {
        'ctl00$CPHBody$SM1': 'ctl00$CPHBody$SM1|ctl00$CPHBody$DropDownListYear',
        '__EVENTTARGET': 'ctl00$CPHBody$DropDownListYear',
        '__EVENTARGUMENT': '', 
        '__LASTFOCUS': '',
        '__VIEWSTATE': '/wEPDwULLTEzOTA4NTI0NjIPZBYCZg9kFgICAQ9kFgICAQ9kFgQCAw9kFgQCAw8QZBAVCwlTZWxlY3QuLi4EMjAxOQQyMDE4BDIwMTcEMjAxNgQyMDE1BDIwMTQEMjAxMwQyMDEyBDIwMTEEMjAxMBULCVNlbGVjdC4uLgQyMDE5BDIwMTgEMjAxNwQyMDE2BDIwMTUEMjAxNAQyMDEzBDIwMTIEMjAxMQQyMDEwFCsDC2dnZ2dnZ2dnZ2dnFgFmZAIHDxBkZBYBZmQCBQ9kFgJmD2QWAgIBDw8WAh4HVmlzaWJsZWhkFgICAQ8PFgIeBFRleHRlZGRkeEZHG5q6Cotmr68H2vtwPeUaCfCyJVToMhV3U7V96vQ=',
        '__VIEWSTATEGENERATOR': 'E683B3E1',
        '__EVENTVALIDATION': '/wEdAB262YTcBj28c7jvdf1gwObsveKMXQdDxptcbN9BdysOm+6V3Na+CaCjzfIG08M/c98ifbZmtBr6V09l3+qu652uVoG2UlUABDfUX4EEbQynqjPs4j9sJ8Yq+ydRODBHdS1WWNGuwgxM8ZlRWwlkiaePCK8H/vyWXf1Ekm6Vutco4Kq7rVo0xNS9ZnGZXxPckg+AcA+arRk+uWobOu9XfmdpbvuE4SRZ4FDpp9ZzYz4a/vGt/dfFRp/nphb011akNDRHu3eM7+f8gncsbV6K1w7THECMP2C9VUV4HKmd1l9iIlnWra6U+obNSP2djTMVYLYq8LLKdtEpD9r4k5Nb/H4qrfjl7RYpe47qi0y+QEdwGrA5pa7c30hhw4j3yczmZcBAvO+tuade5NMStBUwRkZgpxdBPvWdmVjwpv4De+UjdbhAlOmVyWmApv1N8rtGsCpuCm23EOfUrQ74TWFTq/6Nl/wXkGUVZnjqN44nuQOqpOikO8lUZeprOXmenSZOZ74DTt00/f7F5SGgQgKT+eO2ASdsGGq9g8/dcMfUgE1BhavglP4OV1F7ETIFQrMj0Bpn9WXxbw0B0rsqldvhoFPxhOvAvHqvpIIFUmGqmIs8Hg6A1nlY4PeAfI+pBLB1pMui6f1uT3v5N5Otl35g8XEZ',
        'ctl00$CPHBody$DropDownListYear': '2010',
        'ctl00$CPHBody$DropDownListMonth': '0',
        'ctl00$CPHBody$TextBox1': '',
        '__ASYNCPOST': 'true'
    }
    return form_data

def set_payload():
    payload = {
        'Cache-Control': 'no-cache',
        'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
        'Referer': 'http://kohimahighcourt.gov.in/judgement.aspx',
        'User-Agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_5) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/76.0.3809.87 Safari/537.36',
        'X-MicrosoftAjax': 'Delta=true',
        'X-Requested-With': 'XMLHttpRequest'
    }
    return payload

def get_pdf(url,name):
    name = name.replace('/','_')
    name = name.replace('.','_')
    name = name.replace('-','_')
    response = session.get(url)
    file_name = './PDF_Downloads/'+name+'.pdf'
    with open(file_name,'wb') as f:
        f.write(response.content)

def get_causelists(token_dict):
    for month in range(1,13):
        token_dict['month'] = month
        form_data = set_form_data(token_dict)
        print(form_data)
        response = session.post(HOME_PAGE_URL, data=form_data)
        if response.status_code != 200:
            print('Connection failed')
            return 
        soup = soup_creator(response)
        print(soup)
        div = soup.find('div',{'class':'dsply'})
        if div.find('li'):
            print(div.find_all('li'))


def get_year_tokens(url):
    token_dict = {}
    response = session.get(url, timeout=TIMEOUT)
    if response.status_code != 200:
        print('Failed to load home page!!')
        return
    soup = soup_creator(response)
    token_dict['view_state'] = soup.find('input',{'id':'__VIEWSTATE'})['value']
    token_dict['event_validation'] = soup.find('input',{'id':'__EVENTVALIDATION'})['value']
    print(token_dict['event_validation'])
    return token_dict


def start_parsing():
    try:
        # connecting to website
        url = create_get_url(HOME_PAGE_URL)
        # token_dict = get_tokens(url)
        start_year = 2010
        end_year = int(date.today().year)
        get_year_tokens(url)
        
            # get_causelists(token_dict)
            break

        
    except Exception as e:
        print('Exception while parsing page')
        print(e)
    
    return dict(status='ERROR', message='Exception Occured!!', error_type='EXCEPTION')


def create_combinations():
    try:
        print('creating combination')
        start_parsing()
    except Exception as e:
        print('Exception while creating_combination')
        print(e)


def log_script_stats(st, et):
    dt_format = '%Y-%m-%d %H:%M:%S'
    start_time = st.strftime(dt_format)
    end_time = et.strftime(dt_format)
    print('Combinations Created: started at %s and completed at %s' % (start_time, end_time))


if __name__ == '__main__':
    start_time = datetime.now()
    create_combinations()
    end_time = datetime.now()
    log_script_stats(start_time, end_time)

