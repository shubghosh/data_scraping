from bs4 import BeautifulSoup
import http.client
import re 
from datetime import datetime
import hashlib
import requests
import json
import subprocess
import os
import itertools
import boto3


http.client.MAXHEADERS = 100000
TIMEOUT = 120

HOME_PAGE_URL = 'https://www.nddb.coop/resources/tenders/blackfirms'
PAGE_URL = ''

session = requests.Session()

def create_get_url(base_url, data=dict()):
    if len(data) == 0:
        return base_url
    url = base_url + '?'
    for key, val in data.items():
        url += key + '=' + val + '&'
    return url[:-1]

def soup_creator(url):
    return BeautifulSoup(url.text, 'html.parser')


def get_col_data(cols):
    data_dict = {}
    # print(cols)
    data_dict['s_no'] = cols[0].text.strip()
    data_dict['bidders_name'] = cols[1].text.strip()
    data_dict['blacklisting_period'] = cols[2].text.strip()
    
    print(data_dict)
    return data_dict

def get_table(url):
    data_list = []
    response = session.get(url, timeout=TIMEOUT, verify=False)
    soup = soup_creator(response)
    div = soup.find('div',{'class':'field field-name-body field-type-text-with-summary field-label-hidden'})

    table_body = div.find('tbody')
    rows = table_body.find_all('tr')[1:]
    for row in rows:
        cols = row.find_all('td')
        data = get_col_data(cols)
        data_list.append(data)
        # break
    return data_list


def start_parsing():
    try:
        # connecting to website
        url = create_get_url(HOME_PAGE_URL)
        data = get_table(url)
        print(len(data))
    except Exception as e:
        print('Exception while parsing page')
        print(e)
    
    return dict(status='ERROR', message='Exception Occured!!', error_type='EXCEPTION')


def create_combinations():
    try:
        print('creating combination')
        start_parsing()
    except Exception as e:
        print('Exception while creating_combination')
        print(e)


def log_script_stats(st, et):
    dt_format = '%Y-%m-%d %H:%M:%S'
    start_time = st.strftime(dt_format)
    end_time = et.strftime(dt_format)
    print('Combinations Created: started at %s and completed at %s' % (start_time, end_time))


def create_text_file(data_dict):
    s = ''
    with open('input.txt','w') as f:
        t = open('desc.txt','r',encoding="utf-8")
        content = t.readlines()
        for line in content:
            line = line.replace('\n','')
            line = line.replace('\t','')    
            if not line.strip():
                continue
            f.write(line)
            s = s + line
    data_dict['content'] = s
    data_dict['content_type'] = 'text'
    result = hashlib.md5(data_dict['title'].encode() + data_dict['Court'].encode() + data_dict['Citation'].encode()
            + data_dict['content'])
    md5 = result.hexdigest()
    data_dict['md5'] = md5
    
    return data_dict


if __name__ == '__main__':
    start_time = datetime.now()
    create_combinations()
    end_time = datetime.now()
    log_script_stats(start_time, end_time)

