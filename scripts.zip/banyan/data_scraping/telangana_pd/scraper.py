from bs4 import BeautifulSoup
import http.client
from datetime import datetime
import requests
import json
import os
import urllib3

urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

http.client.MAXHEADERS = 100000
TIMEOUT = 120

HOME_PAGE_URL = (
    "https://www.tspolice.gov.in/jsp/citizenServices?method=viewFirCitizen"
)
PS_URL = "https://www.tspolice.gov.in/jsp/citizenServices?"
CAPTCHA_URL = "https://www.tspolice.gov.in/jsp/citizenLogin?method=ajaxCaptcha"
RECORD_URL = (
    "https://www.tspolice.gov.in/jsp/citizenServices?method=approvedFIRSubmit"
)
PAGE_URL = "https://www.tspolice.gov.in/jsp/citizenServices"

session = requests.Session()


def create_get_url(base_url, data=dict()):
    if len(data) == 0:
        return base_url
    url = base_url + "?"
    for key, val in data.items():
        url += key + "=" + val + "&"
    return url[:-1]


def soup_creator(url):
    return BeautifulSoup(url.text, "html.parser")


def set_params(district):
    params = {"method": "getPSforFIR", "districtCd": district}
    return params


def get_pdf(url):
    response = session.get(url)
    with open("name.pdf", "wb") as f:
        f.write(response.content)


def set_form_data_ps(token, district):
    form_data = {
        "org.apache.struts.taglib.html.TOKEN": token,
        "district": district,
        "policeStation": "",
        "fromdate": "",
        "firNo": "",
        "captcha": "",
    }
    return form_data


def set_form_data_records(token_dict, district, ps, date, captcha):
    form_data = {
        "org.apache.struts.taglib.html.TOKEN": token_dict["apache_token"],
        "district": district,
        "policeStation": ps,
        "fromdate": "04/08/2018",
        "firNo": "",
        "captcha": captcha,
    }
    return form_data


def set_payload(cookie):
    payload = {"Cookie": cookie}
    return payload


# def set_payload_captcha(cookie=None):
#     payload = {
#         "Referer": "https://www.tspolice.gov.in/jsp/citizenServices?method=approvedFIRSubmit",
#         "Sec-Fetch-Mode": "cors",
#         "Sec-Fetch-Site": "same-origin",
#         "User-Agent": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_5) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/76.0.3809.100 Safari/537.36",
#     }
#     if cookie:
#         payload["Cookie"] = cookie
#     return payload


def set_payload_records(cookie):
    payload = {
        "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3",
        "Accept-Encoding": "gzip, deflate, br",
        "Accept-Language": "en-GB,en-US;q=0.9,en;q=0.8",
        "Cache-Control": "max-age=0",
        "Connection": "keep-alive",
        "Content-Length": "149",
        "Content-Type": "application/x-www-form-urlencoded",
        "Cookie": cookie,
        "Host": "www.tspolice.gov.in",
        "Origin": "https://www.tspolice.gov.in",
        "Referer": "https://www.tspolice.gov.in/jsp/citizenServices?method=viewFirCitizen",
        "Sec-Fetch-Mode": "navigate",
        "Sec-Fetch-Site": "same-origin",
        "Sec-Fetch-User": "?1",
        "Upgrade-Insecure-Requests": "1",
        "User-Agent": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_5) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/76.0.3809.100 Safari/537.36",
    }
    return payload


def get_col_data(cols, data_dict):
    data_dict["case_code"] = cols[0].text.strip()
    data_dict["pet_name"] = cols[1].text.strip()
    data_dict["res_name"] = cols[2].text.strip()
    data_dict["pet_advocate"] = cols[3].text.strip()
    data_dict["res_advocate"] = cols[4].text.strip()
    data_dict["filling_date"] = cols[5].text.strip()
    data_dict["order_date"] = cols[6].text.strip()
    data_dict["upload_date"] = cols[7].text.strip()
    data_dict["pdf_url"] = DOC_URL + cols[8].find("a")["href"]
    data_dict["doc_link"] = DOC_URL + cols[0].find("a")["href"]

    response = session.get(data_dict["doc_link"])

    print(data_dict)


def get_next_page(soup):
    cols = soup.find_all("td", {"class": "rhead"})
    next_page = None
    for col in cols:
        if col.text == "Next":
            next_page = PAGE_URL + col.find("a")["href"].split("'")[-2]
            return next_page
        else:
            next_page = None
    return next_page


def get_data(soup, data_dict):
    table = soup.find_all("table")[0]
    if table:
        rows = table.find_all("tr")[1:]
        for row in rows:
            cols = row.find_all("td")
            get_col_data(cols, data_dict)


def get_records(ps_data, token_dict):
    for dist, value in ps_data.items():
        data_dict = {}
        data_dict["state_name"] = "Telangana"
        data_dict["dist_name"] = dist
        data_dict["dist_code"] = value["dist_code"]
        for ps, ps_code in value["ps_list"].items():
            data_dict["ps_code"] = ps_code
            data_dict["ps_name"] = ps

            captcha = session.get(CAPTCHA_URL, verify=False).text.strip()

            data = set_form_data_records(
                token_dict,
                data_dict["dist_code"],
                data_dict["ps_code"],
                "",
                captcha,
            )
            headers = set_payload_records(token_dict["cookie"])
            print("data")
            print(data)
            print("headers")
            print(headers)
            response = session.get(
                RECORD_URL,
                data=data,
                headers=headers,
                verify=False,
                allow_redirects=True,
            )
            # if response.status_code != 200:
            #     print("Failed to load page")
            #     return
            print(response.text)
            print(response)
            break
        break


def get_ps(token_dict, districts):
    data = {}
    for district, code in districts.items():
        data_dict = {}
        ps = {}
        data_dict["dist_code"] = code
        data_dict["dist_name"] = district
        data_dict["state_name"] = "Telangana"
        response = session.post(
            PS_URL,
            data=set_form_data_ps(
                token_dict["apache_token"], data_dict["dist_code"]
            ),
            params=set_params(data_dict["dist_code"]),
            headers=set_payload(token_dict["cookie"]),
        )
        soup = soup_creator(response)
        options = soup.find("select", {"name": "policeStation"}).find_all(
            "option"
        )
        for optn in options:
            ps[optn.text] = optn["value"]
        data[data_dict["dist_name"]] = {
            "dist_code": data_dict["dist_code"],
            "ps_list": ps,
        }
        # get_records(ps, data_dict["dist_code"], data_dict, token_dict)
    return data


def get_districts():
    districts = {}
    response = session.get(HOME_PAGE_URL)
    if response.status_code != 200:
        print("Failed to load Page")
        return
    soup = soup_creator(response)
    options = soup.find("select", {"id": "district"}).find_all("option")
    for optn in options:
        districts[optn.text] = optn["value"]
    return districts


def get_tokens():
    token_dict = {}
    response = session.get(HOME_PAGE_URL, verify=False)
    if response.status_code != 200:
        print("Failed to load page")
        return
    token_dict["cookie"] = response.headers["Set-Cookie"].split(";")[0]
    soup = soup_creator(response)
    form = soup.find("form", {"name": "userMenuForm"})
    token_input = form.find("input")
    token_dict["apache_token"] = token_input.get("value")
    return token_dict


def start_parsing():
    token_dict = get_tokens()
    districts = get_districts()
    ps_data = get_ps(token_dict, districts)
    get_records(ps_data, token_dict)


def create_combinations():
    try:
        print("creating combination")
        start_parsing()
    except Exception as e:
        print("Exception while creating_combination")
        print(e)


if __name__ == "__main__":
    create_combinations()
    # url = base_url + "/notify"
    # api_call(url, json.dumps(dict(finished=True)))
