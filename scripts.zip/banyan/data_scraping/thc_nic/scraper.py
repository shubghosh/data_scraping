from requests_toolbelt import MultipartEncoder
from bs4 import BeautifulSoup
import http.client
from datetime import datetime
import requests
import os
import json

http.client.MAXHEADERS = 100000
TIMEOUT = 120

HOME_PAGE_URL = "https://tsu.trp.nic.in/highcourt/page/frmCauselist.aspx"
PDF_URL = "https://tsu.trp.nic.in/highcourt/page/"

session = requests.Session()
base_url = "http://localhost:1567"


def create_get_url(base_url, data=dict()):
    if len(data) == 0:
        return base_url
    url = base_url + "?"
    for key, val in data.items():
        url += key + "=" + val + "&"
    return url[:-1]


def soup_creator(url):
    return BeautifulSoup(url.text, "html.parser")


def set_formdata(page):
    form_data = {
        "__EVENTTARGET": page["trg"],
        "__EVENTARGUMENT": page["arg"],
        "__VIEWSTATE": "/wEPDwULLTE1MTI3NjMxMzgPZBYCZg9kFgICAw9kFgQCAQ8PFgQeBFRleHQFBUxvZ2luHgdWaXNpYmxlaGRkAgMPZBYIAgEPDxYCHwAFE0xhd2F6aW1hIENhdXNlIExpc3RkZAIDDzwrAA0BAA8WAh8BaGRkAgQPPCsADQEADxYEHgtfIURhdGFCb3VuZGceC18hSXRlbUNvdW50Ai1kFgJmD2QWKgIBD2QWBGYPZBYCZg8VAQExZAIBD2QWBGYPFQEEMTcxN2QCAQ8PFgIfAAUXQ2F1c2UgTGlzdCAtIDAzLzEwLzIwMTlkZAICD2QWBGYPZBYCZg8VAQEyZAIBD2QWBGYPFQEEMTcxNWQCAQ8PFgIfAAUXQ2F1c2UgTGlzdCAtIDMwLzA5LzIwMTlkZAIDD2QWBGYPZBYCZg8VAQEzZAIBD2QWBGYPFQEEMTcxM2QCAQ8PFgIfAAUXQ2F1c2UgTGlzdCAtIDI2LzA5LzIwMTlkZAIED2QWBGYPZBYCZg8VAQE0ZAIBD2QWBGYPFQEEMTcxMGQCAQ8PFgIfAAUXQ2F1c2UgTGlzdCAtIDIzLzA5LzIwMTlkZAIFD2QWBGYPZBYCZg8VAQE1ZAIBD2QWBGYPFQEEMTcwN2QCAQ8PFgIfAAUXQ2F1c2UgTGlzdCAtIDE5LzA5LzIwMTlkZAIGD2QWBGYPZBYCZg8VAQE2ZAIBD2QWBGYPFQEEMTcwNWQCAQ8PFgIfAAUXQ2F1c2UgTGlzdCAtIDE2LzA5LzIwMTlkZAIHD2QWBGYPZBYCZg8VAQE3ZAIBD2QWBGYPFQEEMTcwM2QCAQ8PFgIfAAUXQ2F1c2UgTGlzdCAtIDEzLzA5LzIwMTlkZAIID2QWBGYPZBYCZg8VAQE4ZAIBD2QWBGYPFQEEMTcwMmQCAQ8PFgIfAAUXQ2F1c2UgTGlzdCAtIDEyLzA5LzIwMTlkZAIJD2QWBGYPZBYCZg8VAQE5ZAIBD2QWBGYPFQEEMTcwMWQCAQ8PFgIfAAUXQ2F1c2UgTGlzdCAtIDA5LzA5LzIwMTlkZAIKD2QWBGYPZBYCZg8VAQIxMGQCAQ9kFgRmDxUBBDE2OTlkAgEPDxYCHwAFF0NhdXNlIExpc3QgLSAwNS8wOS8yMDE5ZGQCCw9kFgRmD2QWAmYPFQECMTFkAgEPZBYEZg8VAQQxNjk3ZAIBDw8WAh8ABRdDYXVzZSBMaXN0IC0gMDIvMDkvMjAxOWRkAgwPZBYEZg9kFgJmDxUBAjEyZAIBD2QWBGYPFQEEMTY5NWQCAQ8PFgIfAAUXQ2F1c2UgTGlzdCAtIDI5LzA4LzIwMTlkZAIND2QWBGYPZBYCZg8VAQIxM2QCAQ9kFgRmDxUBBDE2OTNkAgEPDxYCHwAFF0NhdXNlIExpc3QgLSAyNi8wOC8yMDE5ZGQCDg9kFgRmD2QWAmYPFQECMTRkAgEPZBYEZg8VAQQxNjkxZAIBDw8WAh8ABRdDYXVzZSBMaXN0IC0gMjIvMDgvMjAxOWRkAg8PZBYEZg9kFgJmDxUBAjE1ZAIBD2QWBGYPFQEEMTY4NmQCAQ8PFgIfAAUXQ2F1c2UgTGlzdCAtIDA5LzA4LzIwMTlkZAIQD2QWBGYPZBYCZg8VAQIxNmQCAQ9kFgRmDxUBBDE2ODVkAgEPDxYCHwAFF0NhdXNlIExpc3QgLSAwOC8wOC8yMDE5ZGQCEQ9kFgRmD2QWAmYPFQECMTdkAgEPZBYEZg8VAQQxNjgzZAIBDw8WAh8ABRdDYXVzZSBMaXN0IC0gMDUvMDgvMjAxOWRkAhIPZBYEZg9kFgJmDxUBAjE4ZAIBD2QWBGYPFQEEMTY4MWQCAQ8PFgIfAAUXQ2F1c2UgTGlzdCAtIDAxLzA4LzIwMTlkZAITD2QWBGYPZBYCZg8VAQIxOWQCAQ9kFgRmDxUBBDE2NzlkAgEPDxYCHwAFF0NhdXNlIExpc3QgLSAyOS8wNy8yMDE5ZGQCFA9kFgRmD2QWAmYPFQECMjBkAgEPZBYEZg8VAQQxNjc3ZAIBDw8WAh8ABRdDYXVzZSBMaXN0IC0gMjUvMDcvMjAxOWRkAhUPDxYCHwFoZGQCBg8PFgIfAAVMMzBkYXlzJyBDYXVzZSBMaXN0cyBjYW4gYmUgc2VlbiBoZXJlLiBGb3IgdGhlIHJlc3QgY2hlY2sgQXJjaGl2ZSBDYXVzZSBMaXN0LmRkGAIFI2N0bDAwJENvbnRlbnRQbGFjZUhvbGRlcjEkR3JpZFZpZXcyDzwrAAoBCAIDZAUjY3RsMDAkQ29udGVudFBsYWNlSG9sZGVyMSRHcmlkVmlldzEPZ2Q24hhFVDPszY/zihHGDzSt4d8mbA==",
        "__VIEWSTATEGENERATOR": "12F6D127",
        "__EVENTVALIDATION": "/wEWBALYnrDCCgLg3I7uDgLg3PLuDgKP6PmbAcF1Wr8YDAhhfMFwaJeXnwQ2/8Zl",
    }
    return form_data


def get_pdf(url, name):
    name = name.replace("/", "_")
    name = name.replace(".", "_")
    name = name.replace(" ", "_")
    response = session.get(url)
    file_name = "./PDF_Downloads/" + name + ".pdf"
    with open(file_name, "wb") as f:
        f.write(response.content)


def set_payload(cookie):
    payload = {
        "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3",
        "Accept-Encoding": "gzip, deflate, br",
        "Accept-Language": "en-GB,en-US;q=0.9,en;q=0.8",
        "Cache-Control": "max-age=0",
        "Connection": "keep-alive",
        "Content-Length": "2576",
        "Content-Type": "application/x-www-form-urlencoded",
        "Cookie": cookie,
        "Host": "tsu.trp.nic.in",
        "Origin": "https://tsu.trp.nic.in",
        "Referer": "https://tsu.trp.nic.in/highcourt/page/frmCauselist.aspx",
        "Sec-Fetch-Mode": "navigate",
        "Sec-Fetch-Site": "same-origin",
        "Sec-Fetch-User": "?1",
        "Upgrade-Insecure-Requests": "1",
        "User-Agent": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/77.0.3865.90 Safari/537.36",
    }
    return payload


def get_col_data(cols, doc_response):
    data_dict = {}
    data_dict["s_no"] = cols[0].text.strip()
    data_dict["pdf_url"] = PDF_URL + cols[1].find("a")["href"]
    response = session.get(data_dict["pdf_url"])
    print(data_dict)
    doc_data = {
        "pdf_link": dict(
            content=response.content, content_type=response.headers["Content-Type"]
        ),
        "link": dict(
            content=doc_response.content,
            content_type=doc_response.headers["Content-Type"],
        ),
    }
    data = dict(export_type="DATA", record_params=data_dict, doc_params=doc_data)
    api_data = prepare_export_data(data)
    url = base_url + "/export/data"
    api_call(url, api_data, api_data.content_type)
    return data_dict


def get_pages(url):
    response = session.get(url, timeout=TIMEOUT, verify=False)
    if response.status_code != 200:
        print("Failed to load home page!!")
        return
    # cookie = response.headers["Set-Cookie"].split(";")[0]
    # print(cookie)
    soup = soup_creator(response)
    table = soup.find("table", {"id": "ctl00_ContentPlaceHolder1_GridView2"})
    row = table.find_all("tr")[-1]
    pages = row.find_all("td")[1:]
    list = []
    for page in pages:
        data_dict = {}
        page = page.find("a")["href"].split("(")[1].split(")")[0].split(",")
        data_dict["trg"] = page[0].replace("'", "")
        data_dict["arg"] = page[1].replace("'", "")
        list.append(data_dict)
    return list


def get_causelists(url):
    data = {}
    response = session.get(url, verify=False)
    if response.status_code != 200:
        print("Failed to load home page!!")
        return
    soup = soup_creator(response)
    table = soup.find("table", {"id": "ctl00_ContentPlaceHolder1_GridView2"})
    rows = table.find_all("tr")[1:-2]
    for row in rows:
        cols = row.find_all("td")
        get_col_data(cols, response)
    pages = get_pages(url)
    for page in pages:
        form_data = set_formdata(page)
        response = session.post(url, data=form_data, timeout=TIMEOUT, verify=False)
        if response.status_code != 200:
            print("Failed to load home page!!")
            return
        soup = soup_creator(response)
        table = soup.find("table", {"id": "ctl00_ContentPlaceHolder1_GridView2"})
        rows = table.find_all("tr")[1:-2]
        for row in rows:
            cols = row.find_all("td")
            get_col_data(cols, response)
    return data


def prepare_export_data(data):
    params = dict(
        export_type=data["export_type"],
        record_params=data["record_params"],
        doc_params=dict(),
    )
    fields = {}
    if "doc_params" in data:
        for k, v in data["doc_params"].items():
            file_name = k
            params["doc_params"][k] = dict(
                content_type=v["content_type"], file_name=file_name
            )
            file_path = "./" + file_name
            with open(file_path, "wb") as f:
                f.write(v["content"])
            fields[file_name] = (file_name, open(file_path, "rb"), v["content_type"])
            os.system("rm " + file_path)
    fields["params"] = json.dumps(params)
    return MultipartEncoder(fields=fields)


def api_call(url, data, content_type="text/plain"):
    try:
        response = requests.post(
            url=url, data=data, headers={"Content-Type": content_type}
        )
        print(response)
        resp = response.json()
        print(resp)
    except Exception as e:
        print("Exception while parsing response")
        print(e)


def start_parsing():
    try:
        # connecting to website
        url = create_get_url(HOME_PAGE_URL)
        get_causelists(url)
    except Exception as e:
        print("Exception while parsing page")
        print(e)

    return dict(status="ERROR", message="Exception Occured!!", error_type="EXCEPTION")


def create_combinations():
    try:
        print("creating combination")
        start_parsing()
    except Exception as e:
        print("Exception while creating_combination")
        print(e)


def log_script_stats(st, et):
    dt_format = "%Y-%m-%d %H:%M:%S"
    start_time = st.strftime(dt_format)
    end_time = et.strftime(dt_format)
    print(
        "Combinations Created: started at %s and completed at %s"
        % (start_time, end_time)
    )


if __name__ == "__main__":
    start_time = datetime.now()
    create_combinations()
    end_time = datetime.now()
    log_script_stats(start_time, end_time)
    url = base_url + "/notify"
    api_call(url, json.dumps(dict(finished=True)))
