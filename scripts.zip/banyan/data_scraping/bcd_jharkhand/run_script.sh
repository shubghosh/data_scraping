python3 scraper.py
