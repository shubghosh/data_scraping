from bs4 import BeautifulSoup
import http.client
import re 
from datetime import datetime
import hashlib
import requests
import json
import subprocess
import os
import itertools


http.client.MAXHEADERS = 100000
TIMEOUT = 120

HOME_PAGE_URL = 'http://bcdjharkhand.gov.in/DebarredContractors.aspx'
# JUDGEMENT_PAGE_URL = 'http://moneylaundering.legal/'
# PDF_URL = 'https://cpwd.gov.in/'

session = requests.Session()


def create_get_url(base_url, data=dict()):
    if len(data) == 0:
        return base_url
    url = base_url + '?'
    for key, val in data.items():
        url += key + '=' + val + '&'
    return url[:-1]


def soup_creator(url):
    return BeautifulSoup(url.text, 'html.parser')


def get_data(url):
    response = session.get(url)
    if response.status_code != 200:
        print("Connection to website refused")
    soup = soup_creator(response)
    # print(soup)               
    table = soup.find_all('table',{'class':'table table-striped table-bordered table-condensed table-hover table-responsive'})
    print(len(table))
    get_first_table_data(table[0])
    get_second_table_data(table[1])
    

def get_first_table_data(table):
    rows = table.find_all('tr',{'class':'small'})
    # rows.pop(0)
    i = 0
    for row in rows:
        cols = row.find_all('td')
        data = get_col_data_first(cols)
        i+=1
        print(data)
        print('###############################################################################################################')
        break

def get_second_table_data(table):
    rows = table.find_all('tr',{'class':'small'})
    # rows.pop(0)
    i = 0
    for row in rows:
        cols = row.find_all('td')
        data = get_col_data_second(cols)
        i+=1
        print(data)
        print('****************************************************************************************************************')
        break


def get_col_data_first(cols):
    data_dict = {}
    name = cols[0].find('input',{'type':'hidden'})['name']
    name = name.replace('HFDownloadID1','lnkDownloadDebarred')
    print(name)
    data_dict['s_no'] = cols[0].text.strip()
    data_dict['contractor_name'] = cols[1].text.strip()
    data_dict['company_name'] = cols[2].text.strip()
    data_dict['address'] = cols[3].text.strip()
    data_dict['debarred'] = cols[4].text.strip()
    data_dict['debarred_free'] = cols[5].text.strip()
    if data_dict['debarred_free']:
        free_name = name.replace('HFDownloadID1','lnkDownloadDebarredFree')
        payload_free = get_payload(free_name)
        response_free = session.post(HOME_PAGE_URL,data=payload_free)
        file_name = './PDF_Downloads_Free/'+free_name+'.pdf'
        with open(file_name,'wb') as f:
            f.write(response_free.content)
    payload = get_payload(name)
    file_name = './PDF_Downloads/'+name+'.pdf'
    response = session.post(HOME_PAGE_URL,data=payload)
    with open(file_name,'wb') as t:
        t.write(response.content)
    return data_dict


def get_col_data_second(cols):
    data_dict = {}
    name = cols[0].find('input',{'type':'hidden'})['name']
    name = name.replace('HFDownloadID1','lnkDownloadDebarredbyother')
    print(name)
    data_dict['s_no'] = cols[0].text.strip()
    data_dict['dept_name'] = cols[1].text.strip()
    data_dict['contractor_name'] = cols[2].text.strip()
    data_dict['address'] = cols[3].text.strip()
    data_dict['debarred'] = cols[4].text.strip()
    data_dict['debarred_free'] = cols[5].text.strip()
    if data_dict['debarred_free']:
        free_name = name.replace('HFDownloadID1','lnkDownloadDebarredFree')
        payload_free = get_payload(free_name)
        response_free = session.post(HOME_PAGE_URL,data=payload_free)
        file_name = './PDF_Downloads_Others_Free/'+free_name+'.pdf'
        with open(file_name,'wb') as f:
            f.write(response_free.content)
    payload = get_payload(name)
    file_name = './PDF_Downloads_Others/'+name+'.pdf'
    response = session.post(HOME_PAGE_URL,data=payload)
    with open(file_name,'wb') as t:
        t.write(response.content)
    return data_dict



def get_payload(name):
    payload = {
        '__EVENTTARGET': name,
        '__EVENTARGUMENT':'' ,
        '__VIEWSTATE': '0Bpnq4ZR2+X1NC2ppaAxpTumX3d7X2gihW2l5Eqs08XhFET0d+8T0PozDlur9l4z0iOvWMI8IcL9gNm2AJxxATs3DrYUuotEcVuA0l6Prp80G+SaF3PUEyh2GXR6oCjz5XwpsMMqUuCuzDR4mQi72u+BuUg6+p1dNSNW4R1nQkoK74zcocDDKu2NBe/jkGGxT76Pun32HBD0s+RkO4UxPmb3DV/RPuiSDgCflJzsdPLBPSjM1l+Uah+O9z1gXz5Wy1/0aI/3LWnNUFFNtnYRxDl8Uhk2Xl6bMNycGo1hLBRBrjwLcaCwgoFpFDU5+1LKe4lYk0ydO6LmZALc5sb4QOOJLvwYAky4HuN8jWu4nBNQZqrrOtKHVFcACH6oPVTewSX4c0KLqhRXljkOeSKXcEaYlu9fFAmMHH3jxEoEdbmWnecfn/uoqmfnwnjygs6mnxZSEoLgerPd4V3k6Ovl5MhuH6V7bH9phgFN2CL35RkkNzR39frej8cdSRE3sHGEbXfaWA9FNrsqPwTHlQAtlOJUsWNw6M0IBWkE+4vb4taCrxQNBbpdCne5ondqiiAIcRljqXBaEomFZdarDU4F+zVP9G823bm4I3+Tc0plxTs4ZOvs8jwcEGfxOg/kH8HNJg6YsqBbEHKI6wFOYElnzwIWUZxHJGQysO5BwlyjGV42cxptVES+NahxziDpaHuqbLHrgnSRnq1VsdRwPvyblEP5vzNyqJWo7PdH1h27/w3dC76j0eiAzH9aXTzdl+P2pxhK0Kc0LekKCvEMUi1zGvSY+VXy9fJeWzsAajONhnGleB7xNwjK2NmMYSe554/XLUX6UBclEdUeo+lm2PVttXs1vp/q8anEB3Ky0a0AsHQt6BFb5t9H5AHmULLv5Q9g5Fs+QKnHNV5S2ntpoINGotDzduJPxzvzlXQzbGfBstowHSNnwfHd7UopYhemtxh/g1PKSZ6s22esSgpZYBSe5HEXfGXvn8WW8nkCGNf+YV2Y+aItTnqLzOqEv92Cp5glbfOiEt81+wPiC1CDyuiXTGsgA9yuMv+RF88jl0aoUDAEwpyO2zc3WAAX4+PBpUwXbzOHlR07bntC8X6oXbF+dtuF6Pg/pLE4JmAzA4hviVh6b5vwMlbQgPJ2Uc16nMGxfLTn8iaKAmqVznnkhwemql86FOlJ/nLUCBkcTu39MZ9G1o5hwHm1JuByu+IJ9xy5S53HG1Gcg1pbJWmVmPFpDbt3EUgQHvUmeP6g2ycia7j4PFuYEbZ3YO++i0xReI/GA6R0U/0MivOQnOlNQRF00BEc+O/0za+VpzntXtZhyS4uXhwGtbc/NpKO2KqqBg8nNFH8/y9iqcAcIVig+MIaAOG0DQWB9naS0KgfNAtJGRPFrwA1N3VyX8lZEcmto953kXNOaDAGfvkwwsjjWp+sKsTBam6lffUd24tr2bFFPxXqNxhtcUmJnwYr1BIHDV94POvf76+/yF3c/7u2ri1lqaZzt3w/oa3O4/bq0WLdIwYpAodO9I/xMFeeGJowe0rpFf/Sl9WgbPrOREtCV5pYN5o1m91Ymvn7bm28kQQhZ51IgQBbWU2vAE8oYpLfNwz3n+YnyrCNiGKp8O0bHv7EWD/4Fv9MmcBFVz79VETA8ANSPcHUaxPI+hnal/nPyZLohm4BIAiSAwOGsmXyOmCymPbIipTSwn/mi+NK18XHnrV4MKsiNTkqo7GvCPDHEtvmPpmWXAzZ8JgDLYwAuPicLVeoDNRinMtAbtw9GexGHspzCIEw/WbBfGAsBqnBTr1ZMsOos63nkS5VVCcJ/mEkmZpM2LaFL5sT62bVBF1QEaQN47gCWWB9fFPEp2XbsaaI/am8azFeTj9A0dpsUtBe7tCyuADXD33ZgViTEq+BO80p+mn339ddvMlmdDM6c+efbU4CmE8NGdEAhlbHQ65g1K0iarFoounHQrKaKrzXGsIajpWpD+anhQzuX2tI4W62yKSe7vlp8PvPbjdbI32WlT7DkS9NtNvGU5r11X16XWBQmvnmLcovYNdW2pOv7OhDwLBwLPgNHipgxJ2IJirLTVUzPF95GP4g3Et6/c7SSv42UNtRTZIUDd0Vc7vJ0NqxHH8y9I90Ix+tTdcLJIWlZRVWDCqm++/uEhAsY/6tEq4FAj4miKX2mxwd7NLmzy4PhaJn/mCTwpjiL66P8HsQWjT54kbdxafGO1cCCauXZ2fh6Fga/s+7/FUXC2mpCZFbLal1O/6Rs//JFou0giX4BzH93GNTWcH+vUaphvzD+wFYAmUU1pXUn4qkNIJ32gYW7y8UpNuS16vgvBzCy6H0+ojfu3YkOND5ryMi9ajLZsKmdc9x2NUHLMvKFA6zmsJYTyWXW9LxS1jtevW7BsJkbuzZtlR258GZkbh4dPr02SsBRTuPSIEZdw+Uka8T9p4bHd6rbFqeR0s2ODz5Al5/xWV54PVlqWa/noBVf5pOKq3epgE2ZO1ZXEVVU8N1zFaNkzedN8iYgxEbCRgjaOT3vGA0hw/DHRH5S96AYax1Lg9SM4EVNY/UkmgU2kj/oOR1LM76fct6VYS+DJCOzsLJ922llF+UpaVWAbBLBjcXxVPXfkNyatvXvRSo889qhseMJMPTfv4aATeiYoEhGbH7oed17BhfKiy7959Gp0eFWllYgt1VIawRBpK6p3R2TeVucGJxtNLqCcHKly7JVY0XheNwlC+luLeUNT0yyLmucVek9utrwMPiSbbWQnHK3htsuVO6thSQiAwtk026XqmQ/SKx+Q4ldHKp3oY6I6hV9c35kPR91PHcQgNYUUOLOD+Oit1En6Rl27caSs6d/SRrlzEiqIHH/XBTEeJ0GJPLSZYiI5SSfSQfm+5R9TRCKXbAMx+ERjEhkMW/xY4XinpvWU/yslbqDXHndina+BgCfAfTnqyUNHbngY4W9K4bOosvx0Hy/lZ/VTnLtCFIdzKY3nvi/08AiPmPjPVVz0vEm2BOD7GC7v+4n1dd/GMzShNAHw0Tyw6jQehZ7svNTj2ih9gW4hV+T/JhQp3AAnZMONhK3krimgqqEcVJ/P0XsgY1g7WcnE4zpK0M6vW9oOsXz6XTjSlVrWGjG2jwg08czPNH5FVvwoCXGVI55LewI3x0UifMqPKOJaCJyMRaodTc92/DKqJzLCqKUzJ2dW5zg7nmS433KtLCejPVqUZNcjpu44CL7iWvp3eIrvTx5Q4HgFtO5G8Xa+PlsgVxi+X3aBHZwgXDhfkfnaDSi00K3Vyq2Cmu6XzNfnUaKPBJHZ8pp+vbeqHAQPccUwzCdKL55zKIHhRGwhS8tRNKwuP5Y/YFBDK23EeihNJemIO5tLu7AQtPT3T1+6E6BzZSAall3MhjiqozSzgt6h15wE3BX2nr9XBVwhZk935bVJYLn9joXWJ31BC1oeflHcyJFaCEeFkrmcCyBCe/LHusUINXENCYIDNL+SXBP0ZcIoDySucnNmIn/47+13JOuZegOlB7iz/CB39MkH6XqsSbDiot7zC2/tbq1MLlE+c9wxeBq1998Ubxw6nrfzTcW8ptLyMfPbgfupk+C4yXVrCwVP90Dvj5ZTtScyBywjoDbSqKer+Wy4tODEMoGOHFRDOD4OdsqarhY01Qgud7kgchBD9meFQndVBFQ5nlirOBY587c9cwTS05pK1NEo+qQpyYeud5X+Y4LnM+lH0Hje98C2GbSx5NDdHXRtbKp3ub139Oq7Wy88EVRSfAjtcc0paS4w7IWO9orgrYT5jyrGdpvsBpOlelkWFrs+/dXRn34ZcbEBcw4FVexU6vt5HwnaVFtQw2YzA4b71/Uw7LwuLsWzikDIKdYCJQFP75uxbuBxtGBYp6tyEXJX5jC4b/0TPmFRwxkTogD24LimD5Q6S+8ux6Zhoc3fdqVu6In1XQv1+r94g4nSmhOfaT8itunCPh6Vwnq6Graye4q5+hmgNB4Uikue9BNLlLF2g4pxhJsOfKp8KasvVk3MH3EK+0sDyuNyJFy6Zah3mYgaaGqDFVWl5bPz7aOxRsRzKQNfHl9riPlBp+fe77ViiFpO4ku5d/TEqOfmDWIqP2DAujOLgJwRen6UNm7HD+Ez0T0lKrfapV6J2QbPoBUuBOQpef+rwodIxzqejkrMbDoAJ+oqAkGXKXdb5xuJiUxRBha5wnLPDUaPIF+63qlR3/Eus9DB2gAhj8gJfk0RaogDTPidI0CPTGutU8gKB6rnC4EH2EVQyb6lFADCk/1voC3K/vMGQR3tn2CPn/GY8ESiwbsyG9JToUEBY9eH6BqrNIJ4NUfoMbXXu5+QjGVS6tLmVUpax/51p3AAK5sKd+4y0HZ/eSeNtwztkgy73dgRaexlNO9iqwj6g5R9rrH7NdVmKNZ5xMJo5XKhvj46+RSRYpgBbcnqK7Iuw7rKbvmTbkKgJNrHlMBQtA8Fb486itJsa9wRBUu2dg+fehl4Jzl2yHy9KlOzYQ+FDvWstUpEHJYuqQk9r8ynuOSC/RS5Cprjtj4T/Ys6Vh4vv1ET53LmOC5gZMRWGELd4vA46xNgyZCv40P45JT3idyu1ezIfor7zM1GPiz4PNe7avOqLFjTPz7GVOQqGavRUvf9vC/E0CQEoQpXctedSzKxg2/lASHHQrKn/WwgNIbU8/WGAcDLvZRkNnaRE1gGykcMxOp2MZMdM/hMNgPFHZ2FA5dssgqPKgWh2VdnJLG6bbJi3lR1CUAOwqc0JVaEDBZ/S/dpoeuKATI4x/h/pNK6GYjZKhmiVL9zp2ng2LQhmC6RFJ1GfoKtHcELrqhH717LYgzNQhrmTBGzGSjTFDrnDie2JlG+AHA4/LL8M7at+q4ryp5HQTEIuDC2gxGfllf3gyIJrO/hLjiu0d27NqeoXfvMj9bAOKy1Y6vRVSWZDvQS9U+NdvUosmrsEKM3qBNbtOC4Ggn9jp7dqNUYPyFnERyuvIfMYsP+G2LNCd2w8C9+MIcgWSoAN9EBU0goKrGwOt2OOsvBlDAbk1o771k+MNx30WS42EsNrbXjFkEyLx67uNXFMpSze0/LT9GFC9Q8lvK7i0XAcrNKQ1MgJ7ffZvntRF+ynrdSSXHP+Mvrf0MOaPJbPNeoyY85V16VkfenZNefCYuMLD4vGgWnlZYpKaxAVvPtb59dHcKZ14+5eHmqCAaBQ+8DH2yQIfnxI7j8qgkrtEPmGyaKN15Mu71bFLIDBWby7lf5mPO08o8BDCD69DopMOGHuh8wjltXZO3iSkhBNgz054Mt1Xug6BcthSWI+BMkmVrKdEt23O7LmnfMj3ESAgVphAtMdpjskviHZOleB6FzyClU6A/jOYyzjfah5WO4WwQeGpFNStZK/m8dXEEzA18Xx1ilhFiZ+VKDwL7i7O6Us62i5plL1WuTZUCsEzXVsTWIO9O1adlHQ+rdB7dGW38OAyFvIkZY6V0STyOncjD3qljzB62JDPOjOpxjqZIx6FiT3//KfU3r/GFEUJh2RilzhAPex7kT2p981fcDfPEW88WYe/S/qcEbqPx1MrT2dlSb1v4tvhL9fQga0/r7KwRX20LRTA5W6NsAMMikvI01dK73Zsdt8plxFPneK1oRDAh39BEPZe84Dwa5a+1LaaWT18HWso2K53tOHvTpZQY+xN8VMRaE7JUmzzaap7GVtLPkzxumvy3nUmDTEFkAnRcMwtVV+T8Gv4PCr3zh0AiJtqie3rL/Je2wdRfJE1RxbpIx6hDXTkpWXf2xpY376dKsRttW//b+TPfKQ0ZrTUe95g/ENOO44S9x8FtdtZH4euptBugFvJ3V8ruhuXEG4MczDRIADnwwmYYXh6vxIbVxfnleYx0806BdG9TZdZueVw/66Fi1LZM0Rt3JiGNtqVzpKpa636VVYGRyKqeOShxuZSGcOvy+xUYhTXmsJF2R/cRE7BA48WoOCfVtRRa7P6GSBvF+DJn9kxvhBTef+yKtCOr7dbaEIcP7is1aPK4GeYwDGgeAPNjaBtT1tPEljvylq8vCf/DTFIFIeGN0MNYp2nt+4W1St9auqg7iNv5U0b7h5GER5EQtZhVoAW3i+v7aTNoXkLklAsnlNc1NbBwOuqcUrer/V1k3U/JqEX6FKqnrmWvNKc7pX+2UIaA6Sh8MhK2QipSfaxw5AolKO3i/aginEUPJtxCsJ40zsLP01KZF7j4l7LCv2ItlUtAPfI4zzvuo9CDImDsiAPMFvMeFkQ0ZNC3fRrbr12IfhzbFzT5Wl3YQVyBn/AWvW8dSHdKDfx52jNDUamcN7Y4bglKiS5SjbPEgZl/DKv1sKWZs5k2bw8v6eBPbxwiTEEIhqU272Y373HKd5t2C6yOkK5biWypYIQ8yp0CwVtyJJWLhHULSyiZpoHb/K89k089PAIC28dYCB//RZm3oHoIsJg14+jemmMaHYUM6Ey9cdu60w7Hii4R49qx8n0vcGzei2yS5jWL068zzfytKVyv7XQbl52hkbQB7/KqOfZQxWIXNpBslrcsZ9bK5gfe1pfx6zKlvdQNX3JcHAzLBwB3UU6RU51HHNmgIXNjDokAg0GYQ0bexbw8Y1hTmKUe4nfXy1socdHSR+CSwliVzingi4nRcPMGPZbw6X2TbVZYnQWAIBtSaY53dBnFbxQt4BRPfDPS2tybgslWmGDukONbvl+hM3IsuM7nDDlU0HPYUtLq8tGFxzmnhmqOcJDg3f1aBUxlGDBTooGL5mFBGmttgpW7ls9TkTVxPxRihRzSpCrT7K4LNjhVBnmwp7IEW85Z2R2YFthEJdTgP5gTj910YyBDmyjuT5zJzjs1oOPJtrzXl6hrpbkXRJ++gkw1PH40pl5tJ/ExN4Cqs/GdzS5u0BVZ5/AneVV5i2Jc+N/yzvtyyHCCCTpIZUjpAHWFaHTx4TwRmUmB17CefJzcZOXP7XcJ2Eraevdk5Wr88U4Q7KqOYhDcog6bOmN/L1rbHW3R+U14A6hQJv+LmZrHStAWq0EtWjGQ00qQRz29GByvr9pmYa2ZBu9NjrqhtMM7IUWF909kS400sJRQDH5bPdF3Rt+4ebV7RVF3Xa1J7vth1IZ4HNfFtCNbKcPgdGbT/AxbKZzj5PTMPYcl9/ChP2m2qfCHdkpw/d150Fi6iXhFSKZNXrZU88nY34bgApW2E288ZPGwiNgCq+TVM74IYexX1TnwzfPJtQncBWJJVXVUeh/4r/eUD5wnXYDwOASyRJwQmtnSTeMPzhmGbaQi4iawE/6USm67DiHtW2SgC9eldHIygUw8rBQRPQCpYm3equ+0v3OSSKZYRMx1otUb5UZQnzJi1WxnXfHNGZBdgR6y+mR0kF9c+XEoRoKfBw1zYH30VK5CSXA4j+LbleE+Qlb2nicXPVQz/I4c7pX5UXcSfduA3fLioS1EOKNxWahqDWncFtS5/+GfZjz/7D2LRyvVQYjXtJL5uaCxYidX8PDKfVplOQsfwzNI+XngzlvGx/xsZotBTfgLfVC9tP8lAszfewqzrLr5YjN7VU/ub7jaOa22dfNKezVCLhWA1hGmvEgGYvKD1s4C155eiS9VWqo2qUaOF+88aERFisKA9GMLvKVtrMl4WyLIRc7QgTNG9zE4uynBzcMQAz0zLx5K7UiK0tuyUNQUOfPBgODVTBLzoh1MtTh68h1LDFeuRvYRRfQMA0x715Rfbka++7QwE+yIh9wV3zlWzGN0bU9bvyZYRoynk3Hw4HlU3dujrmovQhTVm/W5T6PztZnV9My6+sMAFMqqwsHwK/J4TTbxA10jJkGnHa0SEpgxt27KS0o7NjkXu2k2Dv+idNpvlVRI+JeINr0X6YecCS7LdNOocUkB4VHsJfl3h/Pxws+tHAm/3I16JA96xe833xV/4DAvNTSBEy3YZrH3/I35+xdxbKqFOS32lkkx+T/VUgk8UJlv+ptXUXVTPSu+AnZOsk1jdIeYpAgJZuyx24hqVaGxhwf3S+SexXqk8z0Id0rPg1y3yUFMY2T6wP3Y46vf9IMwKxZzIb3kTaS0SahpcsnYBVUGHeJv6uZCwPxpunmMu+DPkngX19BNrrzhwEjjh/UdyhlFfbMuR8Lf8KQKJwsoVyhoedqoCmaYxxg6LKrk60qLOvxIM0WVYP1EoThfN9N0EduQNEasKvyNuUSGcAsPc2up7LWxwR7TkdXRG3HhCAMjnlmHx6XYzrofojhPOILQ4NdReKHx/ZQELIap+wsTwjtXAdFXfIFrfHpYa3YZ1i9e7XhD8hJceIObpCYieeGxvYc2dP3WI03FPcR867Opyug2UfCUtHAydaM5wt2c57ulyAwIzAEh+l1J79vo/j3R9tU0GhBgcZhW9yHmeYAjOdzdWHa0gFuN8BCAETiiw9MTS5BqOBh1yoRQdHpA/eMu0D744QfYU/nVAnnRM9o7lAyVRwPu/EDxCJdMYKqcE5SKtpUf+EjWpAduUHg2s1XTMOSa0UiBx0qGTFlw5hR8caFEEg2F6U8sRkQb+k/gbrBapsLrcdXTCOm+20ylTjbTL8omQZff+g/Y+qzUR0m1JCB0BghexE4f9WRcetr2EWR9xXtspYzuNJfcQRNqiJrbw7ImOWVDC4jNMECpZjbIPjtZ4euj5Iveap+8xjI8pZc86KzBkz2dOA9PQLcVKusUXzx3ff/meBQuZF3BMqfJKUwHkiqqjK8RhBu2wq9Uk91U4Vd2CbDyvbS1ijBVd/4c5PAfi139rFWbLhrDXoa0JGjl4id2b5ctxlHVdueLraWfJ3vKp2vNFjhZg3cgr1UEv2t1dzZ+M5tDwTlU5rYCCHrxNv/H58vutGbtLY2n40l3335ynB+7KpmP5uSKzpKY0zeRsVJ1tU7vYNaKZkRpH4j3iEwsjbwl6MN6gVWqsTo32s5g897SeZWzQ7d+64B8TveicrBuJQEAgexSNE9tk5TgHL++MacqDyWjJ1uh8neiVK4uOjfdm5fcw83ciN+BaIRd313mHVhtFUOQyVOQHus4z4dGbMAFEho0b6lsSY1waur+1Yw27Pv4TqpvCM449+DI4JjPDXSBDMLWLtanumsMPPblDeaKWb7FeTCW42EZUEUqmKCMG7BawJn8TahqCM2P7h24I/BOeYxxsQiRVu/PAuhpnZiWXuIqJi2Hay0fgZnpvp5o/8BooLCQI6ZXcWL5xtFgmtEtpawlhFWew+gacTXPpPqh9DmvS28RsYve7sd/+gIThizhjR1aaQq2fiXa3HEwNGE7ujGR5NQjaaEkTqjDe12UVZScgdIH/LPT42g9LNJcweJ2iRjopi7kZD0B073+sgUeyWcey3SVNHF+Qqv5LUg5fH3TvvxYNZlPw+F8Gug+o1yRjGwNT4tR/DM7JaKWbeLGEa1LJ6WvtCRVhVQ34h0YR4XjuSrh30MtSu1kpXS7P/7dHLGoSS0e53BIv/qsVh6ZkwvUA2/ja/QPZhKZ3ebp1jmKsDwnL5H0g+17oFdwyoHi8DlRt0UJFADHNAziNbrZTFsjFf9Ztnpef8e9SrWHWFWVbhR+/tR2EuFCCFRBKXluJBYXCgpCoCWqZSExQ4wGZJdlIcqZgzX+/mNraambcCZovlcxtb7lmg52wHcuM7LlUtQiZckOo+hyHfsJHoRzVKPoLiBlA5SiR7OU3R5haIgBnHf3TFB2F/10NRVgF63Ghb+tU9r9qdpGBqW9o6+smCHfiI1urQaDh0abFV/sz+gZe5VC+76a+Tm5wqrvIjXiAwg43RFN3AJPvlmIWNwGsRem9qSZ250+DYlowMPFnoXgiojRDNLahB5s/Xvf4MhcA0NCQcmTr9Y0R0UDVaLiA0Mz016mGvknsg6AkTiSK/42V1Hfn2DkO/Um+/VmKjDgvz6xwTZw7MI88ZZuswegBKddF659+m3hfrpAhcphX1RfUdPV9nHuq/6WHuuvXUmpY9QUvlVa33A9F8Gaw5ay+rFM7Scx2KGkgR1bVoQjVvc5EDwYhksUVGljYnxlw/SBeKUGo1xqUPbQjo+v35twzBq2iMp6qN+HN/HXycsmEYB9cwnVJjkTu4QRYQaJ7trzZDRyocgqPEmDMALlJ8U6rLnAVjJlfYb/Fbq+OLtI/kcml1NaULIyNjWgKRXH+MPkV/WZh2+clanUTEyQIxVNkQi/TurfxQWiwrOB1ARE9BufJs+Csl+45UpHJRUUOtKsDXmdoVeMjUkxfM0aMQoRFMXXAQBRMHy9Fl39LH1TP2MmhH+11zzjSXYNaK9Tn+JfGmRxOC6bHAX78OASwJ9fkdsgt8kuV7K5ilQY3Yy9Zk25i8PSwvTYVcWSdBPkCSOsJClDf/QZIzdklJNJAVWW9Xwe5ZIAUoYga+txH1zIK5mmJ/l+657HRcXtT3j+aqqM9f95V4x/2tGunS8Wu5ifbwuX7vPQqLrjj97GIfGQ4AIwfD6gCdPGAhwpvhuUYAWMFpquQxUwqRbbAB6s2/VkOrI56kuit3/R+E8NOp/1AMFPgJThRjbiOLFs/BjvpDEjiuVZhDFyMNZi8/UeLpyczi5gTiRVO4yKUf0hPuCBD+PynK59I4bTQ/uqlHHLwGFoET6oMISi+a7UjfddgQAEI+KK+YmEvcFeSwqFXx9xisELoKgDxmZ4P+Bj9X94iPNGtCjCoioLvCz+vKNzJlxjcfYtRZSn7ks/SBXzRw4YuAukrg8n63li3gl1G2w8W+QYcSVe6/neF9Y7wlmEGt2Y2PS+dSH5DB6KVb4hRgNxd7ihP+SO9zpAkiA9MLWIlU0rw4nLGeWqeJY9BMosh/Q8jDk7M5DXeN2gHVCeYVrNaec9tA+uUabUwXe6fya7uRbpY6hsftiqjkTIGaXnaozLYwhHemQ3KtYNOIvR90GwIhYQdqivWSDNtPBIWuiCD1PH2OJLfZHnoWQKwtxMAEtcihfb9/hKnnrzR7ltXBFE6jny2b8sICOa6RLr8M/BlEzEHr4iFghrLaKcjKnNLiZPrfUvE5p7XIRA9tstQvAZ0w6U5yF24PmJcSzQmuHDAvBQ8S6HTGm0nFhYOt3hAwZjxIhAR1fbe6/OLODJ9ITPkuSmQOUx0vGEAzq9nXpSpvjX+U+ixCtiupPk0sr7aXxPM9q1s2/s7GAY8neRZQ/mXBFfIZVzveEngjPhw3uQSOUTwrUqHtP6h0A7mmxscHp9UsnJlzeLo11A+Q2kpZ1udVNkBxygjJ49jMRdN7DADCApUC/FNIavkJUmoGrpq/ZsXNMyRBk2lLycfBgPNN8xO5sMU/THDxvDoXO82XKJsAjWrEEDYQ90KfhY5yZUzWqytCOEhb+pqd8ec3EJZ160RLfIEjATgLYT5vNXPtufsLz/WvJewoWbCgLF+dhIbi3AGHjUGTwkTObPJLvprrwXogSoFns2GTDpm7c5gGGRxwp35ozWKBYifwKp+233urZSMH1kHtL6TlIlLEXI3vJqrlV9MnN/dsneIWCO8m08iXgaRBhkO7ZfdnrQzflKumxB1I+OTJoFcQL3UTcs5chAW2RGBpFbF2ozphGCSKvkCXQAZVmHR7mGkoR8x9ni22vYNsSDaQatqiQmRry4FuKFP9fuUtmlPpbt0eLloCE/JLh7M9iMtsp3PPw+SIHOinSAAvqSHvc3xEblDpI3a9OGYnQK1qTMLeVs+Y7RdtGUILM6qYLYT5/TVPBNVYSAgMpRG61bFuHnm142fwUASkfMgQxABesaoeU2/9y4kjzEXYalLThfIk3cAepMn35BK0wD+nytn77AS/juRaSGAAzWzsVlqrYTuWKTJOnugVz0f3dJ5/jUmEiVEEelycH9Q70R7k+EIkpA1daWqEIu/bBmjqzyU/kuXQAdFlfh/ikhzjvZ9zaCD2pahZZw4qInIxjJ5tqUOXK4G9zGSDxG2PGx140OU2XOEYlUD2EOf/wVxWGpgHnP3WczG6KmYAxRHik+D1eBnORlHfl/2GJhISKe4OzIowUIHrHuOFl3nOkyOqt2G4VZGw+BxOZPYkjiHeqBPN4Xw1dNOrRDdIj+UglDePMvLy0jjhpTIDME/12YPvvZcivJIvLWpBEMUYk6MT9XDwp88++gYbIZ+4EJlJiL0B3DGnEqj8VMWw1O0QDDUAHUoLBQXnjro7VgFVcwK8qsxGXdXccAJwjL3B+PFH8I6ArZ/rSTi/FwB19k9Y9kuHNmclf3vye2uhFl0SBJ0bfb+Sk4T+tOIBoZAorYQuHI1UJf4V9eiFLhqILPSttRkLGgzJcJFE+/Vuf/Zgw8CKtHipi/m4ZQ0iVaHnnymrKlkZoDQ8Eea+QNNl0UV5vCQQWuLxwgWgW6WiuR+aDM2/rlNG9Ntt51HwAECBiN3A2tZi9bMTUjfaN7DbOvAuNP3K+FJOL2TENBTZrKW+nRlK0S56fGV9zbu5WZ2CthgK8/xbcxntWojtfQ2YwTeFAiF1kUqTEz9lCCyO1Fu/qdrguL8L7RINVvKCtpheTCfKnxQe9mSEe6NyxZTuAGrCSYPk7wpXWDcUPIloz+yJ5EieSAJoF2JOz+hNk1KCA4I5/eWCkFA8qSkijCUtrrUHGlw2ffoO+azoF+hb264+3QVe5TdiBtToUdtQ87eBhnETtLofSCu5wLbVfQlWpKOKlkZ5RScXXpT3WTKxhkWt4rFA1Zrr2Jv9CBMMBRb449O7kF2mwn1PaLOJa3iqbXRS4frboLAbXg2nYFEJHcOHKjNsfuJ8gK9QGtpNO7P/DXZjau6PzC5nf61qAjWUg4QSrQD0Pr9KBS0/MedGV8/ZAR7Y67WbRfQkmYkj/qxeTst0tEUzXMaASocSN0+8Ohk0wkb4ENVd8rR432c2IEnYg9gxp23JuV2HhLSX1LzLH/t+idCFKdOXC23lLhX4aYPpSkjEsZCrEtelsz69REbTqbA+152QJmm55xzF3rSvIMK4FoebFIGPENMZGiCIe4unVgiXw+YqS3jjTPSuXnuZh3fsMFDLkp0sQ3GlVx/tn/ufelrPOzCnOKDCYCWcEhQfm88x430cH3O91ccx+jg7h+K55FMJ56eYJAnE8laRnqiHlgeMX47jLKcQBDA4WXdu2WBVb0s9C3CYSBgBfKiF4JC4g+8Os2OnMQtdCXARgsban0UHQb2grDtd1Mdyb+whZO6FcQN833jjIJoGLKsnphQLyTxkPXZ6ZBR7BPRgviSiMEEKpBtVU5uKYG7x+xJ0M0D7uBUxJzntZJDM2eDApDgcRFTTW8Mxu9TQZAEHkV2N2aqWLtwCY2BvC2b2OGXaBvIzYF52551obJlc8r7edsNwBZf83sHC0maljYd6s9PaFjgerC/+DzmoqN8iqB6DxH7dPGvwdWtFTICC6/+/sJIX0D4IHDsa1E1v7Ih3idA+oX3rRKwXu82BCTzGGNetLcarxsV0+gyNwlEJkYVRRHrJGQPV20T16mp1P1Jftkq2nuMRn8azIlfNjhreZWZRqeGEcGKDvJV7Yz/GY/A0efiLYqViN1yRGSVsHLQh3lfpEt7PCqtkoSV+f0u+8wyJ0O+emXp9W3NPgalRgS5DYn1brkYcSnhLOuR56+dDH/XeMILDPMP1yMfvzK5tYcqGk10xdsymYL/iujALg0+nCnvpY4088py1WU7gVoNYdxWq7QGE8Pqq8j1anz0sWyvPZoIcg1M2hVrSUwm6O8+uv2hl69bVENXbqDig57rpzC+uqklmisVc0PbPfMwLeWb9f11T6ePrgzVIARRIgslhf9x2fUqVFQmFPUWqoQcNBT7CVhMDCm1WoPi7wxlt9VQmqWfqbkp/kOJlFgkKkeTG7jgc7l1Aus0BGxYZP6ByZuKZ2LJZxjVMh+L9Se1Q7aPOMu0EbARRnXTmjZtJxQckfZW1ib4XBIKJfROJobSYPqtDzcbVu2Agb+9HUXa19TldGaMpbLdboGikbw73ccTF7USWeTkR3h45KajDyWN183XXZvWgi+09g942f0xFA5ERuDH9Wk+BP2dScgy4jAS6tJGtJlkgKrZqgPCkzAdn8jAlBih2WVBPFGN+RHJt473WPG3BHeU3/Zo1nSQ9vXL7ylZckZNkaV9qV6OTV2ST6rUHhc8FxcZfoLxwj2ma3oR2E/i7QahR6qxUEawYRf2lk7kL6FZWWFADndMLnyJHSSvCf0Oh/EBFHREKg19m3lVrdO6kE5SFdkdq/PZ4MGPI6OhTmQvLaUqqII/O/BxD57M8WnaD5ohKgOVzOhn8P2OAEz/ZPCdCLBGIBDEtKCfqemsHUeHMtCW8qqlojed9dIq9og+mErf4HubifP7iDEOo0p/R/XRo6Z0MFGRwHPr2oAQFgT4gDE5wJbO0MppGBeeFMZf/KPeK1df0RCbAWpDgDMpu7Wq4yAWWX03n+UvuGTFsyqR+O1qTH26OGBcH+XKO0pvTxmDOf7wqM+DgA1WYg7CDrmt0o3WbqsPoQMW+LF1K1wokzAHg1i37ucCUhNt95b3RpgekAdNi7X61gisXvOWzvkJ2FjwP7HHH5dzt9Wd7SoRyteLa9dierB8v1+tPEZR+S7LDd7p35YOzGURM9TsxbHxZIrQG+grqpPSYXcOSjMOmQtkWpyyN2M2+7qKyATlyZzdBgD4cY4ZOhLLL+LVDByrpuqy1yR1CW9rPan/zkxHj8bLWgWT5ovEX8mzeSUFaH68KCxqexR8nQUvFqmVrck04XaT+8zZxa2XRGjLpO2StyO4lumq/l5i5WCAm2Qc0Cxf8TsCVBrTy2mDTEqz1jxhZfiU56xm5N3MbvTaKM6w1IPZN87ylTsbcuBzJb+lokKfcblvf0iGurLm07nk8PA8r2qCSFlJ0FpyQfqOhsrDZ0RW3w2mBezcta3RP7a5SaUWIe411SdZN9TsYcNGnEOQI/BD/P9jBaJFZJi9S3qLQUHnnAH6QtwHCoH34SAhJDR5JvxtjqY/7jBl6yTyXcD2zDZ0Jmf8FPooF6zcRAs6vuCRvRTtvSCSSwFQgqdkqAWp17gmekFdaWDbRZcb1pAq1DMhHKqkR2nNYirgpDjDt3md2AXp//g4+miiLz373gSlKOAW6hrm/KPkrzjbanyT8FoHDf/adl8bSbOzHX0+fYbCk8GdkxMxblIAmhHhEw/BDanT5q+EYABoY8c3kKYo8Pu4RRujo0gzribYXLfUCTw42oQjoZPUM+7JG0GIqtc2QLdFfMYTrSs67w5EY7BbSTaiXXL+9VA1WOP3whoiy3icOC9A7AHrUYvmVEH0YbcgLCbDS5DOtKvv6+0K5gRlP5ZF8ob3+IKbX5AUI1rmD9dFa3zZdGAXWkBSjR3oNvp8L4uLYgaXw+fcfGmdkwg+Ks1qld1ToYqXTrHzL3nSFWLkBFi8Pf1CRQdJBp4gmAYEZfDOE=',
        '__VIEWSTATEGENERATOR': '951D8588',
        '__VIEWSTATEENCRYPTED':'',
        '__EVENTVALIDATION': 'qjqpDufMb0At1QgGk4uD6vowvf/C/iTc2ipG39q8Tc6ayAUGuesc9nc5vqKqT1unbFwQkkGN+eUCiwew27wsKTWk0pEnQG5UVcbJq/OH9hklAMdbo6AEOSAYJRzVCuP/DxWZbS5RrMEtOifHJw4xSENUEedGoMzhZKke97EOYcLkUDbFriRQeSEd2GPlgZwOjhm2fbkEwfeVZd0JjcY7xhUqwvJxGq5z2iN3Dd9GBPzlaOVw1Z7vuGe6wokyu9pYFElxzB8vUAN1PVOjkoqd3xT99cBYj7AQM0Hw0E3W73cLQOYFC5vpJLQ+fV7/4gd5Wx66XPYwvfnVp9w7VtskPC36OnN38HNVCLxQ6/8Ayy+kroCTxEJNIlxbNnlMGss5pB8Rk27Xp3M1ksQKJQxMP4jMoFzhTKYBUaEqwGZZ87aF6vGeWG7V+d+VeWJ/hCbSd5lCJJt1RHiyx6Af6aTG5vRlUNZPNkRBIb0SUuG1jFFHpcCmcsK8QLQL1vyZO3gETfTWRgjyiasyxfubiyxMeuSH7TTyxddVxm81eMMimv0JfbbFx86WFKT2AoG2OM29CgXzh2V7Sn27mJB9Hz7TVtcnh1+pymhDZY145ETGjmrb9iNthSToYqQrJYm57AqSx4+KQYCIookpBiRmyRlh+2N2TgML/RnZtmwcP5hTdA2mIO2RUSaJRqUJAbs2SbjprwSHII/8MFGyS06Eh+N5FVKIZ5rO9LcRT+twix745ustlRa3NcDoW53UPHcRzMrfVKBFq4FcZcQb8aUQzfU3wcLVgbAMvFkU4/GOasatY7EfXlIbVklO9S3CL6xStgxCnettdVv9j7KjRdWQN1vkb0owLtcFOzyVivj8YjAJqnSOWWenA8IRUAv+Jd5C6FxHNhCnTdVaBzrx/514Lyh7ZaoR7HFNAftLoWjjnBQrUtq6HaWdBqmp7wwUrYMYBySOT9VtNvAcjEOjhppqFL+Cx7CaZ+iDXnI1fiqp1JUCZfYhJRr13P7WMVXVJ0Wl2qsPcBDvlusGSmq4ppKKwuLm/p/BoMIuu7tHgXABUVpRWNMR5BPQkISNDP9SDy3gAJ54JXMC89a+ezGNAG9ckvqmyiPC1Tu+9yWP4TsTpbLaw2Bs5wC5Kvt91RyF19BYHhFcBX4piFNkruGk+NyowcvNy3sE5rkap42tIpKNmiideFcp14J+pWGOeln2d8gRWO2lF7zCjtAL+RryK/+D7155g21UCeOYWR9CUkdHtCD1gLtWJhgi//Xjm3XwNkyE2PSippF6h2DQL5BPZmvG72HP8P95HdnBj9ovI0wxMZFouZm5eZpNC8suCN82I6zyjA+dMBp6pMhloDU7/SvKo0hg/JGmOnbQztKeduzJ6tazMjuqHMxAiS9AngDZHjfnDndPc3lKliG7VhOtqbnHiWY00KK5AmaSQeelYYTa+u9NA7FL+BMkB3W1KyZ924JlY3baVCYUz+Vv0wCIHCYNmoZuBEKijq2c8qA2TOuTUiMs7walj3gCYuaVyLkdJiX3yYmrKy+Xet/cIsWz5KqGlGjVYHf0ZYpAfhOE7BQw2DoZ5FcMusDWhkldGp+uCsEiRNNEjn6m5M/LrejtZQlj1ISNkYqUFsYD+3zKStVSkshjK+/Ga8ZVJvi7QVr87AR+X7p0xFsl7E/PV/pMok7FOTuw4CmUlG1my1XQiBOq30Y0W4yb5mv0gkb7mbfGcy1vDJBtILUB7dARSDZdD/q9zxUH86H7SZgh7+j1oEeMSO5lUst+ccDFOlp+iAQGRilt30VbO6VijBYi2ZflqwWqbOH/ydxTk+slMiKv0gThgjTS5s4sp81C4x3qQXJNeNQJtjahwbBcXIHonQsJcXPRpJfoEFRW8ecJIZGa8BVZT7TrTUlKnwz3qh61iH3/TibhGpP4IUONkZ6EvXi6sY3/PQADp1IiSKu1qzHnOtq1FXAPDKCW48WRGl8ZbEMBBH84KxjCvf9fBvp7jZboEHCKC5vT69NJ6WgPangYkuO8UFrzQqID5SPLrQZ9Vk94LHNIonhwgWDPtYH/BvhnEhD1bPfm4t/hfySjiz1ePdNYXYVVHlZPy0clZZfKM2GW9mLO/N4WM3GSgmGx3wuCVaYdMO6yx0vJD5v1duhdzOGocxxwTsuGj70DdpxiYTH+yMEOkJLSSEB2DhwytWLsXaVcFnQ02ySAp5jZdENixJJ3S/uShKwlSBSE1PfQZuVoPbjzGOf6bairha39+NoD/H4sW/0O16j2g2QbBIAH56h6OorDHJ2Wmi6hx7VUKu7DaKt3M2yJ+z8ySsyek//CdeGF+Z9fbvVqEFcXikum+nzaw3Xij6rEiP1NOfJIa391CB01s6HyA4vgkwbZwwhCs6jyiPpigucAcnxEjqEAy93Zxy0k7fhWfqsbxQrOGrCE89KJr8ago/AVifgNc81AQot+3P7dRM9+mKbm7XIYm+L6EF3pMYvBNHoewYVYxsgyqZkIVoZw2UrJCfJXgpU1AasxwCVAGlXV/H2ZnOMAcHXcZki6+UEKr4LgYtD7oVUvVznN5W6MzevIvOQXt7/L/8ujlEEUUtPDuzk+FgnHG0qmaP1jSd2yRXQMRQVRww96iSSBZEqpW4j38CQg4uNcPIqRJh5Anh9t9jJewa5dNpDVXLTfNVqbsOOdpRMqtV36T3Tl1iD4Ire8hTPIQ1Pbfzn21rypk9yHRy88zTMhyQDYFGlMAIoFmKDw++976ua9Xz4hf0hPe7DgIIk56+E68dAb9WgmRzu4NxYnN1R4QvBF1PHhzRaHX9QXy8t4D+SAWL1FuaRkIR89OBBOJzy5LG9OaanKR+rzUajPWCHmmdxGzZ0+mrawiUPmQPraSfXQpvAfSYuzYML2nAUbXVZJVC+HRAH5YrNBIO05vHfKV3HZwYTbgq4qDdTmGc9idJLz+JdkRTfl1AYsWUfyshpGT7e3cexw70MsfA16YpqNu9jLaNBzbC0WV+Nue21Ex5XbZVeilw6xIgnfnztX6drqWv2OHAm4Cw8+f10XzAXWeouOjygKLYHN73RGWY3uIFfyhgKwZcENMhwZ27EQII2FHBh78Pw98pIGjgSry2gUEkjTulFesUGDuljKizVi5f8/qv+VAs/3aAv7LwAMzIIOmSnN0A/Wo4OEb9tBtsXdqdIshZBZX6Qoif+qhX2D2dNds1fhixAEVP5UZUkf9kT9UVIl0/UKJDw6AlE377hVGhtkVtxACpJ87lWvsIemtKrdGsbR7Iz3Z9rD3jTCWEGO00VvgxLDKLOke4y8An+e9G2/SCq5uNGspFyUcutMQRndrntqg3mPzAAPuObMDQumS06KXZrP1DwLahev/vZDDgTsyBhEUGaI0EkQpZDJR7sOtaQmbpbFQ521C3EuF/n5T8EJ2bKZtYZjyYe7DakDWq2uZ2on7fzXGdZy5M8eOVu6RwzYA0sXTV5LRyjPvqqcoUxT6hJ6XqLJkSouP0Sigc10zXpF/TaShAVpcDHw3ZWd9PBJQLQYsU+VVTQUmHft9ah8/K4FH7As9Oc6rILT5bQBMREV73KV5VS4ERW9oGPh5XxdoBSM94v3bBkhsVElYlR1ZRm9RUjj5nqhjcpor4vBSfy5tVcnefEGSgtvts+6aq/M6j/2rsgEP+b8kXjMS5xIFoDsL9YmmtG5hHjgcIFR7TcG7G6WshMUSOFI5vnBxBmKsqZ/sx5apPR5aiUktucvqbz5IPGtIc1ukSkMgFXxg+QJDCWhvi8VlIbCK8AJwu89r6zhYBZx8+XEmSwjP1SlwNt8u/GiM3nSEcvQZo7ydKszxwrp3hSlLVFpUr5Qvs4ETAumYVCNCVhGV5bv+fM5I4GRKLMFqGC6vW50I+YbClIFazH4k1FT1mFGfZJQQsLuIMbLX3qrM4FoeWrBX9OGAwfmV0lSUvO812y676EtnBG3os2IJ9afVG+Rx0RTZHFhypM4yxU/ZSyGj3G1rCWL7PRSDnuVa6METgKqbFAEseuK5BcNj0q0x3z6UQInLcJu3MTZvWszLpfVqbkJSKr9OI2Ret2MFKygKPhrUSUQT8cqkHpgzS4c1mIqD0+M4n7iSPq2PIJkFQ+LH1Zmy/QFSb/hsoM2L3sQzoxVPPzGRb5kIE/NEU+nJkye+T2rbt82gKqWqktWZQMATkUMafPBwdNJEWFRsRjiXvPgCi6ktDhqEjKbhgt+BrWzlqdCStOahj3AK9aWgA/WFZrAM5HgXFvvCH16EXOUVX9UB7u4cazgjNWsQRx9zoTQzbFtG3gu9A1CUrpVB2Gf6+9wjLH+HmFF0mzTHLBCrxSUOqBHl1kiw+aDxjlX9MhsSKnORen8V0ncwLVh0NtSaKgmc5Wx7S76MVp3foRKAtAEzYX6OwqARDMtYOM+PEGfSVyvuZ1kIp+IjqGu3g4GJMucJo2zYfuAVsjUc5k642JBKCMsDgMH2rS3nM1MMnAbNnA0ut2s+S0rGcSyQHfOteZ77eT7CKW0xnXHaz7CNfAv+JSsQbxkwd9qQQCc8Lpl37Cio1mA7DEmCdND1ihsZfz5U/vmzd9WCWvZtHszLFP+wqMYrC+83fTOxttE0jOb66qSgOmTK+bKqerGdJGLOHUMpoxTS4Af1y8s8UjNzIRawvz5//trG1AJ01ju191UG/Uvb65LuHHau6Tp3XDL24GGoupL+jP1/uQU6dDp21+6xjK0/j+95yw048rD7yQ18w1zaTqmiaeRHP6dzAoknla72DMPaBKR9lxk8xt7E/68pf6bGYXi6jDD+UFXmkCElmIHjMwsaNPTdgOHnEwcjOWLxG/+YBGVzl9qOzuL6y772eURaDp3cExuZxtLaU54s/lXQ3QmBtjR5XgfS6K4H/EEY/FgcvXmLrF1gBclnjZtOjKl+Pcmk4tKetTd0P0j9M7B3HIbO51mGLwFY/O8sgg/7PYwSyKLyQwG2sstwzqBT5Rb6UfAl+TUEItWOAKTQTr4F+Qnd87mtF7GspLGp5kX5iFIc+8dEFH8phACQTpGwolIp4pRqGqIj26f9yW3mpRgTkt8ZYCEKhWEOcB+Z44zjQuo3h/77OxiG3Il6c6RzxMbbx20Rvsbsd2Z+re90zi+3Sd/KbHvdN3C42ccwMX128sZU97k0tiQk3K8n2Qo1xpR/K9/yhmFuyONPydCSD+b+9AmQyFeUB4NhM9wJf/ITJpHaCKZ8xjzQzpBUYQFATVugI7pNw+NgRRUg6XMP9qwPIvVrgXXFF2zHQedfNB071AyAtTqiQ7mjYFIC6NfErx0zNi1RivRaG1lZErKYsM9rreme02LXCnDhTj+amXVfoss0apDnxcUvmotfFvUoAWus/Mvk+z6ht57C9bYxmXvbls0d9eT6rciTlw3pHUaSu5bj2KmgUkvvQgh7LtiE074EifUXcPbxPM91pH5NEhMDgPaMVGBpUKwxN0hE3ywL8+S+MOZ+ZIVvx22IvENEN48t3zEBvQy3zsfLwBHYqR4oShJiNpLcT6UqHAAWDxeBiWgEEp8zKdDu+/HWBnpQQgQz5HxNOP+1hVUffVpiVGRTibEFsA5YccRRMuXt9fX43iW8whlQltFDd0gKr4Ak5fqdw418vtoYeDaelVuJEZfMhkSFFH2bM5i0Yu+eIvvfBM9LFEZKvxGbolO7xKEW3h6mbq9aUeON2uYQ/3ivA4QfqeTm16kmRvx4QLSBqAxHQ7DLcF/v86tb57OrH2J3+RXpIUMiY/mHz/2GEm92oiv7aUO3NTc5xlQklatsWo8BqavYVM3cDxnFmurXn8hnnvqYtshlWTqVWusE79Lg4ZQFz3yGSw5MubfhLP82+SWgpzQi7Gf8beqGgDojFBZ6FoSs/tdJ7ia7TSc0uwQoJGLmo8l9BwfKAQO6IxNUOOVo4dRODYI3+c+pH/f+qOZwlEhmXDOHnnDfniUX+l2dhwsvK+CEhzeU8XsFj4zq7edHC7GFLZjExTfxhDAzWjaPYbkJbYzqivw3QRHxvIB1Sl8sfE69JqVewyjKA1onZeM4EDZMdqfJwhmhRRQzhkMJ7C73CGcLN6ZjZlTVC25a5BKC+CNTWbTV9f/Z0UmImhV4PP9ZnRBczhP9loGVJT806hxOFYPmFXIXAzUo8JES/tF7NJqr83cQmZ3mlMn5+mGi91T1YicEvm6KS4IwjvEGwAr6wN8qyIblzG8jKCW7tQhrOKUEdyAmlILuoKZiUSEz9Lbi47tP83k+1H94ZYbLk3RExNHFLhOMcWXEaS3uo92brdWtK51P5/59PsFV5Y4XC54L1sv4d8UhZ/Rj2mcmtIawNpUb6zneGj9AzCJAfv6hQyFYZ5l+AmAGNLGsGceH6rMDvoDQNoOuxhrva1aquUA/LIxdAE0cwcxJSo7PiPOchyJvNGwh3Vd0Cw2wHDUKV/Zmj8Pl9LKezTQJWfRrFMLDYvbooqIZX8nhWj9onlorEv0K/LXwBBhkymzHzGVEaeEBvn8COm0fCOgC5qYyIjT1qfstqSF62BkI0j3Cia4it6jYhCNV2fK7d+tZdW2tn46SKlI6+WeTah+llcbeYSt0XKoD0Mg15xdRDIJPJC4gP5jbMRBbZNBTlo9cVd+Tyr+VaXjCSO0ezrzohi/shv1n1fxDIrwbvpd6bN+PDwBIdnuz4O+6LLTmu6n77mMKnY+kCy735D3VaoUEjYRaS5CMz0UhPFncND3WWR039MkoN3rikTJ8Tp2e+qinKIIKgOwbi/Ymng/NvLnDX14Vy03BLHCLQmKLamf9hqT6w/5Y/eHOSFmuv6FT6B0r3BCZKKcHxNLrOvKB13Jx1VcpFWlvWEiz7mFnNZUgGtgk3ke7a+C2HlAMHRYrkzXNwZq3RXM4gIfPER70o4rKg51TJyPJjtIxVl7bs4YtOXB6Cybs1xz1gHcS0rGAhSXsYn7waGv99w4SdgYPdHnov7roJx/rpEA4/KJe9u6wwinDDHNxYAxJDxhygu3ETMrAIrzA604DZnoxHya0wJzaX2lhbNObwA3SCQrkoMY1IUgEBhFed9RMxCXxQLqdDe4NTz9vGESlol4A8JJbyoDTHGbhwpTh4Kv29evJAi7pHgxpMjx1Fo5hCtZgDZn8UyZv0D7aMiiMc/Fx0tBdvdln9FHNKzYBM+3RfL18c6DYc76NK2+vYEpEz93mvohXbFNoPHfCwgAmuoxhxT/UStoFAeFE+2rgbEBaaJxE9ieRNOshDcIVE9tN3FFQ2KbaOJ1oHg5Mf1NfjU+BfcpLHRpe8zrf9bDw4r3HAxJCze/vEab614LTO/k+tlZVcJqFBoj/72OwNl/HSXp5sAvdE/K2D8DPAwatyEilXoGrYcOV3lHshmMuLFJSY7B',
    }

    return(payload)
    
    # print(response.content)



def start_parsing():
    try:
        # connecting to website
        url = create_get_url(HOME_PAGE_URL)
        # for i in range(0,20):
        get_data(url)
        # print(data['data_dict'])
        
    except Exception as e:
        print('Exception while parsing page')
        print(e)
    
    return dict(status='ERROR', message='Exception Occured!!', error_type='EXCEPTION')


def create_combinations():
    try:
        print('creating combination')
        start_parsing()
    except Exception as e:
        print('Exception while creating_combination')
        print(e)


def log_script_stats(st, et):
    dt_format = '%Y-%m-%d %H:%M:%S'
    start_time = st.strftime(dt_format)
    end_time = et.strftime(dt_format)
    print('Combinations Created: started at %s and completed at %s' % (start_time, end_time))


if __name__ == '__main__':
    start_time = datetime.now()
    create_combinations()
    # check()
    end_time = datetime.now()
    log_script_stats(start_time, end_time)

