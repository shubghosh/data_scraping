from requests_toolbelt import MultipartEncoder
from bs4 import BeautifulSoup
import http.client
import requests
from datetime import datetime
import json
import os

http.client.MAXHEADERS = 100000
TIMEOUT = 120

HOME_PAGE_URL = "http://uic.gov.in/frmDisplayCauseList.aspx"
PDF_URL = "http://www.herc.gov.in"

session = requests.Session()
base_url = "http://localhost:1567"


def create_get_url(base_url, data=dict()):
    if len(data) == 0:
        return base_url
    url = base_url + "?"
    for key, val in data.items():
        url += key + "=" + val + "&"
    return url[:-1]


def soup_creator(url):
    return BeautifulSoup(url.text, "html.parser")


def set_payload(cookie):
    payload = {"Cookie": cookie}
    return payload


def set_form_data(token_dict):
    form_data = {
        "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3",
        "Accept-Encoding": "gzip, deflate",
        "Accept-Language": "en-GB,en-US;q=0.9,en;q=0.8",
        "Cache-Control": "max-age=0",
        "Connection": "keep-alive",
        "Content-Length": "3213",
        "Content-Type": "application/x-www-form-urlencoded",
        "Cookie": "_ga=GA1.3.620491047.1567677535; _gid=GA1.3.504063495.1567677535",
        "Host": "uic.gov.in",
        "Origin": "http://uic.gov.in",
        "Referer": "http://uic.gov.in/frmDisplayCauseList.aspx",
        "Upgrade-Insecure-Requests": "1",
        "User-Agent": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_5) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/76.0.3809.132 Safari/537.36",
        "__EVENTTARGET": "RadioButtonList1$1",
        "__EVENTARGUMENT": "",
        "__LASTFOCUS": "",
        "__VIEWSTATE": token_dict["vs"],
        "RadioButtonList1": "Both (Date and Bench)",
        "__EVENTVALIDATION": token_dict["ev"],
    }
    return form_data


def get_pdf(url, name):
    name = name.replace("/", "_")
    name = name.replace(" ", "_")
    name = name.replace(".", "_")
    response = session.get(url)
    file_name = "./PDF_Downloads/" + name + ".pdf"
    with open(file_name, "wb") as f:
        f.write(response.content)


def get_next_page(soup):
    a_tags = soup.find("p", {"class": "paging"}).find_all("a")
    next_page = ""
    for a in a_tags:
        if a.text == "Next":
            next_page = (
                a["href"]
                .split("(")[1]
                .split(")")[0]
                .split(",")[0]
                .replace("'", "")
            )
            return next_page
        else:
            next_page = None
    return next_page


def get_col_data(cols):
    data_dict = {}
    if cols[0]:
        data_dict["date"] = cols[0].text.strip()
    if cols[1]:
        data_dict["pro_ra_no"] = cols[1].text.strip()
    if cols[2]:
        data_dict["petitioner"] = cols[2].text.strip()
    if cols[3]:
        data_dict["respondent"] = cols[3].text.strip()
    if cols[4]:
        data_dict["subject"] = cols[4].text.strip()
    if cols[5]:
        data_dict["pdf_url"] = PDF_URL + cols[5].find("a")["href"]
    response = session.get(data_dict["pdf_url"])
    doc_data = {
        "pdf_link": dict(
            content=response.content,
            content_type=response.headers["Content-Type"],
        )
    }
    data = dict(
        export_type="DATA", record_params=data_dict, doc_params=doc_data
    )
    # api_data = prepare_export_data(data)
    # url = base_url + "/export/data"
    # api_call(url, api_data, api_data.content_type)
    print(data_dict)
    return data_dict


def get_table(token_dict):
    form_data = set_form_data(token_dict)
    response = session.get(HOME_PAGE_URL, timeout=TIMEOUT, data=form_data)
    if response.status_code != 200:
        print("Failed to load home page!!")
        return
    soup = soup_creator(response)
    print(soup)
    exit()
    next_page = get_next_page(soup)
    token_dict["view_state"] = soup.find("input", {"id": "__VIEWSTATE"})[
        "value"
    ]
    token_dict["event_target"] = next_page
    rows = soup.find(
        "table", {"id": "ctl00_cphcontent_cphrightholder_gvDailyOrders"}
    ).find_all("tr")[1:]
    for row in rows:
        cols = row.find_all("td")
        get_col_data(cols)
    return token_dict


def get_token():
    token_dict = {}
    response = session.get(HOME_PAGE_URL)
    if response.status_code != 200:
        print("Failed t load homepage")
        return
    soup = soup_creator(response)
    token_dict["vs"] = soup.find("input", {"id": "__VIEWSTATE"})["value"]
    token_dict["ev"] = soup.find("input", {"id": "__EVENTVALIDATION"})["value"]
    return token_dict


def prepare_export_data(data):
    params = dict(
        export_type=data["export_type"],
        record_params=data["record_params"],
        doc_params=dict(),
    )
    fields = {}
    if "doc_params" in data:
        for k, v in data["doc_params"].items():
            file_name = k
            params["doc_params"][k] = dict(
                content_type=v["content_type"], file_name=file_name
            )
            file_path = "./" + file_name
            with open(file_path, "wb") as f:
                f.write(v["content"])
            fields[file_name] = (
                file_name,
                open(file_path, "rb"),
                v["content_type"],
            )
            os.system("rm " + file_path)
    fields["params"] = json.dumps(params)
    return MultipartEncoder(fields=fields)


def api_call(url, data, content_type="text/plain"):
    try:
        response = requests.post(
            url=url, data=data, headers={"Content-Type": content_type}
        )
        print(response)
        resp = response.json()
        print(resp)
    except Exception as e:
        print("Exception while parsing response")
        print(e)


def start_parsing():
    try:
        # connecting to website
        url = create_get_url(HOME_PAGE_URL)
        token_dict = get_token()
        get_table(token_dict)
        print(token_dict)
        # token_dict = get_table(url)

    except Exception as e:
        print("Exception while parsing page")
        print(e)
    return dict(
        status="ERROR", message="Exception Occured!!", error_type="EXCEPTION"
    )


def create_combinations():
    try:
        print("creating combination")
        start_parsing()
    except Exception as e:
        print("Exception while creating_combination")
        print(e)


def log_script_stats(st, et):
    dt_format = "%Y-%m-%d %H:%M:%S"
    start_time = st.strftime(dt_format)
    end_time = et.strftime(dt_format)
    print(
        "Combinations Created: started at %s and completed at %s"
        % (start_time, end_time)
    )


if __name__ == "__main__":
    start_time = datetime.now()
    create_combinations()
    end_time = datetime.now()
    log_script_stats(start_time, end_time)
    # url = base_url + "/notify"
    # api_call(url, json.dumps(dict(finished=True)))
