from pymongo import MongoClient

MONGO_URL = "3.80.136.128:30006"
MONGO_USERNAME = "kagzat"
MONGO_PASSWORD = "q0xoFtVOc2FzefbcZx9m5yzWNp49tsOH0GNAnQHD1Be1C2h/6eVE/XkW1eqqGnB8"
MONGO_AUTH_SOURCE = "admin"
DB_NAME = "sisyphus_prod_scraping"
COL_NAME = "mca_cin"


def get_collection(db_name, col_name):
    client = MongoClient(
        MONGO_URL,
        username=MONGO_USERNAME,
        password=MONGO_PASSWORD,
        authSource=MONGO_AUTH_SOURCE,
    )
    db = client[db_name]
    return db[col_name]


def get_records():
    col = get_collection(DB_NAME, COL_NAME)
    data_list = []
    try:
        records = col.find({}).limit(100)
        i = 0
        for rec in records:
            print(i, rec)
            data_list.append(rec)
            i += 1
    except Exception as e:
        print(e)


def write_file(records):
    with open("mca_dump.json", "w"):


if __name__ == "__main__":
    get_records()


# mongoexport -h mongodb://kagzat:q0xoFtVOc2FzefbcZx9m5yzWNp49tsOH0GNAnQHD1Be1C2h%2F6eVE%2FXkW1eqqGnB8@3.80.136.128:30006/admin -d sisyphus_prod_scraping -c mca_cin --type=json -q '{}' --out report.json


# mongoexport -h 3.80.136.128:30006 -u kagzat -p q0xoFtVOc2FzefbcZx9m5yzWNp49tsOH0GNAnQHD1Be1C2h/6eVE/XkW1eqqGnB8 --authenticationDatabase admin -d sisyphus_prod_scraping -c mca_cin --type=json -q '{}' --out report.json
