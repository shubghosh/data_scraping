from requests_toolbelt import MultipartEncoder
from bs4 import BeautifulSoup
import http.client

# from datetime import datetime
import requests
import json
import os
import datetime

http.client.MAXHEADERS = 100000
TIMEOUT = 120

HOME_PAGE_URL = "http://chdsdmcentral.gov.in/publicpages/CauseList.aspx"

session = requests.Session()
base_url = "http://localhost:1567"


def create_get_url(base_url, data=dict()):
    if len(data) == 0:
        return base_url
    url = base_url + "?"
    for key, val in data.items():
        url += key + "=" + val + "&"
    return url[:-1]


def soup_creator(url):
    return BeautifulSoup(url.text, "html.parser")


def set_form_data(date, req_data, judge):
    form_data = {
        "__EVENTTARGET": "",
        "__EVENTARGUMENT": "",
        "__VIEWSTATE": req_data["view_state"],
        "__VIEWSTATEGENERATOR": "4330DC88",
        "__VIEWSTATEENCRYPTED": "",
        "__EVENTVALIDATION": req_data["event_validation"],
        "ctl00$ContentPlaceHolder1$BDPLite1$textBox": date,
        "ctl00$ContentPlaceHolder1$ddJudge": judge,
        "ctl00$ContentPlaceHolder1$Button1": "Submit",
    }
    return form_data


def set_form_data_1(date, req_data, judge, page):
    form_data = {
        "ctl00$ContentPlaceHolder1$sc1": "ctl00$ContentPlaceHolder1$sc1|ctl00$ContentPlaceHolder1$ReportViewer1$ctl09$Reserved_AsyncLoadTarget",
        "__EVENTTARGET": "ctl00$ContentPlaceHolder1$ReportViewer1$ctl09$Reserved_AsyncLoadTarget",
        "__EVENTARGUMENT": "",
        "__VIEWSTATE": req_data["view_state"],
        "__VIEWSTATEGENERATOR": "4330DC88",
        "__VIEWSTATEENCRYPTED": "",
        "__EVENTVALIDATION": req_data["event_validation"],
        "ctl00$ContentPlaceHolder1$BDPLite1$textBox": date,
        "ctl00$ContentPlaceHolder1$ddJudge": judge,
        "ctl00$ContentPlaceHolder1$ReportViewer1$ctl03$ctl00": "",
        "ctl00$ContentPlaceHolder1$ReportViewer1$ctl03$ctl01": "",
        "ctl00$ContentPlaceHolder1$ReportViewer1$ctl10": "ltr",
        "ctl00$ContentPlaceHolder1$ReportViewer1$ctl11": "standards",
        "ctl00$ContentPlaceHolder1$ReportViewer1$AsyncWait$HiddenCancelField": "False",
        "ctl00$ContentPlaceHolder1$ReportViewer1$ToggleParam$store": "",
        "ctl00$ContentPlaceHolder1$ReportViewer1$ToggleParam$collapse": "false",
        "ctl00$ContentPlaceHolder1$ReportViewer1$ctl05$ctl00$CurrentPage": page,
        "ctl00$ContentPlaceHolder1$ReportViewer1$ctl05$ctl03$ctl00": "",
        "ctl00$ContentPlaceHolder1$ReportViewer1$ctl08$ClientClickedId": "",
        "ctl00$ContentPlaceHolder1$ReportViewer1$ctl07$store": "",
        "ctl00$ContentPlaceHolder1$ReportViewer1$ctl07$collapse": "false",
        "ctl00$ContentPlaceHolder1$ReportViewer1$ctl09$VisibilityState$ctl00": "None",
        "ctl00$ContentPlaceHolder1$ReportViewer1$ctl09$ScrollPosition": "",
        "ctl00$ContentPlaceHolder1$ReportViewer1$ctl09$ReportControl$ctl02": "",
        "ctl00$ContentPlaceHolder1$ReportViewer1$ctl09$ReportControl$ctl03": "",
        "ctl00$ContentPlaceHolder1$ReportViewer1$ctl09$ReportControl$ctl04": "PageWidth",
        "__ASYNCPOST": "true",
    }
    return form_data


def set_form_data_2(date, req_data, judge, page):
    form_data = {
        "ctl00$ContentPlaceHolder1$sc1": "ctl00$ContentPlaceHolder1$sc1|ctl00$ContentPlaceHolder1$ReportViewer1$ctl05$ctl00$Next$ctl00",
        "ctl00$ContentPlaceHolder1$BDPLite1$textBox": date,
        "ctl00$ContentPlaceHolder1$ddJudge": judge,
        "ctl00$ContentPlaceHolder1$ReportViewer1$ctl03$ctl00": "",
        "ctl00$ContentPlaceHolder1$ReportViewer1$ctl03$ctl01": "",
        "ctl00$ContentPlaceHolder1$ReportViewer1$ctl10": "ltr",
        "ctl00$ContentPlaceHolder1$ReportViewer1$ctl11": "standards",
        "ctl00$ContentPlaceHolder1$ReportViewer1$AsyncWait$HiddenCancelField": "False",
        "ctl00$ContentPlaceHolder1$ReportViewer1$ToggleParam$store": "",
        "ctl00$ContentPlaceHolder1$ReportViewer1$ToggleParam$collapse": "false",
        "ctl00$ContentPlaceHolder1$ReportViewer1$ctl05$ctl00$CurrentPage": page,
        "ctl00$ContentPlaceHolder1$ReportViewer1$ctl05$ctl03$ctl00": "",
        "ctl00$ContentPlaceHolder1$ReportViewer1$ctl08$ClientClickedId": "",
        "ctl00$ContentPlaceHolder1$ReportViewer1$ctl07$store": "",
        "ctl00$ContentPlaceHolder1$ReportViewer1$ctl07$collapse": "false",
        "ctl00$ContentPlaceHolder1$ReportViewer1$ctl09$VisibilityState$ctl00": "ReportPage",
        "ctl00$ContentPlaceHolder1$ReportViewer1$ctl09$ScrollPosition": "",
        "ctl00$ContentPlaceHolder1$ReportViewer1$ctl09$ReportControl$ctl02": "",
        "ctl00$ContentPlaceHolder1$ReportViewer1$ctl09$ReportControl$ctl03": "",
        "ctl00$ContentPlaceHolder1$ReportViewer1$ctl09$ReportControl$ctl04": "PageWidth",
        "__EVENTTARGET": "ctl00$ContentPlaceHolder1$ReportViewer1$ctl05$ctl00$Next$ctl00",
        "__EVENTARGUMENT": "",
        "__VIEWSTATE": req_data["view_state"],
        "__VIEWSTATEGENERATOR": "4330DC88",
        "__EVENTVALIDATION": req_data["event_validation"],
        "__VIEWSTATEENCRYPTED": "",
        "__ASYNCPOST": "true",
    }
    return form_data


def set_payload_1():
    payload = {
        # 'Cache-Control': 'no-cache',
        # 'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
        "Referer": "http://chdsdmcentral.gov.in/publicpages/CauseList.aspx",
        "User-Agent": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_5) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/76.0.3809.87 Safari/537.36",
        # 'X-MicrosoftAjax': 'Delta=true',
        # 'X-Requested-With': 'XMLHttpRequest'
    }
    return payload


def set_payload(req_data):

    payload = {"Cookie": req_data["cookie"]}
    return payload


def get_col_data(rows, response):
    idx = 0
    while idx < len(rows) - 1:
        data_dict = {}
        if rows[idx].text.strip():
            cols = rows[idx].find_all("td")[1:]
            col = rows[idx + 1].find_all("td")[2:]
            data_dict["s_no"] = cols[0].text.strip()
            data_dict["appeal_no"] = cols[1].text.strip()
            data_dict["petitioner"] = col[0].text.strip()
            data_dict["respondent"] = col[2].text.strip()
            data_dict["advocates_representatives"] = col[4].text.strip()
            data_dict["site"] = col[5].text.strip()
            data_dict["stage"] = col[6].text.strip()
            data_dict["last_hearing_date"] = col[7].text.strip()
            idx = idx + 2
            doc_data = {
                "link": dict(
                    content=response.content,
                    content_type=response.headers["Content-Type"],
                )
            }
            data = dict(
                export_type="DATA",
                record_params=data_dict,
                doc_params=doc_data,
            )
            # api_data = prepare_export_data(data)
            # url = base_url + "/export/data"
            # api_call(url, api_data, api_data.content_type)
        else:
            idx = idx + 1
            continue


def get_causelist_data(date, req_data, judge):
    data_dict = {}
    data_list = []
    for page in range(0, 11):
        if page == 0:
            form_data = set_form_data_1(date, req_data, judge, page)
        else:
            form_data = set_form_data_2(date, req_data, judge, page)
        payload_1 = set_payload_1()
        response = session.post(
            HOME_PAGE_URL, data=form_data, headers=payload_1
        )
        if response.status_code != 200:
            print("Failed to load home page!!")
        soup = soup_creator(response)
        with open("resp.txt", "w") as f:
            f.write(response.text)
        div = soup.find("div", {"dir": "LTR"})
        if not div:
            return data_list
        rows = div.find_all("tr", {"valign": "top"})[3:-1]
        data_dict[page] = get_col_data(rows, response)
        data_list.append(data_dict[page])
        t = open("resp.txt")
        lines = t.readlines()
        req_data["view_state"] = lines[10][84:7756][12:]
        req_data["event_validation"] = lines[10][7854:9196][18:]


def get_causelists(date, req_data):
    data_list = []
    data_dict = {}
    for judge in req_data["judges"]:
        print(judge, date)
        form_data = set_form_data(date, req_data, judge)
        payload = set_payload(req_data)
        response = session.post(
            HOME_PAGE_URL, data=form_data, headers=payload, timeout=TIMEOUT
        )
        print(response)
        if response.status_code != 200:
            print("Failed to load home page!!")
            continue
        soup = soup_creator(response)
        print(1)
        req_data["view_state"] = soup.find("input", {"name": "__VIEWSTATE"})[
            "value"
        ]
        req_data["event_validation"] = soup.find(
            "input", {"name": "__EVENTVALIDATION"}
        )["value"]
        data_dict[judge] = get_causelist_data(date, req_data, judge)
        data_list.append(data_dict)
    return data_list


def get_judges(url):
    judges = []
    req_data = {}
    response = session.get(url, timeout=TIMEOUT)
    if response.status_code != 200:
        print("Failed to load home page!!")
    soup = soup_creator(response)
    select = soup.find("select", {"name": "ctl00$ContentPlaceHolder1$ddJudge"})
    options = select.find_all("option")
    cookies = response.headers["Set-Cookie"].split(",")
    req_data["cookie"] = (
        cookies[0].split(";")[0].strip()
        + "; "
        + cookies[2].split(";")[0].strip()
    )
    req_data["view_state"] = soup.find("input", {"name": "__VIEWSTATE"})[
        "value"
    ]
    req_data["event_validation"] = soup.find(
        "input", {"name": "__EVENTVALIDATION"}
    )["value"]
    for option in options:
        judges.append(option["value"].strip())

    req_data["judges"] = judges
    return req_data


def prepare_export_data(data):
    params = dict(
        export_type=data["export_type"],
        record_params=data["record_params"],
        doc_params=dict(),
    )
    fields = {}
    if "doc_params" in data:
        for k, v in data["doc_params"].items():
            file_name = k
            params["doc_params"][k] = dict(
                content_type=v["content_type"], file_name=file_name
            )
            file_path = "./" + file_name
            with open(file_path, "wb") as f:
                f.write(v["content"])
            fields[file_name] = (
                file_name,
                open(file_path, "rb"),
                v["content_type"],
            )
            os.system("rm " + file_path)
    fields["params"] = json.dumps(params)
    return MultipartEncoder(fields=fields)


def api_call(url, data, content_type="text/plain"):
    try:
        response = requests.post(
            url=url, data=data, headers={"Content-Type": content_type}
        )
        print(response)
        resp = response.json()
        print(resp)
    except Exception as e:
        print("Exception while parsing response")
        print(e)


def start_parsing():
    try:
        req_data = get_judges(HOME_PAGE_URL)
        # start_date = '06-Aug-2019'
        start_date = "01-Jan-2019"
        end_date = str(datetime.date.today().strftime("%d-%b-%Y"))
        start = datetime.datetime.strptime(start_date, "%d-%b-%Y")
        end = datetime.datetime.strptime(end_date, "%d-%b-%Y")
        step = datetime.timedelta(days=1)
        while start <= end:
            date = start.date().strftime("%d-%b-%Y")
            get_causelists(str(date), req_data)
            # data_dict[url] = data
            start += step

    except Exception as e:
        print("Exception while parsing page")
        print(e)

    return dict(
        status="ERROR", message="Exception Occured!!", error_type="EXCEPTION"
    )


def create_combinations():
    try:
        print("creating combination")
        start_parsing()
    except Exception as e:
        print("Exception while creating_combination")
        print(e)


if __name__ == "__main__":
    create_combinations()
    # url = base_url + "/notify"
    # api_call(url, json.dumps(dict(finished=True)))
