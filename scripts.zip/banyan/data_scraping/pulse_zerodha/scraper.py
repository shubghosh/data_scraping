from requests_toolbelt import MultipartEncoder
from bs4 import BeautifulSoup
import http.client
import requests
import json
import os


http.client.MAXHEADERS = 100000
TIMEOUT = 120

HOME_PAGE_URL = "https://pulse.zerodha.com/"

session = requests.Session()
base_url = "http://localhost:1567"


def soup_creator(url):
    return BeautifulSoup(url.text, "html.parser")


def get_li_data(li, doc_response):
    data_dict = {}
    try:
        data_dict["article_link"] = li.find("h2").find("a")["href"]
        data_dict["heading"] = li.find("h2").find("a").text.strip()
        data_dict["short_desc"] = li.find("div", {"class": "desc"}).text.strip()
        response = session.get(data_dict["article_link"])
        doc_data = {
            "pdf_link": dict(
                content=response.content,
                content_type=response.headers["Content-Type"],
            ),
            "link": dict(
                content=doc_response.content,
                content_type=response.headers["Content-Type"],
            )
        }
        data = dict(
            export_type="DATA", record_params=data_dict, doc_params=doc_data
        )
        api_data = prepare_export_data(data)
        url = base_url + "/export/data"
        api_call(url, api_data, api_data.content_type)
    except Exception as e:
        print(e)
    return data_dict


def get_data(url):
    data_dict = {}
    data_list = []
    response = session.get(url, timeout=TIMEOUT)
    if response.status_code != 200:
        print("Failed to load home page!!")
        return
    soup = soup_creator(response)
    li_tags = soup.find("ul", {"id": "news"}).find_all("li")
    print(len(li_tags))
    for li in li_tags:
        data_dict = get_li_data(li, response)
        print(data_dict)
        data_list.append(data_dict)
    return data_list


def prepare_export_data(data):
    params = dict(
        export_type=data["export_type"],
        record_params=data["record_params"],
        doc_params=dict(),
    )
    fields = {}
    if "doc_params" in data:
        for k, v in data["doc_params"].items():
            file_name = k
            params["doc_params"][k] = dict(
                content_type=v["content_type"], file_name=file_name
            )
            file_path = "./" + file_name
            with open(file_path, "wb") as f:
                f.write(v["content"])
            fields[file_name] = (file_name, open(file_path, "rb"), v["content_type"])
            os.system("rm " + file_path)
    fields["params"] = json.dumps(params)
    return MultipartEncoder(fields=fields)


def api_call(url, data, content_type="text/plain"):
    try:
        response = requests.post(
            url=url, data=data, headers={"Content-Type": content_type}
        )
        print(response)
        resp = response.json()
        print(resp)
    except Exception as e:
        print("Exception while parsing response")
        print(e)


def start_parsing():
    try:
        # connecting to website
        data_list = get_data(HOME_PAGE_URL)
        print(len(data_list), "DONE")
    except Exception as e:
        print("Exception while parsing page")
        print(e)

    return dict(status="ERROR", message="Exception Occured!!", error_type="EXCEPTION")


def create_combinations():
    try:
        print("creating combination")
        start_parsing()
    except Exception as e:
        print("Exception while creating_combination")
        print(e)


if __name__ == "__main__":
    create_combinations()
    # url = base_url + "/notify"
    # api_call(url, json.dumps(dict(finished=True)))
