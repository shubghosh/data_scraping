from requests_toolbelt import MultipartEncoder
from bs4 import BeautifulSoup
import http.client
import requests
import json
import os

http.client.MAXHEADERS = 100000
TIMEOUT = 120

HOME_PAGE_URL = "http://ghcazlbench.nic.in/Judgement.htm"
PDF_URL = "http://ghcazlbench.nic.in/"
PAGE_URL = "http://ghcazlbench.nic.in/"

session = requests.Session()
base_url = "http://localhost:1567"


def create_get_url(base_url, data=dict()):
    if len(data) == 0:
        return base_url
    url = base_url + "?"
    for key, val in data.items():
        url += key + "=" + val + "&"
    return url[:-1]


def soup_creator(url):
    return BeautifulSoup(url.text, "lxml")


def get_pdf(url, name):
    name = name.replace("/", "_")
    name = name.replace(".", "_")
    name = name.replace("-", "_")
    response = session.get(url)
    file_name = "./PDF_Downloads/" + name + ".pdf"
    with open(file_name, "wb") as f:
        f.write(response.content)


def get_col_data(cols, a, doc_response):
    data_dict = {}
    if len(cols) > 4:
        data_dict["case_no"] = a.text.strip()
        data_dict["pdf_url"] = a["href"]
        data_dict["judgement_date"] = cols[0].text.strip()
        data_dict["petitioner_name"] = cols[2].text.strip().split("vs")[0].strip()
        data_dict["respondent_name"] = cols[2].text.strip().split("vs")[1].strip()
        data_dict["subject"] = cols[3].text.strip()
        data_dict["judgement_delivered_by"] = cols[4].text.strip()
    else:
        data_dict["pdf_url"] = PDF_URL + a["href"]
        data_dict["judgement_date"] = cols[0].text.strip()
        data_dict["case_no"] = a.text.strip()
        data_dict["petitioner"] = cols[1].text.strip()
        data_dict["respondent"] = cols[2].text.strip()
        data_dict["judgement_delivered_by"] = cols[3].text.strip()

    print(data_dict)
    response = session.get(data_dict["pdf_url"])
    doc_data = {
        "link": dict(
            content=doc_response.content,
            content_type=doc_response.headers["Content-Type"],
        ),
        "pdf_link": dict(
            content=response.content, content_type=response.headers["Content-Type"]
        ),
    }
    data = dict(export_type="DATA", record_params=data_dict, doc_params=doc_data)
    api_data = prepare_export_data(data)
    url = base_url + "/export/data"
    api_call(url, api_data, api_data.content_type)


def get_data(data):
    for year in data["years"]:
        for month in data["months"]:
            url = PAGE_URL + month + str(year) + ".htm"
            response = session.get(url)
            if response.status_code != 200:
                print("Failed to load page")
                continue
            soup = soup_creator(response)
            rows = soup.find("table", {"id": "mytable"}).find_all("tr")[1:]
            for row in rows:
                a = row.find("a")
                cols = row.find_all("td")
                get_col_data(cols, a, response)


def get_year(url):
    yr = []
    mnth = []
    data = {}
    response = session.get(url, timeout=TIMEOUT)
    if response.status_code != 200:
        print("Failed to load home page!!")
        return
    soup = soup_creator(response)
    years = soup.find("select", {"id": "year"}).find_all("option")
    months = soup.find("select", {"id": "qtr"}).find_all("option")
    for year in years:
        yr.append(year["value"])
    for month in months:
        mnth.append(month["value"])
    data["years"] = yr
    data["months"] = mnth
    return data


def prepare_export_data(data):
    params = dict(
        export_type=data["export_type"],
        record_params=data["record_params"],
        doc_params=dict(),
    )
    fields = {}
    if "doc_params" in data:
        for k, v in data["doc_params"].items():
            file_name = k
            params["doc_params"][k] = dict(
                content_type=v["content_type"], file_name=file_name
            )
            file_path = "./" + file_name
            with open(file_path, "wb") as f:
                f.write(v["content"])
            fields[file_name] = (file_name, open(file_path, "rb"), v["content_type"])
            os.system("rm " + file_path)
    fields["params"] = json.dumps(params)
    return MultipartEncoder(fields=fields)


def api_call(url, data, content_type="text/plain"):
    try:
        response = requests.post(
            url=url, data=data, headers={"Content-Type": content_type}
        )
        print(response)
        resp = response.json()
        print(resp)
    except Exception as e:
        print("Exception while parsing response")
        print(e)


def start_parsing():
    try:
        # connecting to website
        url = create_get_url(HOME_PAGE_URL)
        data = get_year(url)
        get_data(data)

    except Exception as e:
        print("Exception while parsing page")
        print(e)

    return dict(status="ERROR", message="Exception Occured!!", error_type="EXCEPTION")


def create_combinations():
    try:
        print("creating combination")
        start_parsing()
    except Exception as e:
        print("Exception while creating_combination")
        print(e)


def log_script_stats(st, et):
    dt_format = "%Y-%m-%d %H:%M:%S"
    start_time = st.strftime(dt_format)
    end_time = et.strftime(dt_format)
    print(
        "Combinations Created: started at %s and completed at %s"
        % (start_time, end_time)
    )


if __name__ == "__main__":
    create_combinations()
    url = base_url + "/notify"
    api_call(url, json.dumps(dict(finished=True)))

