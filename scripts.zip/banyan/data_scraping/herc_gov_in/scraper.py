from requests_toolbelt import MultipartEncoder
from bs4 import BeautifulSoup
import http.client
import requests
from datetime import datetime
import json
import os

http.client.MAXHEADERS = 100000
TIMEOUT = 120

HOME_PAGE_URL = "http://www.herc.gov.in/CurrentDailyOrders.aspx"
PDF_URL = "http://www.herc.gov.in"

session = requests.Session()
base_url = "http://localhost:1567"


def create_get_url(base_url, data=dict()):
    if len(data) == 0:
        return base_url
    url = base_url + "?"
    for key, val in data.items():
        url += key + "=" + val + "&"
    return url[:-1]


def soup_creator(url):
    return BeautifulSoup(url.text, "html.parser")


def set_payload(cookie):
    payload = {"Cookie": cookie}
    return payload


def set_form_data(token_dict):
    form_data = {
        "ctl00_ScriptManager_HiddenField": "",
        "__EVENTTARGET": token_dict["event_target"],
        "__EVENTARGUMENT": "",
        "__LASTFOCUS": "",
        "__VIEWSTATE": token_dict["view_state"],
        "__VIEWSTATEGENERATOR": "D00FAFC8",
        "__SCROLLPOSITIONX": "78",
        "__SCROLLPOSITIONY": "1006",
        "__VIEWSTATEENCRYPTED": "",
        "ctl00$ucSearch$cx": "013280925726808751639:i85g1b47nss",
        "ctl00$ucSearch$cof": "FORID:9",
        "ctl00$ucSearch$txtSearch": "Enter Your Keywords",
        "ctl00$cphcontent$cphrightholder$gvDailyOrders$ctl02$hdfFile": "",
        "ctl00$cphcontent$cphrightholder$gvDailyOrders$ctl03$hdfFile": "",
        "ctl00$cphcontent$cphrightholder$gvDailyOrders$ctl04$hdfFile": "",
        "ctl00$cphcontent$cphrightholder$gvDailyOrders$ctl05$hdfFile": "",
        "ctl00$cphcontent$cphrightholder$gvDailyOrders$ctl06$hdfFile": "",
        "ctl00$cphcontent$cphrightholder$gvDailyOrders$ctl07$hdfFile": "",
        "ctl00$cphcontent$cphrightholder$gvDailyOrders$ctl08$hdfFile": "",
        "ctl00$cphcontent$cphrightholder$gvDailyOrders$ctl09$hdfFile": "",
        "ctl00$cphcontent$cphrightholder$gvDailyOrders$ctl10$hdfFile": "",
        "ctl00$cphcontent$cphrightholder$gvDailyOrders$ctl11$hdfFile": "",
        "ctl00$cphcontent$cphrightholder$ddlPageSize": "10",
    }
    return form_data


def get_pdf(url, name):
    name = name.replace("/", "_")
    name = name.replace(" ", "_")
    name = name.replace(".", "_")
    response = session.get(url)
    file_name = "./PDF_Downloads/" + name + ".pdf"
    with open(file_name, "wb") as f:
        f.write(response.content)


def get_next_page(soup):
    a_tags = soup.find("p", {"class": "paging"}).find_all("a")
    next_page = ""
    for a in a_tags:
        if a.text == "Next":
            next_page = (
                a["href"]
                .split("(")[1]
                .split(")")[0]
                .split(",")[0]
                .replace("'", "")
            )
            return next_page
        else:
            next_page = None
    return next_page


def get_col_data(cols):
    data_dict = {}
    if cols[0]:
        data_dict["date"] = cols[0].text.strip()
    if cols[1]:
        data_dict["pro_ra_no"] = cols[1].text.strip()
    if cols[2]:
        data_dict["petitioner"] = cols[2].text.strip()
    if cols[3]:
        data_dict["respondent"] = cols[3].text.strip()
    if cols[4]:
        data_dict["subject"] = cols[4].text.strip()
    if cols[5]:
        data_dict["pdf_url"] = PDF_URL + cols[5].find("a")["href"]
    response = session.get(data_dict["pdf_url"])
    doc_data = {
        "pdf_link": dict(
            content=response.content,
            content_type=response.headers["Content-Type"],
        )
    }
    data = dict(
        export_type="DATA", record_params=data_dict, doc_params=doc_data
    )
    # api_data = prepare_export_data(data)
    # url = base_url + "/export/data"
    # api_call(url, api_data, api_data.content_type)
    print(data_dict)
    return data_dict


def get_table_data(token_dict, cookie):
    form_data = set_form_data(token_dict)
    payload = set_payload(cookie)
    print("in get table data")
    response = session.post(
        HOME_PAGE_URL, data=form_data, headers=payload, timeout=TIMEOUT
    )
    if response.status_code != 200:
        print("Failed to load home page!!")
        return
    soup = soup_creator(response)
    next_page = get_next_page(soup)
    token_dict["view_state"] = soup.find("input", {"id": "__VIEWSTATE"})[
        "value"
    ]
    token_dict["event_target"] = next_page
    rows = soup.find(
        "table", {"id": "ctl00_cphcontent_cphrightholder_gvDailyOrders"}
    ).find_all("tr")[1:]
    for row in rows:
        cols = row.find_all("td")
        get_col_data(cols)
    return token_dict


def get_table(url):
    token_dict = {}
    response = session.get(url, timeout=TIMEOUT)
    if response.status_code != 200:
        print("Failed to load home page!!")
        return
    soup = soup_creator(response)
    next_page = get_next_page(soup)
    token_dict["view_state"] = soup.find("input", {"id": "__VIEWSTATE"})[
        "value"
    ]
    token_dict["event_target"] = next_page
    rows = soup.find(
        "table", {"id": "ctl00_cphcontent_cphrightholder_gvDailyOrders"}
    ).find_all("tr")[1:]
    for row in rows:
        cols = row.find_all("td")
        get_col_data(cols)
    return token_dict


def get_cookie():
    response = session.get(HOME_PAGE_URL)
    cookie = response.headers["Set-Cookie"]
    cookie = cookie.split(";")
    cookie = cookie[2].split(",")[1].strip() + "; " + cookie[0]
    return cookie


def prepare_export_data(data):
    params = dict(
        export_type=data["export_type"],
        record_params=data["record_params"],
        doc_params=dict(),
    )
    fields = {}
    if "doc_params" in data:
        for k, v in data["doc_params"].items():
            file_name = k
            params["doc_params"][k] = dict(
                content_type=v["content_type"], file_name=file_name
            )
            file_path = "./" + file_name
            with open(file_path, "wb") as f:
                f.write(v["content"])
            fields[file_name] = (
                file_name,
                open(file_path, "rb"),
                v["content_type"],
            )
            os.system("rm " + file_path)
    fields["params"] = json.dumps(params)
    return MultipartEncoder(fields=fields)


def api_call(url, data, content_type="text/plain"):
    try:
        response = requests.post(
            url=url, data=data, headers={"Content-Type": content_type}
        )
        print(response)
        resp = response.json()
        print(resp)
    except Exception as e:
        print("Exception while parsing response")
        print(e)


def start_parsing():
    try:
        # connecting to website
        url = create_get_url(HOME_PAGE_URL)
        cookie = get_cookie()
        token_dict = get_table(url)
        while token_dict["event_target"]:
            try:
                token_dict = get_table_data(token_dict, cookie)
            except Exception as e:
                print("Exception while parsing page")
                print(e)
        print(token_dict["event_target"])
    except Exception as e:
        print("Exception while parsing page")
        print(e)
    return dict(
        status="ERROR", message="Exception Occured!!", error_type="EXCEPTION"
    )


def create_combinations():
    try:
        print("creating combination")
        start_parsing()
    except Exception as e:
        print("Exception while creating_combination")
        print(e)


def log_script_stats(st, et):
    dt_format = "%Y-%m-%d %H:%M:%S"
    start_time = st.strftime(dt_format)
    end_time = et.strftime(dt_format)
    print(
        "Combinations Created: started at %s and completed at %s"
        % (start_time, end_time)
    )


if __name__ == "__main__":
    start_time = datetime.now()
    create_combinations()
    end_time = datetime.now()
    log_script_stats(start_time, end_time)
    # url = base_url + "/notify"
    # api_call(url, json.dumps(dict(finished=True)))
