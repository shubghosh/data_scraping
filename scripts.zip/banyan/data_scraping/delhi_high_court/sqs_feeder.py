from bs4 import BeautifulSoup
from datetime import datetime, timedelta
from threading import Thread
import requests
import boto3
import http.client
import json

AVG_THRESHOLD = 60
PARSED_TILL = "31-12-1989"

http.client._MAXHEADERS = 100000
TIMEOUT = 120

HOME_PAGE_URL = "http://lobis.nic.in/dhcindex.php?cat=1&hc=31"
JUDGE_URL = "http://lobis.nic.in/judname.php?scode=31"
RECORD_URL = "http://lobis.nic.in/judname1.php?scode=31&fflag=1"
PAGE_URL = "http://lobis.nic.in"
PDF_URL = "http://lobis.nic.in"


ACCESS_KEY = "AKIAJQMKT7WP26VWAKOA"
SECRET_KEY = "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"
QUEUE_URL = "https://sqs.ap-south-1.amazonaws.com/449052551048/delhi_high_court"

sqs = boto3.resource(
    "sqs",
    region_name="ap-south-1",
    aws_access_key_id=ACCESS_KEY,
    aws_secret_access_key=SECRET_KEY,
)

session = requests.Session()


def soup_creator(url):
    return BeautifulSoup(url.text, "html.parser")


def set_payload(cookie):
    payload = {"Cookie": cookie}
    return payload


def feed_sqs(combs):
    # feed sqs here
    print("feeding sqs:")
    print(json.dumps(combs))
    messages = []
    for msg in combs:
        messages.append(msg)
        if len(messages) >= 10:
            Thread(target=send_messages, args=[messages]).start()
            messages = []
    if len(messages) > 0:
        Thread(target=send_messages, args=[messages]).start()


def send_messages(messages):
    entries = []
    i = 1
    for msg in messages:
        entries.append({"Id": str(i), "MessageBody": json.dumps(msg)})
        i += 1
    queue = sqs.Queue(QUEUE_URL)
    queue.send_messages(Entries=entries)


def get_judges(token_dict):
    judges = []
    # form_data = set_form_data(token_dict["input_digit"])
    payload = set_payload(token_dict["cookie"])
    response = session.post(JUDGE_URL, data={"Submit2": "Judge Name"}, headers=payload)
    if response.status_code != 200:
        print("Failed to Load Page")
        return
    soup = soup_creator(response)
    options = soup.find("select").find_all("option")[1:]
    for option in options:
        if option["value"]:
            judges.append({option["value"]: option.text.strip()})
    print(judges)
    print(len(judges))
    return judges


def get_cookie(url):
    token_dict = {}
    response = session.get(url)
    if response.status_code != 200:
        print("Failed to load page")
        return
    token_dict["cookie"] = response.headers["Set-Cookie"].split(";")[0]
    # soup = soup_creator(response)
    # token_dict["input_digit"] = soup.find("input", {"id": "hiddeninputdigit"})["value"]
    return token_dict


def create_sqs_comb(judges, start_date, end_date):
    combs = []
    for judge in judges:
        comb_dict = {}
        comb_dict["judge_id"] = list(judge.keys())[0]
        comb_dict['judge_name'] = judge[list(judge.keys())[0]]
        start = datetime.strptime(start_date, "%d/%m/%Y")
        end = datetime.strptime(end_date, "%d/%m/%Y")
        step = timedelta(days=90)
        while start < end:
            strt_date = str(start.strftime("%d/%m/%Y"))
            en_date = str((start + step).strftime("%d/%m/%Y"))
            start += step
            comb_dict["start_date"] = strt_date
            comb_dict["end_date"] = en_date
            # print(comb_dict)
            combs.append(comb_dict)
    return combs


def start_parsing(start_date, end_date):
    try:
        token_dict = get_cookie(HOME_PAGE_URL)
        token_dict["judges"] = get_judges(token_dict)
        combs = create_sqs_comb(token_dict["judges"], start_date, end_date)
        print("Combinations Create:", len(combs))
        feed_sqs(combs)
    except Exception as e:
        print("Exception while creating combination")
        print(e)
        pass


def create_combinations(start_date, end_date):
    try:
        print("creating combination")
        start_parsing(start_date, end_date)
    except Exception as e:
        print("Exception while creating_combination")
        print(e)


if __name__ == "__main__":
    # fetch high court mapping from the database, create date-range combinations for the same.
    # after create combination insert them to sqs queue.
    start_date = "01/01/1950"
    end_date = "18/10/2019"
    create_combinations(start_date, end_date)
