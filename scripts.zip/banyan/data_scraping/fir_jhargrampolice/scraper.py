from bs4 import BeautifulSoup
import http.client
import re 
from datetime import datetime
import hashlib
import requests
import json
import subprocess
import os


http.client.MAXHEADERS = 100000
TIMEOUT = 120

HOME_PAGE_URL = 'http://jhargrampolice.in/fir'
TOKEN_URL = ''
PDF_URL = 'http://jhargrampolice.in/'

session = requests.Session()

def create_get_url(base_url, data=dict()):
    if len(data) == 0:
        return base_url
    url = base_url + '?'
    for key, val in data.items():
        url += key + '=' + val + '&'
    return url[:-1]

def soup_creator(url):
    return BeautifulSoup(url.text, 'html.parser')

def set_form_data(ps):
    form_data = {
        'name1': ps,
    }
    return form_data


def get_pdf(url,name):
    name = name.replace('/','_')
    response = session.get(url)
    file_name = './PDF_Downloads/'+name+'.pdf'
    with open(file_name,'wb') as f:
        f.write(response.content)


def get_records(ps_list, url):
    data_dict = {}
    data_list = []
    for ps in ps_list:
        print(ps)
        form_data = set_form_data(ps)
        response = session.post(url, data=form_data, timeout=TIMEOUT)
        if response.status_code != 200:
            print('Failed to load home page!!')
            return
        soup = soup_creator(response)
        script = soup.find_all('script')
        data = script[-2].text.split('data:')[1]
        data = data.replace('\t','')    
        data = data.split('\n')[1:-8]
        for d in data:
            text = d.split('{')[1].split('}')[0].split(',')
            data_dict['s_no'] = text[0].split(':')[1].strip().replace('\'','')
            data_dict['date'] = text[1].split(':')[1].strip().replace('\'','')
            data_dict['fir_no'] = text[2].split(':')[1].strip().replace('\'','')
            pdf_url = text[3].split(':')[1].split('=')[1].split(' ')[0].replace('"','')
            data_dict['pdf_url'] = PDF_URL + pdf_url
            data_dict['police_station'] = ps
            print(data_dict)
            get_pdf(data_dict['pdf_url'], data_dict['fir_no'])
            data_list.append(data_dict)
        print(ps)
        print('***************************************************************************************************')    
    return data_list


def get_police_stations(url):
    ps_list = []
    response = session.get(url, timeout=TIMEOUT)
    if response.status_code != 200:
        print('Failed to load home page!!')
        return
    soup = soup_creator(response)
    options = soup.find_all('option')[1:]
    for optn in options:
        ps = optn['value']
        ps_list.append(ps)
    return ps_list

def start_parsing():
    try:
        # connecting to website
        url = create_get_url(HOME_PAGE_URL)
        ps_list = get_police_stations(url)
        print(len(ps_list))
        data_list = get_records(ps_list, url)
    except Exception as e:
        print('Exception while parsing page')
        print(e)
    
    return dict(status='ERROR', message='Exception Occured!!', error_type='EXCEPTION')


def create_combinations():
    try:
        print('creating combination')
        start_parsing()
    except Exception as e:
        print('Exception while creating_combination')
        print(e)


def log_script_stats(st, et):
    dt_format = '%Y-%m-%d %H:%M:%S'
    start_time = st.strftime(dt_format)
    end_time = et.strftime(dt_format)
    print('Combinations Created: started at %s and completed at %s' % (start_time, end_time))


if __name__ == '__main__':
    start_time = datetime.now()
    create_combinations()
    end_time = datetime.now()
    log_script_stats(start_time, end_time)

