from bs4 import BeautifulSoup
import http.client
import re 
from datetime import datetime
import hashlib
import requests
import json
import subprocess
import os
from selenium import webdriver
import time


http.client.MAXHEADERS = 100000
TIMEOUT = 120

HOME_PAGE_URL = 'https://uttardinajpurpolice.co.in/fir/'
TOKEN_URL = 'https://uttardinajpurpolice.co.in/cdn-cgi/l/chk_jschl?'
PDF_URL = ''

session = requests.Session()

def create_get_url(base_url, data=dict()):
    if len(data) == 0:
        return base_url
    url = base_url + '?'
    for key, val in data.items():
        url += key + '=' + val + '&'
    return url[:-1]

def soup_creator(url):
    if isinstance(url,str):
        return BeautifulSoup(url,'html.parser')
    else:
        return BeautifulSoup(url.text, 'html.parser')

def set_payload(cookie):
    payload = {
        'cookie': cookie,
        }
    return payload


def get_pdf(url,name):
    name = name.replace('/','_')
    name = name.replace('.','_')
    name = name.replace(' ','_')
    # response = session.get(url)
    download_dir = '/Users/shubhankar/banyan/data_scraping/fir_uttar_dinajpur/PDF_Downloads'#+name+'.pdf'
    # with open(file_name,'wb') as f:
    #     f.write(response.content)

    # driver = webdriver.Chrome()
    # driver.get(url)
    # print(url)
    # time.sleep(10)
    # print(dir(driver))

    # options = webdriver.ChromeOptions()

    # profile = {"plugins.plugins_list": [{"enabled": False, "name": "Chrome PDF Viewer"}], # Disable Chrome's PDF Viewer
    #             "download.default_directory": download_dir , "download.extensions_to_open": "applications/pdf"}
    # options.add_experimental_option("prefs", profile)
    # driver = webdriver.Chrome(chrome_options=options)  # Optional argument, if not specified will search path.
    
    options = webdriver.ChromeOptions()
    options.add_experimental_option('prefs', {
    "download.default_directory": download_dir, #Change default directory for downloads
    "download.prompt_for_download": False, #To auto download the file
    "download.directory_upgrade": True,
    "plugins.always_open_pdf_externally": True #It will not show PDF directly in chrome
    })
    driver = webdriver.Chrome(options=options)
    driver.get(url)
    print(url)
    time.sleep(10)

def get_col_data(cols):
    data_dict = {}
    print(cols)
    data_dict['date'] = cols[0].text.strip()
    url = PDF_URL + cols[1].find('a')['href']
    data_dict['pdf_url'] = url 
    get_pdf(url,data_dict['date'])
    return data_dict

def get_next_page(soup):

    a_tag = soup.find('a',{'class':'pagination-next'})
    if a_tag:
        url = a_tag['href']
        return url
    else:
        return None


def get_records(soup):
    data_list = []
    data = {}
    next_page = get_next_page(soup)
    print(next_page)
    divs = soup.find_all('div',{'class':'fusion-two-third fusion-layout-column fusion-spacing-yes'})

    for div in divs:
        data_dict = {}
        url_div = div.find_next('div',{'class':'fusion-one-third one_third fusion-layout-column fusion-column-last fusion-spacing-yes'})
        pdf_url = url_div.find('a')['href']
        text = div.text.strip().split('\n')
        fir = text[0].split('NO-')[1].split(' ') 
        data_dict['fir_no'] = fir[0]
        data_dict['fir_date'] = fir[1].replace('DT-','')
        data_dict['police_station'] = text[1].split(':')[1]
        data_dict['fir_updated_date'] = text[2].split(':')[1]
        data_dict['pdf_url'] = pdf_url
        print(data_dict)
        get_pdf(data_dict['pdf_url'],text[0])
        data_list.append(data_dict)

        break
    data['next_page'] = next_page
    data['data_list'] = data_list
    return data_list



def get_selenium_html(url):
    driver = webdriver.Chrome()
    driver.get(HOME_PAGE_URL)
    time.sleep(10)
    source = driver.page_source
    soup = soup_creator(source)
    return soup


def start_parsing():
    try:
        # connecting to website
        url = create_get_url(HOME_PAGE_URL)
        soup = get_selenium_html(url)
        data = get_records(soup)
        i=1
        # while data['next_page']:
        #     i=i+1
        #     print("--------------------------------------------------------------------------------------------------------------")
        #     soup = get_selenium_html(url)
        #     data = get_records(soup)
        print(i)

    except Exception as e:
        print('Exception while parsing page')
        print(e)
    
    return dict(status='ERROR', message='Exception Occured!!', error_type='EXCEPTION')


def create_combinations():
    try:
        print('creating combination')
        start_parsing()
    except Exception as e:
        print('Exception while creating_combination')
        print(e)


def log_script_stats(st, et):
    dt_format = '%Y-%m-%d %H:%M:%S'
    start_time = st.strftime(dt_format)
    end_time = et.strftime(dt_format)
    print('Combinations Created: started at %s and completed at %s' % (start_time, end_time))


if __name__ == '__main__':
    start_time = datetime.now()
    create_combinations()
    end_time = datetime.now()
    log_script_stats(start_time, end_time)

