from bs4 import BeautifulSoup
import http.client
import re
from datetime import datetime
import hashlib
import requests
import json
import subprocess
import os
import datetime

http.client.MAXHEADERS = 100000
TIMEOUT = 120

HOME_PAGE_URL = "http://hryrevenuecourts.gov.in/frmPublicCauseList.aspx?cc=0"
RECORD_PAGE_URL = "http://hryrevenuecourts.gov.in/repPublicCauselist.aspx"
session = requests.Session()


def create_get_url(base_url, data=dict()):
    if len(data) == 0:
        return base_url
    url = base_url + "?"
    for key, val in data.items():
        url += key + "=" + val + "&"
    return url[:-1]


def soup_creator(url):
    return BeautifulSoup(url.text, "html.parser")


def set_form_data_cities(city, req_data):
    form_data = {
        "__EVENTTARGET": "ctl00$ContentPlaceHolder1$ddlDistrict",
        "__EVENTARGUMENT": "",
        "__LASTFOCUS": "",
        "__VIEWSTATE": req_data["view_state"],
        "__VIEWSTATEGENERATOR": "38B1E8CF",
        "ctl00$ContentPlaceHolder1$ddlDistrict": str(city),
        "ctl00$ContentPlaceHolder1$txtDate": "13/08/2019",
    }

    return form_data


def set_form_data_courts(date, city, court, req_data):
    form_data = {
        "__EVENTTARGET": "",
        "__EVENTARGUMENT": "",
        "__LASTFOCUS": "",
        "__VIEWSTATE": req_data["view_state"],
        "__VIEWSTATEGENERATOR": "38B1E8CF",
        "ctl00$ContentPlaceHolder1$ddlDistrict": city,
        "ctl00$ContentPlaceHolder1$ddlCourt": court,
        "ctl00$ContentPlaceHolder1$txtDate": "27/08/2019",
        "ctl00$ContentPlaceHolder1$btnSubmit": "Submit",
    }
    return form_data


def set_form_data_records(req_data):
    form_data = {
        "ScriptManager1": "ScriptManager1|ReportViewer1$ctl09$Reserved_AsyncLoadTarget",
        "__EVENTTARGET": "ReportViewer1$ctl09$Reserved_AsyncLoadTarget",
        "__EVENTARGUMENT": "",
        "__VIEWSTATE": req_data["view_state"],
        "__VIEWSTATEGENERATOR": "71B87CEE",
        "ReportViewer1$ctl03$ctl00": "",
        "ReportViewer1$ctl03$ctl01": "",
        "ReportViewer1$ctl10": "ltr",
        "ReportViewer1$ctl11": "standards",
        "ReportViewer1$AsyncWait$HiddenCancelField": "False",
        "ReportViewer1$ToggleParam$store": "",
        "ReportViewer1$ToggleParam$collapse": "false",
        "ReportViewer1$ctl05$ctl00$CurrentPage": "",
        "ReportViewer1$ctl05$ctl03$ctl00": "",
        "ReportViewer1$ctl08$ClientClickedId": "",
        "ReportViewer1$ctl07$store": "",
        "ReportViewer1$ctl07$collapse": "false",
        "ReportViewer1$ctl09$VisibilityState$ctl00": "None",
        "ReportViewer1$ctl09$ScrollPosition": "",
        "ReportViewer1$ctl09$ReportControl$ctl02": "",
        "ReportViewer1$ctl09$ReportControl$ctl03": "",
        "ReportViewer1$ctl09$ReportControl$ctl04": "100",
        "__ASYNCPOST": "true",
    }

    return form_data


def set_payload_cities(cookie):
    payload = {"Cookie": cookie + "; expandable=0c"}
    return payload


def set_payload_courts(cookie):
    payload = {"Cookie": cookie + "; expandable=0c"}
    return payload


def set_payload_records(cookie):
    payload = {
        "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3",
        "Accept-Encoding": "gzip, deflate",
        "Accept-Language": "en-GB,en-US;q=0.9,en;q=0.8",
        "Cache-Control": "max-age=0",
        "Connection": "keep-alive",
        "Content-Type": "application/x-www-form-urlencoded",
        "Cookie": cookie + "; expandable=0c",
        "Host": "hryrevenuecourts.gov.in",
        "Origin": "http://hryrevenuecourts.gov.in",
        "Referer": "http://hryrevenuecourts.gov.in/frmPublicCauseList.aspx",
        "Upgrade-Insecure-Requests": "1",
        "User-Agent": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_5) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/76.0.3809.100 Safari/537.36",
    }
    return payload


def get_records(date, req_data):

    for cities in req_data["cities"]:
        for city in cities:
            courts = cities[city]
            for court in courts:
                payload = set_payload_records(req_data["cookie"])
                form_data_records = set_form_data_courts(
                    date, city, court, req_data
                )
                # print(payload)
                # print(form_data_cities)

                response = session.post(
                    HOME_PAGE_URL, data=form_data_records, headers=payload
                )
                # print(response.headers)
                # print(response.url)
                # print(response.history)
                if response.status_code != 200:
                    print("Failed to load home page!!")
                    return
                soup = soup_creator(response)
                print(soup)
                print(form_data_records)
                print(response)
                break
            break
        break
    return {}


def get_court(req_data):
    payload = set_payload_cities(req_data["cookie"])
    list = []
    for city in req_data["cities"]:
        city_data = {}
        courts = []
        form_data_cities = set_form_data_cities(city, req_data)
        response = session.post(
            HOME_PAGE_URL, data=form_data_cities, headers=payload
        )
        if response.status_code != 200:
            print("Failed to load home page!!")
            return
        soup = soup_creator(response)
        req_data["view_state"] = soup.find("input", {"name": "__VIEWSTATE"})[
            "value"
        ]
        select = soup.find(
            "select", {"name": "ctl00$ContentPlaceHolder1$ddlCourt"}
        )
        options = select.find_all("option")[1:]
        for option in options:
            courts.append(option["value"])
        city_data[city] = courts
        list.append(city_data)
    req_data["cities"] = list
    return req_data


def get_cities(url):
    cities = []
    req_data = {}
    response = session.get(url, timeout=TIMEOUT)
    if response.status_code != 200:
        print("Failed to load home page!!")
    soup = soup_creator(response)
    select = soup.find(
        "select", {"name": "ctl00$ContentPlaceHolder1$ddlDistrict"}
    )
    options = select.find_all("option")[1:]
    cookies = response.headers["Set-Cookie"].split(";")
    req_data["cookie"] = cookies[0]
    req_data["view_state"] = soup.find("input", {"name": "__VIEWSTATE"})[
        "value"
    ]
    for option in options:
        cities.append(option["value"].strip())
    req_data["cities"] = cities
    return req_data


def start_parsing():
    try:
        data_dict = {}
        req_data = get_cities(HOME_PAGE_URL)
        req_data = get_court(req_data)
        start_date = "13/08/2019"
        # start_date = '01/Jan/2019'
        end_date = str(datetime.date.today().strftime("%d/%m/%Y"))
        start = datetime.datetime.strptime(start_date, "%d/%m/%Y")
        end = datetime.datetime.strptime(end_date, "%d/%m/%Y")
        step = datetime.timedelta(days=1)
        while start <= end:
            date = start.date().strftime("%d/%m/%Y")
            data = get_records(str(date), req_data)
            # data_dict[url] = data
            start += step
            # print(data)
            break

        # print(data)
        # print(len(data))

    except Exception as e:
        print("Exception while parsing page")
        print(e)

    return dict(
        status="ERROR", message="Exception Occured!!", error_type="EXCEPTION"
    )


def create_combinations():
    try:
        print("creating combination")
        start_parsing()
    except Exception as e:
        print("Exception while creating_combination")
        print(e)


if __name__ == "__main__":
    create_combinations()
