from bs4 import BeautifulSoup
from datetime import datetime, timedelta
from threading import Thread
import requests
import boto3
import http.client
import json

AVG_THRESHOLD = 60
PARSED_TILL = "31-12-1989"

http.client._MAXHEADERS = 100000
TIMEOUT = 120

HOME_PAGE_URL = "https://bombayhighcourt.nic.in/case_query.php"


ACCESS_KEY = "AKIAJQMKT7WP26VWAKOA"
SECRET_KEY = "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"
QUEUE_URL = "https://sqs.ap-south-1.amazonaws.com/449052551048/bombay_high_court"

sqs = boto3.resource(
    "sqs",
    region_name="ap-south-1",
    aws_access_key_id=ACCESS_KEY,
    aws_secret_access_key=SECRET_KEY,
)

session = requests.Session()


case_type = []


def soup_creator(url):
    return BeautifulSoup(url.text, "html.parser")


def feed_sqs(combs):
    # feed sqs here
    print("feeding sqs:")
    print(json.dumps(combs))
    messages = []
    for msg in combs:
        messages.append(msg)
        if len(messages) >= 10:
            Thread(target=send_messages, args=[messages]).start()
            messages = []
    if len(messages) > 0:
        Thread(target=send_messages, args=[messages]).start()


def send_messages(messages):
    entries = []
    i = 1
    for msg in messages:
        entries.append({"Id": str(i), "MessageBody": json.dumps(msg)})
        i += 1
    queue = sqs.Queue(QUEUE_URL)
    queue.send_messages(Entries=entries)


def get_case_type():
    response = session.get(HOME_PAGE_URL)
    if response.status_code != 200:
        print("Failed to load Page")
        return
    soup = soup_creator(response)
    options = soup.find("select", {"name": "m_skey"}).find_all("option")
    for option in options:
        case_type.append(option["value"])
    return case_type


def create_sqs_comb(start_date, end_date):
    combs = []
    bench = ["01", "02", "03"]
    side_m = ["C", "CR", "OS"]
    side_a = ["AR", "AC"]
    side_n = ["NC", "NR"]
    stamp_reg = ["R", "S"]
    case_type_m = [
        "AO",
        "ARA",
        "ARP",
        "CAO",
        "CAP",
        "CA",
        "CAA",
        "CAE",
        "CAT",
        "CAN",
        "CAC",
        "CAF",
        "CAM",
        "CAFM",
        "CAY",
        "CAL",
        "CAI",
        "CAS",
        "CAW",
        "CAR",
        "C.R",
        "CRA",
        "WP",
        "CP",
        "CAPL",
        "XOB",
        "FCA",
        "FEMA",
        "FERA",
        "FA",
        "LPA",
        "MPA",
        "MCA",
        "PIL",
        "RC",
        "RPF",
        "RAP",
        "RPFM",
        "RPV",
        "RPI",
        "RPA",
        "RPR",
        "RPT",
        "RPN",
        "RPC",
        "RPM",
        "RPL",
        "RPS",
        "RPW",
        "SA",
        "SMP",
        "SMWP",
        "SMPIL",
        "TXA",
        "XFER",
    ]
    case_type_a = [
        "AO",
        "EPAP",
        "ARBA",
        "ARB",
        "CEA",
        "CA",
        "CRF",
        "CRA",
        "COMAP",
        "CARBA",
        "CARAP",
        "CAP",
        "CMA",
        "CMP",
        "CAPL",
        "CP",
        "XAP",
        "XAPL",
        "XOBJ",
        "CSA",
        "EP",
        "FCA",
        "FA",
        "ITA",
        "LPA",
        "MVXA",
        "MP",
        "MCA",
        "PIL",
        "RC",
        "RA",
        "STAPL",
        "STA",
        "SA",
        "SMPIL",
        "SMC",
        "SMR",
        "SMW",
        "TA",
        "WTA",
        "WP",
    ]
    case_type_n = [
        "AO",
        "AA",
        "ARA",
        "ARP",
        "CAO",
        "CEL",
        "CER",
        "CAM",
        "CAA",
        "CAE",
        "CAN",
        "CAC",
        "CAF",
        "CAZ",
        "CAS",
        "CAT",
        "CAW",
        "CA",
        "C.REF",
        "CRA",
        "CS",
        "CAP",
        "CAL",
        "CALCR",
        "CMP",
        "CPL",
        "CP",
        "XOB",
        "CAPL",
        "EP",
        "EDR",
        "FCA",
        "FA",
        "GTA",
        "GTR",
        "ITL",
        "ITA",
        "ITR",
        "LPA",
        "MCA",
        "OLR",
        "PIL",
        "STA",
        "STR",
        "SA",
        "WTL",
        "WTA",
        "WTR",
        "WP",
    ]
    start = datetime.strptime(start_date, "%d-%m-%Y")
    end = datetime.strptime(end_date, "%d-%m-%Y")
    step = timedelta(days=90)
    while start < end:
        strt_date = str(start.strftime("%d-%m-%Y"))
        en_date = str((start + step).strftime("%d-%m-%Y"))
        for b in bench:
            if b == "01":
                side = side_m
                case_type = case_type_m
            elif b == "02":
                side = side_a
                case_type = case_type_a
            elif b == "03":
                side = side_n
                case_type = case_type_n
            for s in side:
                for st in stamp_reg:
                    for ct in case_type:
                        comb_dict = {}
                        comb_dict["bench"] = b
                        comb_dict["side"] = s
                        comb_dict["stamp_reg"] = st
                        comb_dict["case_type"] = ct
                        comb_dict["start_date"] = strt_date
                        comb_dict["end_date"] = en_date
                        # print(comb_dict)
                        combs.append(comb_dict)
        start += step
    return combs


def start_parsing(start_date, end_date):
    try:
        combs = create_sqs_comb(start_date, end_date)
        print("Combinations Create:", len(combs))
        feed_sqs(combs)
        print("Combinations Create:", len(combs))
    except Exception as e:
        print("Exception while creating combination")
        print(e)
        pass


def create_combinations(start_date, end_date):
    try:
        print("creating combination")
        start_parsing(start_date, end_date)
    except Exception as e:
        print("Exception while creating_combination")
        print(e)


if __name__ == "__main__":
    # fetch high court mapping from the database, create date-range combinations for the same.
    # after create combination insert them to sqs queue.
    start_date = "01-01-1994"
    end_date = "21-10-2019"
    create_combinations(start_date, end_date)
