from requests_toolbelt import MultipartEncoder
from bs4 import BeautifulSoup
import http.client
from datetime import datetime
import requests
import os
import json

http.client.MAXHEADERS = 100000
TIMEOUT = 120

HOME_PAGE_URL = "https://arwal.nic.in/document-category/court-orders/"

session = requests.Session()
base_url = "http://localhost:1567"


def create_get_url(base_url, data=dict()):
    if len(data) == 0:
        return base_url
    url = base_url + "?"
    for key, val in data.items():
        url += key + "=" + val + "&"
    return url[:-1]


def soup_creator(url):
    return BeautifulSoup(url.text, "html.parser")


def get_pdf(url, name):
    name = name.replace("/", "_")
    name = name.replace(".", "_")
    name = name.replace(" ", "_")
    response = session.get(url)
    file_name = "./PDF_Downloads/" + name + ".pdf"
    with open(file_name, "wb") as f:
        f.write(response.content)


def get_next_page(url):

    response = session.get(url)
    if response.status_code != 200:
        print("Failed to load home page!!")
        return
    soup = soup_creator(response)
    ul = soup.find("div", {"class": "row clear"}).find("ul")
    li_tags = ul.find_all("li")
    for li in li_tags:
        if li.find("a"):
            a = li.find("a")
            if a.text == "Next":
                next_page = a["href"]
                return next_page
            else:
                next_page = None
    return next_page


def get_col_data(cols):
    data_dict = {}

    data_dict["title"] = cols[0].text.strip()
    data_dict["date"] = cols[1].text.strip()
    data_dict["pdf_url"] = cols[2].find("a")["href"]
    response = session.get(data_dict["pdf_url"])
    doc_data = {
        "pdf_link": dict(
            content=response.content,
            content_type=response.headers["Content-Type"],
        )
    }
    data = dict(
        export_type="DATA", record_params=data_dict, doc_params=doc_data
    )
    api_data = prepare_export_data(data)
    url = base_url + "/export/data"
    api_call(url, api_data, api_data.content_type)
    return data_dict


def get_table(url):
    data = {}
    next_page = get_next_page(url)
    data["next_page"] = next_page
    response = session.get(url, timeout=TIMEOUT)
    if response.status_code != 200:
        print("Failed to load home page!!")
        return
    soup = soup_creator(response)
    table = soup.find("div", {"class": "distTableContent"}).find("table")
    rows = table.find_all("tr")[1:]
    for row in rows:
        cols = row.find_all("td")
        get_col_data(cols)
    return data


def prepare_export_data(data):
    params = dict(
        export_type=data["export_type"],
        record_params=data["record_params"],
        doc_params=dict(),
    )
    fields = {}
    if "doc_params" in data:
        for k, v in data["doc_params"].items():
            file_name = k
            params["doc_params"][k] = dict(
                content_type=v["content_type"], file_name=file_name
            )
            file_path = "./" + file_name
            with open(file_path, "wb") as f:
                f.write(v["content"])
            fields[file_name] = (
                file_name,
                open(file_path, "rb"),
                v["content_type"],
            )
            os.system("rm " + file_path)
    fields["params"] = json.dumps(params)
    return MultipartEncoder(fields=fields)


def api_call(url, data, content_type="text/plain"):
    try:
        response = requests.post(
            url=url, data=data, headers={"Content-Type": content_type}
        )
        print(response)
        resp = response.json()
        print(resp)
    except Exception as e:
        print("Exception while parsing response")
        print(e)


def start_parsing():
    try:
        # connecting to website
        order_data = {}
        url = create_get_url(HOME_PAGE_URL)
        data = get_table(url)
        order_data[url] = data["data"]
        while data["next_page"]:
            page = data["next_page"]
            data = get_table(page)
            order_data[page] = data["data"]
    except Exception as e:
        print("Exception while parsing page")
        print(e)

    return dict(
        status="ERROR", message="Exception Occured!!", error_type="EXCEPTION"
    )


def create_combinations():
    try:
        print("creating combination")
        start_parsing()
    except Exception as e:
        print("Exception while creating_combination")
        print(e)


def log_script_stats(st, et):
    dt_format = "%Y-%m-%d %H:%M:%S"
    start_time = st.strftime(dt_format)
    end_time = et.strftime(dt_format)
    print(
        "Combinations Created: started at %s and completed at %s"
        % (start_time, end_time)
    )


if __name__ == "__main__":
    start_time = datetime.now()
    create_combinations()
    end_time = datetime.now()
    log_script_stats(start_time, end_time)
    url = base_url + "/notify"
    api_call(url, json.dumps(dict(finished=True)))
