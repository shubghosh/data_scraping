from bs4 import BeautifulSoup
import requests
from PIL import Image
import numpy as np
import cv2
import pytesseract
from PIL import ImageEnhance

from pymongo import MongoClient
import boto3
import json
import hashlib

HOME_PAGE_URL = "http://www.mca.gov.in/mcafoportal/viewSignatoryDetails.do"
CAPTCHA_URL = "http://www.mca.gov.in/mcafoportal/getCapchaImage.do"
DATA_URL = "http://www.mca.gov.in/mcafoportal/viewSignatoryDetailsAction.do"

ACCESS_KEY = "AKIAJQMKT7WP26VWAKOA"
SECRET_KEY = "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"
QUEUE_URL = "https://sqs.ap-south-1.amazonaws.com/449052551048/mca_din"

sqs = boto3.resource(
    "sqs",
    region_name="ap-south-1",
    aws_access_key_id=ACCESS_KEY,
    aws_secret_access_key=SECRET_KEY,
)

SISYPHUS_AWS_ACCESS_KEY = "AKIAJQMKT7WP26VWAKOA"
SISYPHUS_AWS_SECRET_KEY = "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"
SISYPHUS_AWS_REGION = "ap-south-1"
SISYPHUS_AWS_S3_BUCKET_URL = "https://sisypheans.s3-ap-south-1.amazonaws.com/"
SISYPHUS_AWS_S3_BUCKET = "sisypheans"

s3 = boto3.client(
    "s3",
    aws_access_key_id=SISYPHUS_AWS_ACCESS_KEY,
    aws_secret_access_key=SISYPHUS_AWS_SECRET_KEY,
    region_name=SISYPHUS_AWS_REGION,
)

MONGO_URL = "3.80.136.128:30006"
MONGO_USERNAME = "kagzat"
MONGO_PASSWORD = "q0xoFtVOc2FzefbcZx9m5yzWNp49tsOH0GNAnQHD1Be1C2h/6eVE/XkW1eqqGnB8"
MONGO_AUTH_SOURCE = "admin"
DB_NAME = "sisyphus_prod_scraping"
COL_NAME = "mca_din"


def get_collection(db_name, col_name):
    client = MongoClient(
        MONGO_URL,
        username=MONGO_USERNAME,
        password=MONGO_PASSWORD,
        authSource=MONGO_AUTH_SOURCE,
    )
    db = client[db_name]
    return db[col_name]


def get_headers():
    return {
        "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3",
        "Accept-Encoding": "gzip, deflate",
        "Accept-Language": "en-GB,en-US;q=0.9,en;q=0.8",
        "Connection": "keep-alive",
        "Host": "www.mca.gov.in",
        "Upgrade-Insecure-Requests": "1",
        "User-Agent": "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/76.0.3809.132 Safari/537.36",
    }


def soup_creator(response):
    return BeautifulSoup(response.text, "html.parser")


def get_form_data(captcha, cin_number):

    return {
        "companyID": cin_number,
        "displayCaptcha": "true",
        "userEnteredCaptcha": captcha,
        "submitBtn": "Submit",
    }


def get_headers_cookie(cookie):
    return {
        "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3",
        "Accept-Encoding": "gzip, deflate",
        "Accept-Language": "en-GB,en-US;q=0.9,en;q=0.8",
        "Connection": "keep-alive",
        "Cookie": cookie,
        "Host": "www.mca.gov.in",
        "Upgrade-Insecure-Requests": "1",
        "User-Agent": "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/76.0.3809.132 Safari/537.36",
    }


def get_col_data(cols):
    data_dict = {}
    try:
        data_dict["din_pan"] = cols[0].text.strip()
        data_dict["full_name"] = cols[1].text.strip()
        data_dict["residential_address"] = cols[2].text.strip()
        data_dict["designation"] = cols[3].text.strip()
        data_dict["date_of_appointment"] = cols[4].text.strip()
        data_dict["whether_dsc_registered"] = cols[5].text.strip()
        data_dict["expiry_date_of_dsc"] = cols[6].text.strip()
        data_dict["surrendered_din"] = cols[7].text.strip()
    except Exception as e:
        print("in col data")
        print(e)
    return data_dict


def prepare_data(data_dict, doc_response):
    data_dict["elastic"] = 0
    data_dict["status"] = 0
    data_dict["backup"] = 0
    data_dict["sisyphean_id"] = ""
    data_dict["event_id"] = ""
    result = hashlib.md5(
        str(data_dict["cin"]).encode()
        + str(data_dict["directors_signatory_details"]).encode()
    )

    data_dict["md5"] = result.hexdigest()

    s3.put_object(
        Bucket=SISYPHUS_AWS_S3_BUCKET,
        Key=data_dict["md5"],
        Body=doc_response.content,
        ACL="public-read",
        ContentType="text/html",
        ContentDisposition="inline",
    )
    data_dict["link"] = SISYPHUS_AWS_S3_BUCKET_URL + data_dict["md5"]
    return data_dict


def get_response(cookie, captcha, session, cin_number, retry_count=0):
    print("Old Captcha", captcha)
    payload = get_headers_cookie(cookie)
    form_data = get_form_data(captcha, cin_number)
    cin_dict = {}
    cin_dict["cin"] = cin_number
    cin_dict["directors_signatory_details"] = []
    try:
        response = session.post(DATA_URL, data=form_data, headers=payload)
        if response.status_code != 200:
            print("Failed to load Page")
            return
        soup = soup_creator(response)
        rows = soup.find("table", id="signatoryDetails").find_all("tr")[1:]
        data_list = []
        for row in rows:
            cols = row.find_all("td")
            data_dict = get_col_data(cols)
            data_list.append(data_dict)
        cin_dict["directors_signatory_details"] = data_list
        cin_dict = prepare_data(cin_dict, response)
        return cin_dict
    except Exception as e:
        retry_count += 1
        if retry_count == 6:
            print(retry_count)
            retry_count = 0
            return None
        print(e)
        print("Retrying....!!!", retry_count)
        write_image(cookie, session)
        captcha = get_text_captcha()
        print("New Captcha", captcha)
        cin_dict = get_response(cookie, captcha, session, cin_number, retry_count)
        return cin_dict


def check_data_length(data):
    if len(data) >= 200:
        return True
    return False


def enhance_image(image):

    enh_bri = ImageEnhance.Brightness(image)
    brightness = 0.7
    imageb = enh_bri.enhance(brightness)

    enh_col = ImageEnhance.Color(imageb)
    color = 5
    imagec = enh_col.enhance(color)

    enh_con = ImageEnhance.Contrast(imagec)
    contrast = 7.95
    imagecs = enh_con.enhance(contrast)

    enh_sha = ImageEnhance.Sharpness(imagecs)
    sharpness = 0.99
    imagesh = enh_sha.enhance(sharpness)

    return imagesh


def get_text_captcha():
    img = Image.open("t2.jpeg")
    img = enhance_image(img)
    img = np.array(img)
    IMG = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)

    text = pytesseract.image_to_string(IMG, lang="eng")
    return text


def write_image(cookie, session):

    headers = get_headers_cookie(cookie)
    response = session.get(CAPTCHA_URL, headers=headers)
    if response.status_code != 200:
        print("Failed to Load Captcha")
        return
    with open("t2.jpeg", "wb") as f:
        f.write(response.content)


def get_cookie(session):
    response = session.get(HOME_PAGE_URL, headers=get_headers())
    if response.status_code != 200:
        print("Failed To Load Page")
        return
    cookie = response.headers["Set-Cookie"]
    cookie = "HttpOnly;" + " " + cookie.split(";")[0]
    return cookie


def store_data(items):
    try:
        col = get_collection(DB_NAME, COL_NAME)
        max_allowed = 200
        done = 0
        # print(len(items))
        if len(items) > 1:
            while done < len(items):
                try:
                    r = col.insert_many(items[done : done + max_allowed], ordered=False)
                    print(r)
                except Exception as e:
                    # print(items[done:done + max_allowed])
                    print("error while inserting many")
                    print(e)
                    pass
                done += max_allowed
        if len(items) == 1:
            col.insert_one(items[0])
    except Exception as e:
        print("Exception while storing data to db")
        print(e)


def prepare_requests(cin_number):
    session = requests.Session()
    cookie = get_cookie(session)
    write_image(cookie, session)
    captcha = get_text_captcha()
    cin_dict = get_response(cookie, captcha, session, cin_number)
    return cin_dict


def get_cin(cin_number):
    cin_dict = prepare_requests(cin_number)
    return cin_dict


def read_queue_and_start():
    cin_list = []
    queue = sqs.Queue(QUEUE_URL)
    messages = queue.receive_messages()
    while len(messages) > 0:
        for message in messages:
            cin = json.loads(message.body)
            # for logging purpose
            print("Fetched Combination", cin)
            cin_dict = get_cin(cin["companyID"])
            print(cin_dict)
            if cin_dict:
                cin_list.append(cin_dict)
            if check_data_length(cin_list):
                store_data(cin_list)
                print(len(cin_list), "records inserted")
                cin_list = []

            message.delete()
        messages = queue.receive_messages()
    if cin_list:
        store_data(cin_list)
        cin_list = []


def scrape_stack():
    params = {
        'access_key': 'YOUR_ACCESS_KEY',
        'url': 'http://scrapestack.com'
    }

    api_result = requests.get('http://api.scrapestack.com/scrape', params)
    website_content = api_result.content

    print(website_content)

    
if __name__ == "__main__":
    # read_queue_and_start()
    col = get_collection(DB_NAME, COL_NAME)
    print(col.count_documents({}))
    # get_cin()
    # scrape_stack()
