from threading import Thread
import boto3
import json
import pandas as pd

ACCESS_KEY = "AKIAJQMKT7WP26VWAKOA"
SECRET_KEY = "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"
QUEUE_URL = "https://sqs.ap-south-1.amazonaws.com/449052551048/mca_din"

sqs = boto3.resource(
        "sqs",
        region_name="ap-south-1",
        aws_access_key_id=ACCESS_KEY,
        aws_secret_access_key=SECRET_KEY,
)


def feed_sqs(combs):
    # feed sqs here
    print("feeding sqs:")
    print(json.dumps(combs))
    messages = []
    for msg in combs:
        messages.append(msg)
        if len(messages) >= 10:
            Thread(target=send_messages, args=[messages]).start()
            messages = []
    if len(messages) > 0:
        Thread(target=send_messages, args=[messages]).start()


def send_messages(messages):
    try:
        entries = []
        i = 1
        for msg in messages:
            entries.append({"Id": str(i), "MessageBody": json.dumps(msg)})
            i += 1
        queue = sqs.Queue(QUEUE_URL)
        queue.send_messages(Entries=entries)
    except Exception as e:
        print(e)
        print("retrying...!!!")
        # send_messages(messages)


def create_sqs_comb():
    cin_list = []
    cin = pd.read_csv("cin.csv")
    for i in range(0, len(cin)):
        cin_list.append({"companyID": cin.loc[i, "cin"]})
    return cin_list


def start_parsing():
    try:
        combs = create_sqs_comb()
        print(combs)
        print("Combinations Create:", len(combs))
        feed_sqs(combs)
        print("feeded")
    except Exception as e:
        print("Exception while creating combination")
        print(e)
        pass


def create_combinations():
    try:
        print("creating combination")
        start_parsing()
    except Exception as e:
        print("Exception while creating_combination")
        print(e)


if __name__ == "__main__":
    create_combinations()
