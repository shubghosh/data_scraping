import sys
import glob
import os 
import re
import json

def set_dictionary():
    data_dict = {
        "name":"",
        "designation":"",
        "courts":[],
        "email":"",
        "mobile_no":"",
        "and_name":"",
        "and_school":"",
        "and_city":"",
        "and_email":"",
        "and-mobile_no":"",
    }

    return data_dict

def start_script():
    
    name = 0
    court = 0
    by = 0
    an = 0
    results = set_dictionary()

    f = open('input.txt','r',encoding="utf-8")
    content = f.readlines()

    for line in content:
        line = line.replace('\n','')

        if re.search('BY.*',line):
            name = 1
            by =1
            continue
        
        if name and by:
            results['name'] = line.split(',')[0]
            results['designation'] = line.split(',')[1]
            name = 0
            court = 1
            continue

        if court and by:
            types = line.split('and')
            print(types)
            for type in types:
                results['courts'].append(type)
            court = 0
            continue

        if re.search('Email:.*',line) and by:
            line = re.search(r'Email:(.*)',line)
            results['email'] = line.group(1)
            continue
        
        if re.search('Mobile:.*',line) and by:
            line = re.search(r'Mobile:(.*)',line)
            results['mobile_no'] = line.group(1)
            continue
        
        if re.search('And.*',line):
            name = 1
            an = 1
            by = 0
            continue
        if name and an:
            results['and_name'] = line.split(',')[0]
            results['and_school'] = line.split(',')[1]
            results['and_city'] = line.split(',')[2]
            name = 0
            continue
        if re.search('Email:.*Mobile:.*',line) and an:
            line = re.search(r'Email:(.*)Mobile:(.*)',line)
            results['and_email'] = line.group(1)
            results['and_mobile_no'] = line.group(2)
            continue
        
        
    return results


def create_text_file():
    with open('input.txt','w') as f:
        t = open('desc.txt','r',encoding="utf-8")
        content = t.readlines()
        for line in content:
            line = line.replace('\t','')
            if not line.strip():
                continue
            f.write(line)
    data = start_script()
    return data