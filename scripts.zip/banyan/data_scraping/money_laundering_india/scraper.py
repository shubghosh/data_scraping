from bs4 import BeautifulSoup
import http.client
import re 
from datetime import datetime
import hashlib
import requests
import json
import subprocess
import os
import itertools
import boto3


http.client.MAXHEADERS = 100000
TIMEOUT = 120

HOME_PAGE_URL = 'http://moneylaundering.legal/judgement.php'
JUDGEMENT_PAGE_URL = 'http://moneylaundering.legal/'

session = requests.Session()

def create_get_url(base_url, data=dict()):
    if len(data) == 0:
        return base_url
    url = base_url + '?'
    for key, val in data.items():
        url += key + '=' + val + '&'
    return url[:-1]

def soup_creator(url):
    return BeautifulSoup(url.text, 'html.parser')

def check_next_page_status(soup):

    pagination_div = soup.find('div',{'class':'pagination'})
    a = pagination_div.find_all('a')
    next_page = HOME_PAGE_URL +'?'+ a[-1]['href'].split('?')[1]
    return(next_page)


def get_next_page(url):
    
    next_page = ''
    response = session.get(url, timeout=TIMEOUT)
    if response.status_code != 200:
        return dict(status='ERROR', error_type='PRE_LOAD_FAIL', message='Failed to load home page!!')
    soup = soup_creator(response)
    disabled_next = soup.find('span',{'class':'disabled'})
    
    if disabled_next != None:
        if disabled_next.text.strip() != 'Next':
            next_page = check_next_page_status(soup)
            return next_page
        else:
            return None
    else:
        next_page = check_next_page_status(soup)
        return(next_page)


def get_judgements(url):
    data = {}
    desc_link = []
    next_page = get_next_page(url)
    data['next_page'] = next_page

    response = session.get(url, timeout=TIMEOUT)
    if response.status_code != 200:
        return dict(status='ERROR', error_type='PRE_LOAD_FAIL', message='Failed to load home page!!')
    soup = soup_creator(response)
    headings = soup.find_all('h4')
    for heading in headings:
        a = heading.find('a')
        desc_link.append(JUDGEMENT_PAGE_URL + a['href'])
    data['judgement_links'] = desc_link
    return data


def get_judgement_data(urls):
    for url in urls:
        data_dict = {}
        response = session.get(url, timeout=TIMEOUT)
        if response.ok:
            soup = soup_creator(response)
            
            title = soup.find('figure',{'class':'event_title'}).find('h3').text
            data_dict['title'] = title

            meta_data = soup.find('figure',{'class':'event_meta'})
            b_tags = meta_data.find_all('b')
            span = meta_data.find_all('span')
            for (b,s) in itertools.zip_longest(b_tags,span):
                data_dict[b.text.strip()] = s.text.strip()

            desc = soup.find('figure',{'class':'event_description'})
            a_tags = desc.find_all('a')
            if a_tags:
                for a in a_tags:
                    if a['href'].startswith('http'):
                        data_dict['pdf_url'] = a['href']
            else:
                data_dict['pdf_url'] = ''
            data_dict = create_text_file(data_dict)
        else:
            print('Source not available')


def start_parsing():
    try:
        # connecting to website
        url = create_get_url(HOME_PAGE_URL)
        data = get_judgements(url)
        get_judgement_data(data['judgement_links'])

        while data['next_page']:
            print("--------------------------------------------------------------------------")
            data = get_judgements(data['next_page'])
            print(data['next_page'])

    except Exception as e:
        print('Exception while parsing page')
        print(e)
    
    return dict(status='ERROR', message='Exception Occured!!', error_type='EXCEPTION')


def create_combinations():
    try:
        print('creating combination')
        # start_parsing()
    except Exception as e:
        print('Exception while creating_combination')
        print(e)


def log_script_stats(st, et):
    dt_format = '%Y-%m-%d %H:%M:%S'
    start_time = st.strftime(dt_format)
    end_time = et.strftime(dt_format)
    print('Combinations Created: started at %s and completed at %s' % (start_time, end_time))


def create_text_file(data_dict):
    s = ''
    with open('input.txt','w') as f:
        t = open('desc.txt','r',encoding="utf-8")
        content = t.readlines()
        for line in content:
            line = line.replace('\n','')
            line = line.replace('\t','')    
            if not line.strip():
                continue
            f.write(line)
            s = s + line
    data_dict['content'] = s
    data_dict['content_type'] = 'text'
    result = hashlib.md5(data_dict['title'].encode() + data_dict['Court'].encode() + data_dict['Citation'].encode()
            + data_dict['content'])
    md5 = result.hexdigest()
    data_dict['md5'] = md5
    
    return data_dict


if __name__ == '__main__':
    start_time = datetime.now()
    create_combinations()
    end_time = datetime.now()
    log_script_stats(start_time, end_time)

