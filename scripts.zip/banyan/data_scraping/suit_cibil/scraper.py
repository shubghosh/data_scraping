from requests_toolbelt import MultipartEncoder
from bs4 import BeautifulSoup
import http.client
from datetime import datetime
import requests
import os
import json
import boto3
from pymongo import MongoClient
import hashlib

http.client.MAXHEADERS = 100000
TIMEOUT = 120

HOME_PAGE_URL = "https://suit.cibil.com/"
CASE_URL = "https://suit.cibil.com/loadSuitFiledDataSearchAction"
SUMMARY_URL = "https://suit.cibil.com/getSuitFiledStateSummaryAction"
STATE_URL = "https://suit.cibil.com/suitFiledAccountSearchAction"
DATA_URL = "https://suit.cibil.com/loadSearchResultPage"
session = requests.Session()
base_url = "http://localhost:1567"

SISYPHUS_AWS_ACCESS_KEY = "AKIAJQMKT7WP26VWAKOA"
SISYPHUS_AWS_SECRET_KEY = "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"
SISYPHUS_AWS_REGION = "ap-south-1"
SISYPHUS_AWS_S3_BUCKET_URL = "https://sisypheans.s3-ap-south-1.amazonaws.com/"
SISYPHUS_AWS_S3_BUCKET = "sisypheans"

s3 = boto3.client(
    "s3",
    aws_access_key_id=SISYPHUS_AWS_ACCESS_KEY,
    aws_secret_access_key=SISYPHUS_AWS_SECRET_KEY,
    region_name=SISYPHUS_AWS_REGION,
)

MONGO_URL = "3.80.136.128:30006"
MONGO_USERNAME = "kagzat"
MONGO_PASSWORD = "q0xoFtVOc2FzefbcZx9m5yzWNp49tsOH0GNAnQHD1Be1C2h/6eVE/XkW1eqqGnB8"
MONGO_AUTH_SOURCE = "admin"
DB_NAME = "sisyphus_prod_scraping"
COL_NAME = "cibil"


def get_collection(db_name, col_name):
    client = MongoClient(
        MONGO_URL,
        username=MONGO_USERNAME,
        password=MONGO_PASSWORD,
        authSource=MONGO_AUTH_SOURCE,
    )
    db = client[db_name]
    return db[col_name]


def soup_creator(url):
    return BeautifulSoup(url.text, "html.parser")


def set_form_data_case(date):

    return {
        "quarterIdSummary": "0",
        "quarterIdGrantors": "0",
        "croreAccount": "0",
        "quarterIdCrore": "0",
        "lakhAccount": "2",
        "quarterIdLakh": date["value"],
        "quarterDateStr": date["date"],
        "fileType": "1",
        "searchMode": "2",
    }


def set_headers(cookie_dict):
    return {
        "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3",
        "Accept-Encoding": "gzip, deflate, br",
        "Accept-Language": "en-GB,en-US;q=0.9,en;q=0.8",
        "Cache-Control": "max-age=0",
        "Connection": "keep-alive",
        "Content-Length": "149",
        "Content-Type": "application/x-www-form-urlencoded",
        "Cookie": cookie_dict["cookie"],
        "Host": "suit.cibil.com",
        "Origin": "https://suit.cibil.com",
        "Referer": "https://suit.cibil.com/",
        "Sec-Fetch-Mode": "navigate",
        "Sec-Fetch-Site": "same-origin",
        "Sec-Fetch-User": "?1",
        "Upgrade-Insecure-Requests": "1",
        "User-Agent": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/78.0.3904.97 Safari/537.36"
    }


def set_headers_state(cookie_dict):
    return {
        "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3",
        "Accept-Encoding": "gzip, deflate, br",
        "Accept-Language": "en-GB,en-US;q=0.9,en;q=0.8",
        "Cache-Control": "max-age=0",
        "Connection": "keep-alive",
        "Content-Length": "322",
        "Content-Type": "application/x-www-form-urlencoded",
        "Cookie": cookie_dict["cookie_data"],
        "Host": "suit.cibil.com",
        "Origin": "https://suit.cibil.com",
        "Referer": "https://suit.cibil.com/getSuitFiledStateSummaryAction",
        "Sec-Fetch-Mode": "navigate",
        "Sec-Fetch-Site": "same-origin",
        "Sec-Fetch-User": "?1",
        "Upgrade-Insecure-Requests": "1",
        "User-Agent": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/78.0.3904.97 Safari/537.36",
    }


def set_headers_data(cookie_dict):
    return {
        "Accept": "application/json, text/javascript, */*; q=0.01",
        "Accept-Encoding": "gzip, deflate, br",
        "Accept-Language": "en-GB,en-US;q=0.9,en;q=0.8",
        "Connection": "keep-alive",
        "Cookie": cookie_dict["cookie_data"],
        "Host": "suit.cibil.com",
        "Referer": "https://suit.cibil.com/suitFiledAccountSearchAction",
        "Sec-Fetch-Mode": "cors",
        "Sec-Fetch-Site": "same-origin",
        "User-Agent": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/78.0.3904.97 Safari/537.36",
        "X-Requested-With": "XMLHttpRequest"
    }


def set_form_data_bank(bank_id, date):
    return {
        "fileType": "1",
        "accountType": "Suit Filed Accounts - Wilful Defaulters Rs 25 lacs and above as on 30-Jun-2019 Search Details <br> Date of extraction 25-Nov-2019",
        "state": "", 
        "suitSearchBean.quarterBean.quarterId": date["value"],
        "suitSearchBean.bankBean.bankId": bank_id,
        "summaryState": "1",
        "suitSearchBean.summaryType": "1",
        "bank": "",
    }


def set_form_data_state(state_id, date, bank_id):
    return {
        "fileType": "1",
        "accountType": "Suit Filed Accounts - Wilful Defaulters Rs 25 lacs and above as on 30-Sep-2019 Search Details <br> Date of extraction 25-Nov-2019",
        "stateName": "",
        "suitSearchBean.quarterBean.quarterId": date["value"],
        "suitSearchBean.stateBean.stateId": state_id,
        "summaryState": "1",
        "suitSearchBean.summaryType": "1",
        "suitSearchBean.bankBean.bankId": bank_id,
    }


def set_params(data):
    return {
        "fileType": "1",
        "suitSearchBeanJson": data,
        "_search": "false",
        "nd": "1574664883119",
        "rows": "15",
        "page": "1",
        "sidx": "",
        "sord": "asc",
    }   


def store_data(items):
    try:
        col = get_collection(DB_NAME, COL_NAME)
        try:
            r = col.insert_many(items, ordered=False)
            print(r)
        except Exception as e:
            # print(items[done:done + max_allowed])
            print("error while inserting many")
            print(e)
            pass
    except Exception as e:
        print("Exception while storing data to db")
        print(e)


def prepare_data(data_dict, response):
    data_dict["elastic"] = 0
    data_dict["status"] = 0
    data_dict["backup"] = 0
    data_dict["sisyphean_id"] = ""
    data_dict["event_id"] = ""
    result = hashlib.md5(
        str(data_dict["bank_name"]).encode()
        + str(data_dict["branch"]).encode()
        + str(data_dict["quarter"]).encode()
        + str(data_dict["borrower_name"]).encode()
        + str(data_dict["registered_address"]).encode()
        + str(data_dict["directors_name"]).encode()
        + str(data_dict["outstanding_amount"]).encode()
        + str(data_dict["borrower_id"]).encode()
        + str(data_dict["quarter_id"]).encode()
    )

    data_dict["md5"] = result.hexdigest()

    s3.put_object(
        Bucket=SISYPHUS_AWS_S3_BUCKET,
        Key=data_dict["md5"],
        Body=response.content,
        ACL="public-read",
        ContentType="text/html",
        ContentDisposition="inline",
    )
    data_dict["link"] = SISYPHUS_AWS_S3_BUCKET_URL + data_dict["md5"]
    return data_dict


def get_data(data, cookie_dict):
    data_list = []
    response = session.get(DATA_URL, params=set_params(data), headers=set_headers_data(cookie_dict))
    if response.status_code != 200:
        print("Page Unavailable")
        return
    json_data = json.loads(response.text)
    for row in json_data["rows"]:
        try:
            data_dict = {}
            data_dict["bank_name"] = row["bankBean"]["bankName"]
            data_dict["branch"] = row["branchBean"]["branchName"]
            data_dict["quarter"] = row["quarterBean"]["quarterDateStr"]
            data_dict["borrower_name"] = row["borrowerName"]
            data_dict["registered_address"] = row["importDataBean"]["regaddr"]
            data_dict["directors_name"] = row["directorName"].strip().split(",")
            data_dict["outstanding_amount"] = row["totalAmount"]
            data_dict["borrower_id"] = row["borrowerId"]
            data_dict["quarter_id"] = row["quarterId"]
            data_dict = prepare_data(data_dict, response)
            data_list.append(data_dict)
        except Exception as e:
            print("In get-data")
            print(e)
    return data_list


def get_state_data(rows, date, cookie_dict, bank_id):
    for row in rows:
        try:
            state_form = set_form_data_state(row["stateBean"]["stateId"], date, bank_id)
            payload = set_headers_state(cookie_dict)
            response = session.post(STATE_URL, data=state_form, headers=payload)
            if response.status_code != 200:
                print("Page Unavailable")
                continue
            soup = soup_creator(response)
            data = soup.find_all("script", {"type": "text/javascript"})[-1].text.strip().split("suitSearchBeanJson")[1].split("'")[1]
            data_list = get_data(data, cookie_dict)
            store_data(data_list)
            print(len(data_list), "Inserted")
        except Exception as e:
            print("in get_state_data")
            print(e)
        # break

def get_bank_data(rows, date, cookie_dict):
    for row in rows:
        try:
            bank_id = row["bankBean"]["bankId"]
            form_dict = set_form_data_bank(row["bankBean"]["bankId"], date)
            response = session.post(SUMMARY_URL, data=form_dict, headers=set_headers(cookie_dict))
            if response.status_code != 200:
                print("Page Unavailable")
                return
            soup = soup_creator(response)
            json_data = soup.find_all("script", {"type": "text/javascript"})[-1].text.strip().split("var json")[1].split("'")[1]
            data_dict = json.loads(json_data)
            get_state_data(data_dict["rows"], date, cookie_dict, bank_id)
        except Exception as e:
            print("In get_bank_data")
            print(e)
        # break

def get_case_data(dates, cookie_dict):
    payload = set_headers(cookie_dict)
    i = 1
    for date in dates:
        try:
            print("Currently crawling", date)
            form_data = set_form_data_case(date)
            response = session.post(CASE_URL, data=form_data, headers=payload)
            if response.status_code != 200:
                print(date, "Unavailable")
                continue
            soup = soup_creator(response)
            json_data = soup.find_all("script", {"type": "text/javascript"})[-1].text.strip().split("var json")[1].split("'")[1]
            data_dict = json.loads(json_data)
            get_bank_data(data_dict["rows"], date, cookie_dict)
            print("crawled", i)
            print("*"*100)
            i += 1
        except Exception as e:
            print("In get_case_data")
            print(e)
        # break


def get_dates():
    response = session.get(HOME_PAGE_URL)
    dates = []
    if response.status_code != 200:
        print("Page Unavailable")
        return
    soup = soup_creator(response)
    options = soup.find("select", {"id": "quarterIdLakh"}).find_all("option")[1:]
    for option in options:
        dates.append({"value": option["value"], "date": option.text.strip()})
    return(dates)


def get_cookie():
    response = session.get(HOME_PAGE_URL)
    if response.status_code != 200:
        print("Page Unavailable")
        return
    cookie = response.headers["Set-Cookie"].split(",")[0].split(";")[0]
    return cookie


def get_token():
    response = session.get(HOME_PAGE_URL)
    if response.status_code != 200:
        print("Page Unavailable")
        return
    cookie = response.headers["Set-Cookie"].split(",")[0].split(";")[0] + "; " + response.headers["Set-Cookie"].split(",")[1].split(";")[0]
    return response.headers["Set-Cookie"].split(",")[0].split(";")[0]


def prepare_export_data(data):
    params = dict(
        export_type=data["export_type"],
        record_params=data["record_params"],
        doc_params=dict(),
    )
    fields = {}
    if "doc_params" in data:
        for k, v in data["doc_params"].items():
            file_name = k
            params["doc_params"][k] = dict(
                content_type=v["content_type"], file_name=file_name
            )
            file_path = "./" + file_name
            with open(file_path, "wb") as f:
                f.write(v["content"])
            fields[file_name] = (
                file_name,
                open(file_path, "rb"),
                v["content_type"],
            )
            os.system("rm " + file_path)
    fields["params"] = json.dumps(params)
    return MultipartEncoder(fields=fields)


def api_call(url, data, content_type="text/plain"):
    try:
        response = requests.post(
            url=url, data=data, headers={"Content-Type": content_type}
        )
        print(response)
        resp = response.json()
        print(resp)
    except Exception as e:
        print("Exception while parsing response")
        print(e)


def start_parsing():
    try:
        # connecting to website
        cookie_dict = {}
        cookie_dict["cookie"] = get_token()
        cookie_data = get_cookie()
        cookie_dict["cookie_data"] = cookie_data + "; " + cookie_dict["cookie"]

        dates = get_dates()
        get_case_data(dates, cookie_dict)
    except Exception as e:
        print("Exception while parsing page")
        print(e)

    return dict(
        status="ERROR", message="Exception Occured!!", error_type="EXCEPTION"
    )


def create_combinations():
    try:
        print("creating combination")
        start_parsing()
    except Exception as e:
        print("Exception while creating_combination")
        print(e)


def log_script_stats(st, et):
    dt_format = "%Y-%m-%d %H:%M:%S"
    start_time = st.strftime(dt_format)
    end_time = et.strftime(dt_format)
    print(
        "Combinations Created: started at %s and completed at %s"
        % (start_time, end_time)
    )


if __name__ == "__main__":
    create_combinations()
