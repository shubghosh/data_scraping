from requests_toolbelt import MultipartEncoder
import requests
from bs4 import BeautifulSoup
import shutil
import json
import re
from datetime import datetime
import pytesseract
from PIL import Image

BASE_URL = "https://main.sci.gov.in"
GET_URL = "https://main.sci.gov.in/case-status/"

session = requests.Session()
base_url = "http://localhost:1567"


def soup_creator(url):
    return BeautifulSoup(url.text, "lxml")


def get_case_status(diary_dict):
    data_dict = None
    while not data_dict:
        diary_dict = get_captcha(diary_dict)
        data_dict, response = get_case_data(diary_dict)
        if not data_dict:
            print("Invalid Captcha")
    data_dict["ref_md5"] = diary_dict["md5"]

    doc_data = {
        "link": dict(
            content=response.content, content_type=response.headers["Content-Type"]
        )
    }
    print(data_dict)
    data = dict(export_type="DATA", record_params=data_dict, doc_params=doc_data)
    api_data = prepare_export_data(data)
    url = base_url + "/export/data"
    api_call(url, api_data, api_data.content_type)
    return data_dict


def get_tesseract_captcha():
    img = Image.open("img1.png")
    result = pytesseract.image_to_string(
        img, lang="eng", config="--psm 10 --oem 3 -c tessedit_char_whitelist=0123456789"
    )
    return result


def get_captcha(diary_dict):
    response = session.get(GET_URL)
    if response.status_code != 200:
        print("Failed to load page")
        return
    soup = soup_creator(response)
    div = soup.find("img", {"id": "captcha"})
    CAPTCHA_URL = BASE_URL + div["src"] + "?0.4095848118365233"
    response = session.get(CAPTCHA_URL, stream=True)
    with open("img1.png", "wb") as out_file:
        shutil.copyfileobj(response.raw, out_file)
    files = {"file1": (open("img1.png", "rb"))}
    captcha = requests.post("http://13.126.130.44/results_sc", files=files)
    print(captcha)
    diary_dict["ansCaptcha"] = captcha.content.decode()
    # captcha = get_tesseract_captcha()
    # diary_dict["ansCaptcha"] = captcha
    return diary_dict


def get_case_data(post_data):
    try:
        data_dict = {}
        session.headers.update(
            {
                "User-Agent": "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/78.0.3904.108 Safari/537.36"
            }
        )
        session.headers.update({"referer": "https://main.sci.gov.in/case-status"})
        session.headers.update({"Vary": "Accept-Encoding"})
        DATA_URL = "https://main.sci.gov.in/php/case_status/case_status_process.php"

        data_dict["year"] = post_data["d_yr"]
        response = session.post(DATA_URL, data=post_data)
        soup = soup_creator(response)
        div = soup.find("div", {"class": "panel-body table-responsive"})
        if div:
            data_dict = data_table_data(div, data_dict)
            # data_dict = prepare_data(data_dict, response)
            return data_dict, response
    except Exception as e:
        print("error in get_case_data", e)
    return None, None


def data_table_data(div, data_dict):
    try:
        span = div.find("span", {"class": "blink_me"}).find("font")
        data_dict["case_status"] = span.text[0]
        rows = div.find("table").find_all("tr")
        li = []
        for td in rows:
            cols = td.find_all("td")
            li.append(cols)
        print(len(li))
        if len(li) == 12:
            data_dict = get_row_data(rows, data_dict)
        elif len(li) == 14:
            data_dict = get_row_data_14_row(rows, data_dict)
        elif len(li) == 13:
            data_dict = get_row_data_13_row(rows, data_dict)
        elif len(li) == 11:
            data_dict = get_row_data_11_row(rows, data_dict)
        elif len(li) == 6:
            data_dict = get_row_data_6_row(rows, data_dict)
        elif len(li) == 7:
            data_dict = get_row_data_6_row(rows, data_dict)
        return data_dict
    except Exception as e:
        print("error in data_table_data", e)


def get_pet_data(data):
    pet_dict = {}
    pet_list = []
    a = str(data).split("<p>")
    for i in a:
        i = (
            i.replace("\xa0\xa0", "")
            .replace("<td>", "")
            .replace("</td>", "")
            .replace("</p>", "")
            .replace("\n", "")
            .strip()
        )
        i = re.sub(" +", " ", i)
        i = i.split("<br/>")
        try:
            if i != [""]:
                pet_dict["name"] = i[0][2:].strip()
                pet_dict["address"] = i[1]
                pet_dict["type"] = 0
                pet_list.append(pet_dict.copy())
            elif i == []:
                pass
            else:
                pass
        except Exception as e:
            print(e)

    return pet_list


def get_res_data(data):
    res_dict = {}
    res_list = []
    a = str(data).split("<p>")
    for i in a:
        i = (
            i.replace("\xa0\xa0", "")
            .replace("<td>", "")
            .replace("</td>", "")
            .replace("</p>", "")
            .replace("\n", "")
            .strip()
        )
        i = re.sub(" +", " ", i)
        i = i.split("<br/>")
        try:
            if i != [""]:
                res_dict["name"] = i[0][2:].strip()
                res_dict["address"] = i[1]
                res_dict["type"] = 1
                res_list.append(res_dict.copy())
            elif i == []:
                pass
            else:
                pass
        except Exception as e:
            print(e)

    return res_list


def get_row_data_6_row(rows, data_dict):
    data_dict["diary_no"] = (
        rows[0]
        .find_all("td")[-1]
        .text.strip()
        .replace("\xa0\xa0", "")
        .replace("\n", "")
    )
    data_dict["case_no"] = (
        rows[1]
        .find_all("td")[-1]
        .text.strip()
        .replace("\xa0\xa0", "")
        .replace("\n", "")
    )
    data_dict["pet"] = get_pet_data(rows[2].find_all("td")[-1])
    data_dict["res"] = get_res_data(rows[3].find_all("td")[-1])
    data_dict["pet_advocate"] = (
        rows[4]
        .find_all("td")[-1]
        .text.strip()
        .replace("\u00a0\u00a0", "")
        .replace("\n", "")
    )
    data_dict["res_advocate"] = (
        rows[5]
        .find_all("td")[-1]
        .text.strip()
        .replace("\u00a0\u00a0", "")
        .replace("\n", "")
    )
    data_dict["data_inserted_on"] = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    return data_dict


def get_row_data_7_row(rows, data_dict):
    data_dict["diary_no"] = (
        rows[0]
        .find_all("td")[-1]
        .text.strip()
        .replace("\xa0\xa0", "")
        .replace("\n", "")
    )
    data_dict["case_no"] = (
        rows[1]
        .find_all("td")[-1]
        .text.strip()
        .replace("\xa0\xa0", "")
        .replace("\n", "")
    )
    if data_dict["case_status"] == "D":
        data_dict["disp_type"] = (
            rows[2]
            .find_all("td")[-1]
            .text.strip()
            .replace("\xa0\xa0", "")
            .replace("\n", "")
        )
    elif data_dict["case_status"] == "P":
        data_dict["listed_on"] = (
            rows[2]
            .find_all("td")[-1]
            .text.strip()
            .replace("\xa0\xa0", "")
            .replace("\n", "")
        )
    data_dict["pet"] = get_pet_data(rows[3].find_all("td")[-1])
    data_dict["res"] = get_res_data(rows[4].find_all("td")[-1])
    data_dict["pet_advocate"] = (
        rows[5].find_all("td")[-1].text.strip().replace("\u00a0\u00a0", "")
    )
    data_dict["res_advocate"] = (
        rows[6].find_all("td")[-1].text.strip().replace("\u00a0\u00a0", "")
    )
    data_dict["data_inserted_on"] = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    return data_dict


def get_row_data(rows, data_dict):
    data_dict["diary_no"] = (
        rows[0]
        .find_all("td")[-1]
        .text.strip()
        .replace("\xa0\xa0", "")
        .replace("\n", "")
    )
    data_dict["case_no"] = (
        rows[1]
        .find_all("td")[-1]
        .text.strip()
        .replace("\xa0\xa0", "")
        .replace("\n", "")
    )
    data_dict["present_last_listed_on"] = (
        rows[2]
        .find_all("td")[-1]
        .text.strip()
        .replace("\xa0\xa0", "")
        .replace("\n", "")
    )
    data_dict["status_stage"] = (
        rows[3]
        .find_all("td")[-1]
        .text.strip()
        .replace("\xa0\xa0", "")
        .replace("\n", "")
    )
    if data_dict["status_stage"][0] == "D":
        data_dict["disp_type"] = (
            rows[4]
            .find_all("td")[-1]
            .text.strip()
            .replace("\xa0\xa0", "")
            .replace("\n", "")
        )
    elif data_dict["status_stage"][0] == "P":
        data_dict["listed_on"] = (
            rows[4]
            .find_all("td")[-1]
            .text.strip()
            .replace("\xa0\xa0", "")
            .replace("\n", "")
        )
    data_dict["category"] = (
        rows[5]
        .find_all("td")[-1]
        .text.strip()
        .replace("\xa0\xa0", "")
        .replace("\n", "")
    )
    data_dict["act"] = (
        rows[6]
        .find_all("td")[-1]
        .text.strip()
        .replace("\xa0\xa0", "")
        .replace("\n", "")
    )
    data_dict["pet"] = get_pet_data(rows[7].find_all("td")[-1])
    data_dict["res"] = get_res_data(rows[8].find_all("td")[-1])
    data_dict["pet_advocate"] = (
        rows[9].find_all("td")[-1].text.strip().replace("\u00a0\u00a0", "")
    )
    data_dict["res_advocate"] = (
        rows[10].find_all("td")[-1].text.strip().replace("\u00a0\u00a0", "")
    )
    data_dict["under_sections"] = (
        rows[11]
        .find_all("td")[-1]
        .text.strip()
        .replace("\xa0\xa0", "")
        .replace("\n", "")
    )
    data_dict["data_inserted_on"] = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    return data_dict


def get_row_data_13_row(rows, data_dict):
    data_dict["diary_no"] = (
        rows[0]
        .find_all("td")[-1]
        .text.strip()
        .replace("\xa0\xa0", "")
        .replace("\n", "")
    )
    data_dict["case_no"] = (
        rows[1]
        .find_all("td")[-1]
        .text.strip()
        .replace("\xa0\xa0", "")
        .replace("\n", "")
    )
    data_dict["present_last_listed_on"] = (
        rows[2]
        .find_all("td")[-1]
        .text.strip()
        .replace("\xa0\xa0", "")
        .replace("\n", "")
    )
    data_dict["status_stage"] = (
        rows[3]
        .find_all("td")[-1]
        .text.strip()
        .replace("\xa0\xa0", "")
        .replace("\n", "")
    )
    if data_dict["status_stage"][0] == "D":
        data_dict["disp_type"] = (
            rows[4]
            .find_all("td")[-1]
            .text.strip()
            .replace("\xa0\xa0", "")
            .replace("\n", "")
        )
    elif data_dict["status_stage"][0] == "P":
        data_dict["listed_on"] = (
            rows[4]
            .find_all("td")[-1]
            .text.strip()
            .replace("\xa0\xa0", "")
            .replace("\n", "")
        )
    data_dict["admitted"] = (
        rows[5]
        .find_all("td")[-1]
        .text.strip()
        .replace("\xa0\xa0", "")
        .replace("\n", "")
    )
    data_dict["category"] = (
        rows[6]
        .find_all("td")[-1]
        .text.strip()
        .replace("\xa0\xa0", "")
        .replace("\n", "")
    )
    data_dict["act"] = (
        rows[7]
        .find_all("td")[-1]
        .text.strip()
        .replace("\xa0\xa0", "")
        .replace("\n", "")
    )
    data_dict["pet"] = get_pet_data(rows[8].find_all("td")[-1])
    data_dict["res"] = get_res_data(rows[9].find_all("td")[-1])
    data_dict["pet_advocate"] = (
        rows[10].find_all("td")[-1].text.strip().replace("\u00a0\u00a0", "")
    )
    data_dict["res_advocate"] = (
        rows[11].find_all("td")[-1].text.strip().replace("\u00a0\u00a0", "")
    )
    data_dict["under_sections"] = (
        rows[12]
        .find_all("td")[-1]
        .text.strip()
        .replace("\xa0\xa0", "")
        .replace("\n", "")
    )
    data_dict["data_inserted_on"] = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    return data_dict


def get_row_data_14_row(rows, data_dict):

    data_dict["diary_no"] = (
        rows[0]
        .find_all("td")[-1]
        .text.strip()
        .replace("\xa0\xa0", "")
        .replace("\n", "")
    )
    data_dict["case_no"] = (
        rows[1]
        .find_all("td")[-1]
        .text.strip()
        .replace("\xa0\xa0", "")
        .replace("\n", "")
    )
    data_dict["present_last_listed_on"] = (
        rows[2]
        .find_all("td")[-1]
        .text.strip()
        .replace("\xa0\xa0", "")
        .replace("\n", "")
    )
    data_dict["status_stage"] = (
        rows[3]
        .find_all("td")[-1]
        .text.strip()
        .replace("\xa0\xa0", "")
        .replace("\n", "")
    )
    if data_dict["status_stage"][0] == "D":
        data_dict["disp_type"] = (
            rows[4]
            .find_all("td")[-1]
            .text.strip()
            .replace("\xa0\xa0", "")
            .replace("\n", "")
        )
    elif data_dict["status_stage"][0] == "P":
        data_dict["listed_on"] = (
            rows[4]
            .find_all("td")[-1]
            .text.strip()
            .replace("\xa0\xa0", "")
            .replace("\n", "")
        )
    data_dict["admitted"] = (
        rows[5]
        .find_all("td")[-1]
        .text.strip()
        .replace("\xa0\xa0", "")
        .replace("\n", "")
    )
    data_dict["category"] = (
        rows[6]
        .find_all("td")[-1]
        .text.strip()
        .replace("\xa0\xa0", "")
        .replace("\n", "")
    )
    data_dict["act"] = (
        rows[7]
        .find_all("td")[-1]
        .text.strip()
        .replace("\xa0\xa0", "")
        .replace("\n", "")
    )
    data_dict["pet"] = get_pet_data(rows[8].find_all("td")[-1])
    data_dict["res"] = get_res_data(rows[9].find_all("td")[-1])
    data_dict["pet_advocate"] = (
        rows[10].find_all("td")[-1].text.strip().replace("\u00a0\u00a0", "")
    )
    data_dict["res_advocate"] = (
        rows[11].find_all("td")[-1].text.strip().replace("\u00a0\u00a0", "")
    )
    data_dict["intervenor_advocate"] = (
        rows[12].find_all("td")[-1].text.strip().replace("\u00a0\u00a0", "")
    )
    data_dict["under_sections"] = (
        rows[13]
        .find_all("td")[-1]
        .text.strip()
        .replace("\xa0\xa0", "")
        .replace("\n", "")
    )
    data_dict["data_inserted_on"] = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    return data_dict


def get_row_data_11_row(rows, data_dict):
    data_dict["diary_no"] = (
        rows[0]
        .find_all("td")[-1]
        .text.strip()
        .replace("\xa0\xa0", "")
        .replace("\n", "")
    )
    data_dict["case_no"] = (
        rows[1]
        .find_all("td")[-1]
        .text.strip()
        .replace("\xa0\xa0", "")
        .replace("\n", "")
    )
    data_dict["present_last_listed_on"] = (
        rows[2]
        .find_all("td")[-1]
        .text.strip()
        .replace("\xa0\xa0", "")
        .replace("\n", "")
    )
    data_dict["status_stage"] = (
        rows[3]
        .find_all("td")[-1]
        .text.strip()
        .replace("\xa0\xa0", "")
        .replace("\n", "")
    )
    data_dict["category"] = (
        rows[4]
        .find_all("td")[-1]
        .text.strip()
        .replace("\xa0\xa0", "")
        .replace("\n", "")
    )
    data_dict["act"] = (
        rows[5]
        .find_all("td")[-1]
        .text.strip()
        .replace("\xa0\xa0", "")
        .replace("\n", "")
    )
    data_dict["pet"] = get_pet_data(rows[6].find_all("td")[-1])
    data_dict["res"] = get_res_data(rows[7].find_all("td")[-1])
    data_dict["pet_advocate"] = (
        rows[8].find_all("td")[-1].text.strip().replace("\u00a0\u00a0", "")
    )
    data_dict["res_advocate"] = (
        rows[9].find_all("td")[-1].text.strip().replace("\u00a0\u00a0", "")
    )
    data_dict["under_sections"] = (
        rows[10]
        .find_all("td")[-1]
        .text.strip()
        .replace("\xa0\xa0", "")
        .replace("\n", "")
    )
    data_dict["data_inserted_on"] = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    return data_dict


def get_diary_details(end_point, data, content_type=None):
    diary_details = None
    try:
        url = base_url + end_point
        if content_type:
            response = session.post(url, data, {"Content-Type": content_type})
        else:
            response = session.post(url, data)
        if response:
            diary_details = response.json()["resp"]
    except Exception as e:
        print("exception while get_diary_details", e)
    return diary_details


def get_post_dict(diary_details):
    data_dict = {}
    data_dict["d_no"] = diary_details["diary_no"]
    data_dict["d_yr"] = diary_details["year"]
    data_dict["ansCaptcha"] = ""
    data_dict["md5"] = diary_details["md5"]

    return data_dict


def start_parsing():
    parsing = True
    end_point = "/import/data"
    while parsing:
        try:
            resp = get_diary_details(
                end_point, json.dumps({"import_type": "DATA"}), "text/plain"
            )
            print("diary details resp")
            print(resp)
            if resp:
                diary_details = resp["record_params"]
                # start parsing here
                post_diary_details = get_post_dict(diary_details)
                get_case_status(post_diary_details)
            else:
                parsing = False
                print("no parsed data found")
        except Exception as e:
            print("exception in start parsing", e)


def prepare_export_data(data):
    params = dict(
        export_type=data["export_type"],
        record_params=data["record_params"],
        doc_params=dict(),
    )
    fields = {}
    if "doc_params" in data:
        for k, v in data["doc_params"].items():
            file_name = k
            params["doc_params"][k] = dict(
                content_type=v["content_type"], file_name=file_name
            )
            file_path = "./" + file_name
            with open(file_path, "wb") as f:
                f.write(v["content"])
            fields[file_name] = (file_name, open(file_path, "rb"), v["content_type"])
            os.system("rm " + file_path)
    fields["params"] = json.dumps(params)
    return MultipartEncoder(fields=fields)


def api_call(url, data, content_type="text/plain"):
    try:
        response = requests.post(
            url=url, data=data, headers={"Content-Type": content_type}
        )
        print(response)
        resp = response.json()
        print(resp)
    except Exception as e:
        print("Exception while parsing response")
        print(e)


if __name__ == "__main__":
    # read_queue_and_start()
    start_parsing()
    # diary_details = {"d_no": "1", "d_yr": "2019", "ansCaptcha": ""}
    # data_dict = get_case_status(diary_details)
    # print(data_dict)
    url = base_url + "/notify"
    api_call(url, json.dumps(dict(finished=True)))
