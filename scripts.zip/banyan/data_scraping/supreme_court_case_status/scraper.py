import elasticsearch
import sys

es = elasticsearch.Elasticsearch(
    ["13.233.186.115:8881"],
    http_auth=("elasticuser", "ORYmu3iFnLFsg4j8pdMxwqRZzo8lIgK3"),
)


def main():
    page = es.search(
        index="kagzat",
        scroll="12m",
        size=10000,
        body={
            "query": {"bool": {"must": [{"match_phrase": {"source": "supreme court"}}]}}
        },
    )
    sid = page["_scroll_id"]
    scroll_size = len(page["hits"]["hits"])
    x = 0
    # Start scrolling
    case_category = {}
    
    while scroll_size > 0:
        try:
            x = x + 1
            print("Scrolling... %d" % x)
            page = es.scroll(scroll_id=sid, scroll="12m")
            sid = page["_scroll_id"]
            # Get the number of results that we returned in the last scroll
            scroll_size = len(page["hits"]["hits"])
            print("scroll size: " + str(scroll_size))
            data = page["hits"]["hits"]
            for doc in data:
                case_category[doc["_source"]["case_no"][0:2]] = "1"
            # sys.exit()
        except Exception as e:
            print(e)
    print(case_category)


if __name__ == "__main__":
    main()
