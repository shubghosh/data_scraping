from bs4 import BeautifulSoup
import http.client
from datetime import datetime
import requests
import json

http.client.MAXHEADERS = 100000
TIMEOUT = 120

HOME_PAGE_URL = 'https://mpphscl.in/Home/_SearchBlockList'
PDF_URL = 'https://mpphscl.in/'

session = requests.Session()

def create_get_url(base_url, data=dict()):
    if len(data) == 0:
        return base_url
    url = base_url + '?'
    for key, val in data.items():
        url += key + '=' + val + '&'
    return url[:-1]

def soup_creator(url):
    return BeautifulSoup(url.text, 'html.parser')

def get_pdf(url,name):
    name = name.replace('/','_')
    response = session.get(url)
    file_name = './PDF_Downloads/'+name+'.pdf'
    with open(file_name,'wb') as f:
        f.write(response.content)

def set_form_data():
    form_data = {
        'id': '1,1',
    }
    return form_data

def get_col_data(cols):
    data_dict = {}
    print(cols)
    data_dict['date'] = cols[0].text.strip()
    url = PDF_URL + cols[1].find('a')['href']
    data_dict['pdf_url'] = url 
    get_pdf(url,data_dict['date'])
    return data_dict


def get_table(url):
    data_dict = {}
    data_list = []
    form_data = set_form_data()
    response = session.post(url, data=form_data, timeout=TIMEOUT)
    if response.status_code != 200:
        print('Failed to load home page!!')
        return
    text = response.text.replace("\\","").replace('u003ca style="color:#428bca" ','')
    data_list = json.loads(text)
    # print(data_dict)
    for d in data_list:
        print()
        url = d['upload_attachment'][0].split('.')[0]
        url = PDF_URL + url.replace('href=u0027','') + '.pdf'
        print(url)
        d['pdf_url'] = url
        get_pdf(url,d['black_listing_order'])
        print(d)
    # print(data_list)
    return data_list


def start_parsing():
    try:
        # connecting to website
        url = create_get_url(HOME_PAGE_URL)
        data_list = get_table(url)
        # data_list = get_records(url, token_data)
        print(len(data_list),'DONE')
    except Exception as e:
        print('Exception while parsing page')
        print(e)
    
    return dict(status='ERROR', message='Exception Occured!!', error_type='EXCEPTION')


def create_combinations():
    try:
        print('creating combination')
        start_parsing()
    except Exception as e:
        print('Exception while creating_combination')
        print(e)


def log_script_stats(st, et):
    dt_format = '%Y-%m-%d %H:%M:%S'
    start_time = st.strftime(dt_format)
    end_time = et.strftime(dt_format)
    print('Combinations Created: started at %s and completed at %s' % (start_time, end_time))





if __name__ == '__main__':
    start_time = datetime.now()
    create_combinations()
    end_time = datetime.now()
    log_script_stats(start_time, end_time)

