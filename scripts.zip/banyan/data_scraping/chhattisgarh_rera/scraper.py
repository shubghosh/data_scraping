from bs4 import BeautifulSoup
import http.client
import re 
from datetime import datetime
import hashlib
import requests
import json
import subprocess
import os
import itertools
import boto3


http.client.MAXHEADERS = 100000
TIMEOUT = 120

HOME_PAGE_URL = 'https://rera.cgstate.gov.in/cause_list.aspx'
# JUDGEMENT_PAGE_URL = 'http://moneylaundering.legal/'
# PAGE_URL = 'https://apps.powergridindia.com/pgciltenders'
# PDF_URL = 'http://rera.rajasthan.gov.in'

session = requests.Session()

def create_get_url(base_url, data=dict()):
    if len(data) == 0:
        return base_url
    url = base_url + '?'
    for key, val in data.items():
        url += key + '=' + val + '&'
    return url[:-1]

def soup_creator(url):
    return BeautifulSoup(url.text, 'html.parser')


def set_payload(token_data):
    payload = {

        '__EVENTTARGET': 'ctl00$ContentPlaceHolder1$LinkButton1',
        '__EVENTARGUMENT': '',
        '__VIEWSTATE': token_data['vs'],
        '__EVENTVALIDATION': token_data['ev'],
        'ctl00$ContentPlaceHolder1$txt_applicant_name': '',
        'ctl00$ContentPlaceHolder1$txt_respondent_name': '',
        'ctl00$ContentPlaceHolder1$txt_complaint_number': '',
        'ctl00$ContentPlaceHolder1$txt_from_date': '',
        'ctl00$ContentPlaceHolder1$txt_to_date': '',
    }
    return payload


def set_request_headers(token_data):
    headers = {
        'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3',
        'Accept-Encoding': 'gzip, deflate, br',
        'Cache-Control': 'max-age=0',
        'Connection': 'keep-alive',
        'Content-Type': 'application/x-www-form-urlencoded',
        'Cookie': token_data['cookie'],
        'Origin': 'https://rera.cgstate.gov.in',
        'Referer': 'https://rera.cgstate.gov.in/cause_list.aspx',
        'Upgrade-Insecure-Requests': '1',
        'User-Agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_5) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/75.0.3770.100 Safari/537.36'
    }

    return headers


def get_col_data(cols):
    data_dict = {}
    print(cols)
    data_dict['s_no'] = cols[0].text.strip()
    data_dict['applicant_name'] = cols[1].text.strip()
    data_dict['respondent_name'] = cols[2].text.strip()
    data_dict['complaint_no'] = cols[3].text.strip()
    data_dict['hearing_date'] = cols[4].text.strip()
    return data_dict


def get_records(url, token_data):
    payload = set_payload(token_data)
    headers = set_request_headers(token_data)
    response = session.post(url, headers=headers, data=payload)
    if response.status_code != 200:
        print('Failed to load home page!!')
        return
    soup = soup_creator(response)
    table = soup.find('table',{'id':'ContentPlaceHolder1_gv_cause_list'})
    rows = table.find_all('tr')
    rows.pop(0)
    print(len(rows))
    data_list = []
    for row in rows:
        print(row)
        cols = row.find_all('td')
        data_dict = get_col_data(cols)
        data_list.append(data_dict)
        # break
    return data_list

def get_tokens(url):
    token_data = {}
    response = session.get(url, timeout=TIMEOUT)
    print(response)
    if response.status_code != 200:
        print('Failed to load home page!!')
        return
    soup = soup_creator(response)
    token_data['ev'] = soup.find('input',{'id':'__EVENTVALIDATION'})['value']
    token_data['vs'] = soup.find('input',{'id':'__VIEWSTATE'})['value']    
    token_data['cookie'] = response.headers['Set-Cookie'].split(';')[0]
    return token_data


def start_parsing():
    try:
        # connecting to website
        url = create_get_url(HOME_PAGE_URL)
        token_data = get_tokens(url)
        data_list = get_records(url, token_data)
        print(len(data_list),'DONE')
    except Exception as e:
        print('Exception while parsing page')
        print(e)
    
    return dict(status='ERROR', message='Exception Occured!!', error_type='EXCEPTION')


def create_combinations():
    try:
        print('creating combination')
        start_parsing()
    except Exception as e:
        print('Exception while creating_combination')
        print(e)


def log_script_stats(st, et):
    dt_format = '%Y-%m-%d %H:%M:%S'
    start_time = st.strftime(dt_format)
    end_time = et.strftime(dt_format)
    print('Combinations Created: started at %s and completed at %s' % (start_time, end_time))





if __name__ == '__main__':
    start_time = datetime.now()
    create_combinations()
    end_time = datetime.now()
    log_script_stats(start_time, end_time)

