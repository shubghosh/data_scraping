from bs4 import BeautifulSoup
import http.client
import re 
from datetime import datetime
import hashlib
import requests
import json
import subprocess
import os
import itertools
import boto3


http.client.MAXHEADERS = 100000
TIMEOUT = 120

HOME_PAGE_URL = 'https://www.casemine.com/search/in?q=outraging+modesty'
PAGE_URL = 'https://www.casemine.com'
CAPTCHA = 'https://www.google.com/recaptcha/api2/anchor?ar=1&k=6LcJ3BkTAAAAAHKTgjh9hLIeNBcCAa31q2P5r6PJ&co=aHR0cHM6Ly93d3cuY2FzZW1pbmUuY29tOjQ0Mw..&hl=en&v=v1562567553145&size=normal&cb=2i6c6pwlhbyx'
session = requests.Session()

def create_get_url(base_url, data=dict()):
    if len(data) == 0:
        return base_url
    url = base_url + '?'
    for key, val in data.items():
        url += key + '=' + val + '&'
    return url[:-1]

def soup_creator(url):
    # return BeautifulSoup(url.text, 'html5lib')
    return BeautifulSoup(url.text, 'html.parser')
    
def set_headers():
    headers = {
        'Cookie': 'JSESSIONID=1CD82F0EE464A20481DEF88304CF10D7; AWSELB=091151691C2B7CB12F1EE0932158384157A8B3173A084A2BB09445D92505C935E1F87D185279AD2A935063595952FF68EA89CAFCB468568B7C7317C008A1818C06D4D3EB81; _ga=GA1.2.279664206.1563452774; _gid=GA1.2.1131794543.1563452774; _gat_gtag_UA_80561974_1=1'
    }
    return headers


def get_form_data(csrf,token):
    form_data = {
        'g-recaptcha-response': token,
        '_csrf': csrf,
    }
    return form_data

def get_content(content_div):
    data_dict = {}
    
    data_dict['content'] = content_div.text.strip()
    return data_dict

def get_judgement_urls(url):
    data_list = []
    response = session.get(url, timeout=TIMEOUT, verify=False)
    soup = soup_creator(response)
    main_div = soup.find('div',{'class':'tab-content jl__tab-content'})
    a = main_div.find_all('a',{'class':'jdlink'})
    urls = []
    for q in a:
        url = PAGE_URL + q['href']
        urls.append(url)
    return urls

def get_judgement_details(urls):
    data_list = []
    data_dict = {}
    i = 0
    for url in urls:
        print(url)
        response = session.get(url)
        soup = soup_creator(response)
        csrf = soup.find('meta',{'name':'_csrf'})['content']
        print(csrf)
        print('---------------------------------------------------------------------------------------------')
        content_div = soup.find('div',{'class':'brieftext'})
        if content_div:
            data_dict['content'] = content_div.text.strip()
            data_dict['title'] = soup.find('h1',{'class':'judgement-title jd-title-jdp'}).text.strip()
            data_list.append(data_dict)
        else:
            # print(True,i)
            i+=1
            resp = session.get(CAPTCHA)
            soup = soup_creator(resp)
            token = soup.find('input',{'type':'hidden'})['value']
            form_data = get_form_data(csrf,token)

            res = session.post(url,data=form_data)
            soup_1 = soup_creator(res)
            print(res.url)
            # print(soup_1)
            print(res.url)
            content_div = soup_1.find('div',{'class':'brieftext'})
            print(content_div)
            data_dict['title'] = soup_1.find('h1',{'class':'judgement-title jd-title-jdp'}).text.strip()

            data = get_content(content_div)
            print(data)
            # data_list.append(data)

            # print(resp.url)
            break
    return data_list

# b0f8b534-fcc1-4876-8a5c-f0349cdf42d3
def start_parsing():
    try:
        # connecting to website
        url = create_get_url(HOME_PAGE_URL)
        urls = get_judgement_urls(url)
        data_list = get_judgement_details(urls)
        print(len(data_list))
    except Exception as e:
        print('Exception while parsing page')
        print(e)
    
    return dict(status='ERROR', message='Exception Occured!!', error_type='EXCEPTION')


def create_combinations():
    try:
        print('creating combination')
        start_parsing()
    except Exception as e:
        print('Exception while creating_combination')
        print(e)


def log_script_stats(st, et):
    dt_format = '%Y-%m-%d %H:%M:%S'
    start_time = st.strftime(dt_format)
    end_time = et.strftime(dt_format)
    print('Combinations Created: started at %s and completed at %s' % (start_time, end_time))


if __name__ == '__main__':
    start_time = datetime.now()
    create_combinations()
    end_time = datetime.now()
    log_script_stats(start_time, end_time)

