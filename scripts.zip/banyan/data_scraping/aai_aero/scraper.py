from bs4 import BeautifulSoup
import http.client
import re 
from datetime import datetime
import hashlib
import requests
import json
import subprocess
import os
import itertools
import boto3


http.client.MAXHEADERS = 100000
TIMEOUT = 120

HOME_PAGE_URL = 'https://www.aai.aero/en/tender/vendor-debarred-list'
# JUDGEMENT_PAGE_URL = 'http://moneylaundering.legal/'

session = requests.Session()

def create_get_url(base_url, data=dict()):
    if len(data) == 0:
        return base_url
    url = base_url + '?'
    for key, val in data.items():
        url += key + '=' + val + '&'
    return url[:-1]

def soup_creator(url):
    return BeautifulSoup(url.text, 'html.parser')


def get_next_page(url):
    next_page = ''
    response = session.get(url, timeout=TIMEOUT, verify=False)
    if response.status_code != 200:
        print('Failed to load home page!!')
    soup = soup_creator(response)
    next_page = soup.find('li',{'class':'pager-next'})
    if next_page:
        url = next_page.find('a')['href']
        return url
    else:
        return None


def get_vendors(url):
    meta_data = {}
    desc_link = []
    next_page = get_next_page(url)
    meta_data['next_page'] = next_page

    response = session.get(url, timeout=TIMEOUT)
    if response.status_code != 200:
        print('Failed to load home page!!')
    soup = soup_creator(response)
    rows = soup.find('tbody').find_all('tr')
    for row in rows:
        cols = row.find_all('td')
        data_dict = get_col_data(cols)
        print(data_dict)
        # meta_data['data'] = data_dict
        # break
    return meta_data


def get_col_data(cols):
    data_dict = {}
    for col in cols:
        data_dict['s_no'] = cols[0].text.strip()
        data_dict['region'] = cols[1].text.strip()
        data_dict['airport'] = cols[2].text.strip()
        data_dict['vendor_name'] = cols[3].text.strip()
        data_dict['vendor_address'] = cols[4].find('a')['data-content'].strip()
        data_dict['order_number'] = cols[5].text.strip()
        data_dict['order_date'] = cols[6].text.strip()
        data_dict['issued_by'] = cols[7].text.strip()
        data_dict['restrained_period_from'] = cols[8].text.strip()
        data_dict['restrained_period_upto'] = cols[9].text.strip()
        data_dict['description'] = cols[10].find('a')['data-content'].strip()
        data_dict['debarred_type'] = cols[11].text.strip()
    return data_dict



def start_parsing():
    try:
        # connecting to website
        url = create_get_url(HOME_PAGE_URL)
        # count = get_pages_count(url)
        data = get_vendors(url)
        print(data) 
        # print(len(data_list))
        i=1
        # while data['next_page']:
        #     i=i+1
        #     print("--------------------------------------------------------------------------------------------------------------")
        #     data = get_vendors(data['next_page'])
        #     # data_list = get_judgement_data(data['judgement_links'])
        #     # print(len(data_list))
        # print(i)
    except Exception as e:
        print('Exception while parsing page')
        print(e)
    
    return dict(status='ERROR', message='Exception Occured!!', error_type='EXCEPTION')


def create_combinations():
    try:
        print('creating combination')
        start_parsing()
    except Exception as e:
        print('Exception while creating_combination')
        print(e)


def log_script_stats(st, et):
    dt_format = '%Y-%m-%d %H:%M:%S'
    start_time = st.strftime(dt_format)
    end_time = et.strftime(dt_format)
    print('Combinations Created: started at %s and completed at %s' % (start_time, end_time))


def create_text_file(data_dict):
    s = ''
    with open('input.txt','w') as f:
        t = open('desc.txt','r',encoding="utf-8")
        content = t.readlines()
        for line in content:
            line = line.replace('\n','')
            line = line.replace('\t','')    
            if not line.strip():
                continue
            f.write(line)
            s = s + line
    data_dict['content'] = s
    data_dict['content_type'] = 'text'
    result = hashlib.md5(data_dict['title'].encode() + data_dict['Court'].encode() + data_dict['Citation'].encode()
            + data_dict['content'])
    md5 = result.hexdigest()
    data_dict['md5'] = md5
    
    return data_dict


if __name__ == '__main__':
    start_time = datetime.now()
    create_combinations()
    end_time = datetime.now()
    log_script_stats(start_time, end_time)

