import requests

# import pandas as pd
from bs4 import BeautifulSoup
from pymongo import MongoClient
import boto3
import hashlib
import json

HOME_PAGE_URL = "http://www.mca.gov.in/mcafoportal/viewCompanyMasterData.do"
DATA_URL = "http://www.mca.gov.in/mcafoportal/companyMasterDataPopup.do"
session = requests.Session()

ACCESS_KEY = "AKIAJQMKT7WP26VWAKOA"
SECRET_KEY = "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"
QUEUE_URL = "https://sqs.ap-south-1.amazonaws.com/449052551048/mca_cin"

sqs = boto3.resource(
    "sqs",
    region_name="ap-south-1",
    aws_access_key_id=ACCESS_KEY,
    aws_secret_access_key=SECRET_KEY,
)

SISYPHUS_AWS_ACCESS_KEY = "AKIAJQMKT7WP26VWAKOA"
SISYPHUS_AWS_SECRET_KEY = "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"
SISYPHUS_AWS_REGION = "ap-south-1"
SISYPHUS_AWS_S3_BUCKET_URL = "https://sisypheans.s3-ap-south-1.amazonaws.com/"
SISYPHUS_AWS_S3_BUCKET = "sisypheans"

s3 = boto3.client(
    "s3",
    aws_access_key_id=SISYPHUS_AWS_ACCESS_KEY,
    aws_secret_access_key=SISYPHUS_AWS_SECRET_KEY,
    region_name=SISYPHUS_AWS_REGION,
)

MONGO_URL = "3.80.136.128:30006"
MONGO_USERNAME = "kagzat"
MONGO_PASSWORD = "q0xoFtVOc2FzefbcZx9m5yzWNp49tsOH0GNAnQHD1Be1C2h/6eVE/XkW1eqqGnB8"
MONGO_AUTH_SOURCE = "admin"
DB_NAME = "sisyphus_prod_scraping"
COL_NAME = "mca_cin"


def get_collection(db_name, col_name):
    client = MongoClient(
        MONGO_URL,
        username=MONGO_USERNAME,
        password=MONGO_PASSWORD,
        authSource=MONGO_AUTH_SOURCE,
    )
    db = client[db_name]
    return db[col_name]


def set_headers():
    return {
        "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3",
        "Accept-Encoding": "gzip, deflate",
        "Accept-Language": "en-GB,en-US;q=0.9,en;q=0.8",
        "Connection": "keep-alive",
        "Host": "www.mca.gov.in",
        "Upgrade-Insecure-Requests": "1",
        "User-Agent": "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/76.0.3809.132 Safari/537.36",
    }


def soup_creator(url):
    return BeautifulSoup(url, "html.parser")


def get_cin(cin):
    print(cin)
    data_dict = get_response(cin)
    if data_dict:
        return data_dict
    else:
        return None


def prepare_data(data_dict, doc_response):
    data_dict["elastic"] = 0
    data_dict["status"] = 0
    data_dict["backup"] = 0
    data_dict["sisyphean_id"] = ""
    data_dict["event_id"] = ""
    result = hashlib.md5(
        str(data_dict["cin"]).encode()
        + str(data_dict["company_name"]).encode()
        + str(data_dict["roc_code"]).encode()
        + str(data_dict["registration_number"]).encode()
        + str(data_dict["company_category"]).encode()
        + str(data_dict["company_sub_category"]).encode()
        + str(data_dict["company_class"]).encode()
        + str(data_dict["authorised_capital"]).encode()
        + str(data_dict["paidup_capital"]).encode()
        + str(data_dict["number_of_members"]).encode()
        + str(data_dict["incorporation_date"]).encode()
        + str(data_dict["registered_address"]).encode()
        + str(data_dict["address_other"]).encode()
        + str(data_dict["email_id"]).encode()
        + str(data_dict["listing"]).encode()
        + str(data_dict["suspended_stock_exchange"]).encode()
        + str(data_dict["agm_last_date"]).encode()
        + str(data_dict["balance_sheet_date"]).encode()
        + str(data_dict["efiling_status"]).encode()
        + str(data_dict["directors_signatory_details"]).encode()
    )

    data_dict["md5"] = result.hexdigest()

    s3.put_object(
        Bucket=SISYPHUS_AWS_S3_BUCKET,
        Key=data_dict["md5"],
        Body=str(doc_response),
        ACL="public-read",
        ContentType="text/html",
        ContentDisposition="inline",
    )
    data_dict["link"] = SISYPHUS_AWS_S3_BUCKET_URL + data_dict["md5"]
    return data_dict


def get_row_data(rows):
    data_dict = {}
    try:
        data_dict["cin"] = rows[0].find_all("td")[-1].text.strip()
        data_dict["company_name"] = rows[1].find_all("td")[-1].text.strip()
        data_dict["roc_code"] = rows[2].find_all("td")[-1].text.strip()
        data_dict["registration_number"] = rows[3].find_all("td")[-1].text.strip()
        data_dict["company_category"] = rows[4].find_all("td")[-1].text.strip()
        data_dict["company_sub_category"] = rows[5].find_all("td")[-1].text.strip()
        data_dict["company_class"] = rows[6].find_all("td")[-1].text.strip()
        data_dict["authorised_capital"] = rows[7].find_all("td")[-1].text.strip()
        data_dict["paidup_capital"] = rows[8].find_all("td")[-1].text.strip()
        data_dict["number_of_members"] = rows[9].find_all("td")[-1].text.strip()
        data_dict["incorporation_date"] = rows[10].find_all("td")[-1].text.strip()
        data_dict["registered_address"] = rows[11].find_all("td")[-1].text.strip()
        data_dict["address_other"] = rows[12].find_all("td")[-1].text.strip()
        data_dict["email_id"] = rows[13].find_all("td")[-1].text.strip()
        data_dict["listing"] = rows[14].find_all("td")[-1].text.strip()
        data_dict["suspended_stock_exchange"] = rows[15].find_all("td")[-1].text.strip()
        data_dict["agm_last_date"] = rows[16].find_all("td")[-1].text.strip()
        data_dict["balance_sheet_date"] = rows[17].find_all("td")[-1].text.strip()
        data_dict["efiling_status"] = rows[18].find_all("td")[-1].text.strip()
    except Exception as e:
        print("In get row_data")
        print(e)
    return data_dict


def get_col_data(cols, data_dict):
    dir_dict = {}
    try:
        dir_dict["din_pan"] = cols[0].text.strip()
        dir_dict["name"] = cols[1].text.strip()
        dir_dict["start_date"] = cols[2].text.strip()
        dir_dict["end_date"] = cols[3].text.strip()
        dir_dict["surrendered_din"] = cols[4].text.strip()
    except Exception as e:
        print("In get row_data")
        print(e)
    return dir_dict


def get_response():
    try:
        with open("man.html", "rb") as f:
            soup = soup_creator(f.read())
        rows = soup.find("div", {"id": "companyMasterData"}).find("table", {"id": "resultTab1"}).find_all("tr")
        data_dict = get_row_data(rows)
        data_dict["directors_signatory_details"] = []
        rows_1 = soup.find("table", {"id": "resultTab6"}).find_all("tr")[1:]
        for row in rows_1:
            cols = row.find_all("td")
            dir_dict = get_col_data(cols, data_dict)
            data_dict["directors_signatory_details"].append(dir_dict)
        data_dict = prepare_data(data_dict, soup)
        print(data_dict)
        return data_dict
    except Exception as e:
        print(e)


if __name__ == "__main__":
    get_response()

