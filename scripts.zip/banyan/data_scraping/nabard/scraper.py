from requests_toolbelt import MultipartEncoder
from bs4 import BeautifulSoup
import http.client
from datetime import datetime
import requests
import json
import os
import xlrd

http.client.MAXHEADERS = 100000
TIMEOUT = 120

HOME_PAGE_URL = "https://www.nabard.org/BlacklistedNGOs.aspx?cid=636&id=24"

session = requests.Session()
base_url = "http://localhost:1567"


def create_get_url(base_url, data=dict()):
    if len(data) == 0:
        return base_url
    url = base_url + "?"
    for key, val in data.items():
        url += key + "=" + val + "&"
    return url[:-1]


def soup_creator(url):
    return BeautifulSoup(url.text, "html.parser")


def set_request_headers(token_data):
    headers = {"Cookie": token_data["cookie"]}
    return headers


def set_dictionary():
    data_dict = {}
    data_dict["s_no"] = ""
    data_dict["name"] = ""
    data_dict["bank"] = ""
    data_dict["post"] = ""
    data_dict["date"] = ""
    data_dict["details"] = ""
    return data_dict


def download_pdf(resp, name):
    if "/" in name:
        name = name.replace("/", "")
    file_name = "./PDF_Downloads/" + name + ".pdf"
    with open(file_name, "wb") as f:
        f.write(resp.content)


def download_xl(resp, name):
    if "/" in name:
        name = name.replace("/", "")
    file_name = "./Excel_Downloads/" + name + ".xlsx"
    with open(file_name, "wb") as f:
        f.write(resp.content)
    return file_name


def parse_xl(file_name):
    wb = xlrd.open_workbook("./e_downloads/test.xlsx")
    sheet = wb.sheet_by_index(0)
    row_count = sheet.nrows
    print(sheet.cell_value(1, 4))
    data_list = []
    for i in range(1, row_count):
        data_dict = set_dictionary()
        rows = sheet.row_values(i)
        data_dict["s_no"] = rows[1]
        data_dict["name"] = rows[2]
        data_dict["bank"] = rows[3]
        data_dict["post"] = rows[4]
        data_dict["date"] = rows[5]
        data_dict["details"] = rows[6]
        data_list.append(data_dict)
    return data_list


def get_excel_links(url, token_data):
    headers = set_request_headers(token_data)
    response = session.post(url, headers=headers)
    data_list = {}
    if response.status_code != 200:
        print("Failed to load home page!!")
        return
    soup = soup_creator(response)
    # print(soup)
    div = soup.find("div", {"class": "CNT-bullet"})
    li = div.find("ul").find_all("li")
    # print(li)
    for a in li:
        url = a.find("a")["href"]
        name = a.find("a").text
        resp = session.get(url)
        if resp.headers["Content-Type"] == "application/pdf":
            download_pdf(resp, name)
        elif (
            resp.headers["Content-Type"]
            == "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
        ):
            file_name = download_xl(resp, name)
            # print(1)
            data_list = parse_xl(file_name)
        else:
            print(resp.headers["Content-Type"])
        for data_dict in data_list:
            doc_data = {
                "pdf_link": dict(
                    content=resp.content,
                    content_type=resp.headers["Content-Type"],
                )
            }
            data = dict(
                export_type="DATA",
                record_params=data_dict,
                doc_params=doc_data,
            )
            api_data = prepare_export_data(data)
            url = base_url + "/export/data"
            api_call(url, api_data, api_data.content_type)
    return data_list


def get_tokens(url):
    token_data = {}
    response = session.get(url, timeout=TIMEOUT)
    print(response)
    if response.status_code != 200:
        print("Failed to load home page!!")
        return
    token_data["cookie"] = response.headers["Set-Cookie"].split(";")[0]
    return token_data


def prepare_export_data(data):
    params = dict(
        export_type=data["export_type"],
        record_params=data["record_params"],
        doc_params=dict(),
    )
    fields = {}
    if "doc_params" in data:
        for k, v in data["doc_params"].items():
            file_name = k
            params["doc_params"][k] = dict(
                content_type=v["content_type"], file_name=file_name
            )
            file_path = "./" + file_name
            with open(file_path, "wb") as f:
                f.write(v["content"])
            fields[file_name] = (
                file_name,
                open(file_path, "rb"),
                v["content_type"],
            )
            os.system("rm " + file_path)
    fields["params"] = json.dumps(params)
    return MultipartEncoder(fields=fields)


def api_call(url, data, content_type="text/plain"):
    try:
        response = requests.post(
            url=url, data=data, headers={"Content-Type": content_type}
        )
        print(response)
        resp = response.json()
        print(resp)
    except Exception as e:
        print("Exception while parsing response")
        print(e)


def start_parsing():
    try:
        # connecting to website
        url = create_get_url(HOME_PAGE_URL)
        token_data = get_tokens(url)
        data_list = get_excel_links(url, token_data)
        print(len(data_list), "DONE")
    except Exception as e:
        print("Exception while parsing page")
        print(e)

    return dict(
        status="ERROR", message="Exception Occured!!", error_type="EXCEPTION"
    )


def create_combinations():
    try:
        print("creating combination")
        start_parsing()
    except Exception as e:
        print("Exception while creating_combination")
        print(e)


def log_script_stats(st, et):
    dt_format = "%Y-%m-%d %H:%M:%S"
    start_time = st.strftime(dt_format)
    end_time = et.strftime(dt_format)
    print(
        "Combinations Created: started at %s and completed at %s"
        % (start_time, end_time)
    )


if __name__ == "__main__":
    start_time = datetime.now()
    create_combinations()
    end_time = datetime.now()
    log_script_stats(start_time, end_time)
    url = base_url + "/notify"
    api_call(url, json.dumps(dict(finished=True)))
