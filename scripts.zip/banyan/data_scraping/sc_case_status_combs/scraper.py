from requests_toolbelt import MultipartEncoder
import requests
from bs4 import BeautifulSoup
import time
import datetime
import boto3
import json


home_url = "https://main.sci.gov.in/"
part_name_url = "https://main.sci.gov.in/case-status"
url = "https://main.sci.gov.in/php/getPartyDetails.php"
captcha_url = "https://main.sci.gov.in/php/captcha.php"
sess = requests.Session()
sess.headers.update(
    {
        "User-Agent": "User-Agent: Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/70.0.3538.77 Safari/537.36"
    }
)
sess.headers.update({"referer": "https://main.sci.gov.in/case-status"})
sess.get(home_url, verify=False)
sess.get(part_name_url, verify=False)

base_url = "http://localhost:1567"


def get_filename():
    return str(time.time()).replace(".", "0")


def get_dairy_no_year(sess, url, data_dict, page_no):
    time.sleep(5)
    post_data = {
        "PartyType": "",
        "PartyName": data_dict["party_name"],
        "PartyYear": data_dict["party_year"],
        "PartyStatus": data_dict["party_status"],
        "page": page_no,
    }
    page = sess.post(url, data=post_data)
    soup = BeautifulSoup(page.text, "html.parser")
    for tr in soup.find("table", class_="mob abc").find_all("tr"):
        try:
            d = {}
            href = tr.find_all("td")[1].find("a").get("href")
            d_no = href.split("d_no=")[1].split("&d_yr")[0]
            year = href.split("&d_yr=")[1]
            d["org_link"] = href
            d["diary_no"] = d_no
            d["case_year"] = year
            d["link"] = (
                "https://www.sci.gov.in/php/case_status/case_status_process.php?d_no="
                + d_no
                + "&d_yr="
                + year
            )
            d["party_status"] = data_dict["party_status"]
            d["year"] = data_dict["party_year"]
            d["done"] = 0
            print(d)
            doc_data = {}
            data = dict(export_type="DATA", record_params=data_dict, doc_params=doc_data)
            api_data = prepare_export_data(data)
            url = base_url + "/export/data"
            api_call(url, api_data, api_data.content_type)
            # supreme_court_data_uniq.insert_one(d)
        except Exception as e:
            print(e)

    for li in soup.find_all("li"):
        try:
            text = li.text
            if text == "Next":
                print(text)
                status = li.get("class")[0]
                print(status)
                if status == "active":
                    print("next page")
                    page_no = page_no + 1
                    post_data = {
                        "PartyType": "",
                        "PartyName": data_dict["party_name"],
                        "PartyYear": data_dict["party_year"],
                        "PartyStatus": data_dict["party_status"],
                        "page": page_no,
                    }
                    get_dairy_no_year(
                        sess,
                        url,
                        data_dict["party_name"],
                        data_dict["party_year"],
                        data_dict["party_status"],
                        page_no,
                    )
        except Exception as e:
            print(e)


def get_sqs_resource(sqs_creds):
    return boto3.resource(
        "sqs",
        region_name=sqs_creds["region_name"],
        aws_access_key_id=sqs_creds["aws_access_key_id"],
        aws_secret_access_key=sqs_creds["aws_secret_access_key"],
    )


def read_queue_and_start(sqs_queue_url, sqs_creds):
    sqs_resource = get_sqs_resource(sqs_creds)
    queue = sqs_resource.Queue(sqs_queue_url)
    messages = queue.receive_messages()
    attempts = 0
    while len(messages) == 0 and attempts < 5:
        # don't stop the process immediately, wait for 2 mins and then
        # proceed
        time.sleep(60 * 2)
        attempts += 1

    while len(messages) > 0:
        for message in messages:
            comb_data = json.loads(message.body)

            # for logging purpose
            start_time = datetime.now()
            get_dairy_no_year(sess, url, 1, comb_data)  # <<-----
            end_time = datetime.now()
            log_script_stats(comb_data, start_time, end_time)
            message.delete()
        messages = queue.receive_messages()


def prepare_export_data(data):
    params = dict(
        export_type=data["export_type"],
        record_params=data["record_params"],
        doc_params=dict(),
    )
    fields = {}
    if "doc_params" in data:
        for k, v in data["doc_params"].items():
            file_name = k
            params["doc_params"][k] = dict(
                content_type=v["content_type"], file_name=file_name
            )
            file_path = "./" + file_name
            with open(file_path, "wb") as f:
                f.write(v["content"])
            fields[file_name] = (file_name, open(file_path, "rb"), v["content_type"])
            os.system("rm " + file_path)
    fields["params"] = json.dumps(params)
    return MultipartEncoder(fields=fields)


def api_call(url, data, content_type="text/plain"):
    try:
        response = requests.post(
            url=url, data=data, headers={"Content-Type": content_type}
        )
        print(response)
        resp = response.json()
        print(resp)
    except Exception as e:
        print("Exception while parsing response")
        print(e)


def start_parsing():
    try:
        queue_data = pre_script_parsing.pre_parsing()
        if not queue_data:
            return
        # start parsing here
        read_queue_and_start(queue_data["sqs_queue_url"], queue_data["sqs_creds"])
    except Exception as e:
        print("Exception while creating_combination")
        print(e)


def log_script_stats(rec, st, et):
    dt_format = "%Y-%m-%d %H:%M:%S"
    start_time = st.strftime(dt_format)
    end_time = et.strftime(dt_format)
    print(rec)
    print(
        "Combination Parsed: started at %s and completed at %s" % (start_time, end_time)
    )


if __name__ == "__main__":
    start_parsing()

