import sqs_feeder
from pymongo import MongoClient
from datetime import datetime

def get_collection(db_details):
    client = MongoClient(
        db_details["db_credentials"]["url"],
        username=db_details["db_credentials"]["username"],
        password=db_details["db_credentials"]["password"],
        authSource=db_details["db_credentials"]["auth_source"],
    )
    db = client[db_details["db_conf"]["db_name"]]
    return db[db_details["db_conf"]["col_name"]]


def get_combination(db_details):
    combinations = []
    col = get_collection(db_details)
    query = {"party_year": "2019"}
    resp = col.find(
        query,
        {
            "_id": 0,
            "sisyphean_id": 0,
            "event_id": 0,
            "elastic": 0,
            "backup": 0,
            "status": 0,
        },
    )
    for rec in resp:
        rec["party_year"] = datetime.now().year
        combinations.append(rec)
    print(len(combinations))
    return combinations


def prepare_combinations(queue_data, populate_data):
    # populate_data = dict(populate=True, db_details=dict())
    # db_details is optional and can be used in case when combinations need be
    #  prepared using db combinations
    records = get_combination(populate_data["db_details"])
    sqs_feeder.feed_sqs(queue_data["sqs_queue_url"], queue_data["sqs_creds"], records)